# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard-nav.spec.ts >> keyboard-nav >> for typescript >> basic keyboard navigation
- Location: e2e/keyboard-nav.spec.ts:24:17

# Error details

```
Error: expect(locator).toHaveScreenshot(expected) failed

Locator: locator('.ag-charts-canvas-center')
  88 pixels (ratio 0.01 of all image pixels) are different.

  Snapshot: 3rd-datum-2nd-series-focus.png

Call log:
  - Expect "toHaveScreenshot(3rd-datum-2nd-series-focus.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - waiting for locator('.ag-charts-canvas-center')
    - locator resolved to <div role="presentation" class="ag-charts-canvas-center">…</div>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - 2124 pixels (ratio 0.01 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - waiting for locator('.ag-charts-canvas-center')
    - locator resolved to <div role="presentation" class="ag-charts-canvas-center">…</div>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - 2119 pixels (ratio 0.01 of all image pixels) are different.
  - waiting 250ms before taking screenshot
  - waiting for locator('.ag-charts-canvas-center')
    - locator resolved to <div role="presentation" class="ag-charts-canvas-center">…</div>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - captured a stable screenshot
  - 88 pixels (ratio 0.01 of all image pixels) are different.

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - generic [ref=e4]: "Element before chart:"
    - textbox "Element before chart:" [ref=e5]
  - generic [ref=e6]:
    - figure "chart, 6 series":
      - button "Renewable sources used to generate electricity for transport fuels" [ref=e7]
      - generic [ref=e8]:
        - img
        - img "2019; Offshore Wind; 2.749K" [active] [ref=e9]
      - generic [ref=e10]: kilotonnes of oil equivalent (ktoe)
      - list "Legend" [ref=e12]:
        - listitem:
          - switch "Onshore Wind, Legend item 1 of 6" [checked] [ref=e13] [cursor=pointer]
        - listitem:
          - switch "Offshore Wind, Legend item 2 of 6" [checked] [ref=e14] [cursor=pointer]
        - listitem:
          - switch "Landfill Gas, Legend item 3 of 6" [checked] [ref=e15] [cursor=pointer]
        - listitem:
          - switch "Solar Photovoltaics, Legend item 4 of 6" [checked] [disabled]
        - listitem:
          - switch "Small Scale Hydro, Legend item 5 of 6" [checked] [disabled]
        - listitem:
          - switch "Large Scale Hydro, Legend item 6 of 6" [checked] [disabled]
      - group "Legend Pagination":
        - button "Previous Legend Page" [disabled] [ref=e16]
        - button "Next Legend Page" [ref=e17] [cursor=pointer]
    - status
    - generic:
      - generic:
        - generic: "2019"
        - generic:
          - img
        - generic:
          - generic: Offshore Wind
          - generic: 2.749K
  - generic [ref=e19]:
    - generic [ref=e20]: "Element after chart:"
    - textbox "Element after chart:" [ref=e21]
```

# Test source

```ts
  1  | import type { Locator, Page } from '@playwright/test';
  2  | import { mkdirSync, writeFileSync } from 'node:fs';
  3  | import { join, parse } from 'node:path';
  4  | 
  5  | // The `ag-charts-test` barrel eagerly loads skia-canvas via mock-canvas and its built `dist` is absent
  6  | // in the Playwright CI container, so import the sampler source module (core-only) directly.
  7  | import {
  8  |     type SerializedSceneRoots,
  9  |     sampleSerializedRoots,
  10 |     sceneSampleToJSON,
  11 | } from '../../../libraries/ag-charts-test/src/scene/scene-sample';
  12 | import { evalPageFunction } from './agE2E';
  13 | import { expect, test } from './fixture';
  14 | import { waitForAllChartUpdates } from './util';
  15 | 
  16 | type SceneCaptureMode = 'all' | 'off' | 'diff';
  17 | 
  18 | function sceneCaptureMode(): SceneCaptureMode {
  19 |     const mode = process.env.AG_SCENE_SNAPSHOTS;
  20 |     return mode === 'all' || mode === 'off' ? mode : 'diff';
  21 | }
  22 | 
  23 | function writeSceneSnapshots(name: string, roots: SerializedSceneRoots[]): void {
  24 |     if (roots.length === 0) return;
  25 |     // Mirror Playwright's resolved screenshot path so the scene JSON carries the same project and platform
  26 |     // identity (e.g. `chart-chromium-linux`) and cannot collide across projects.
  27 |     const screenshot = parse(test.info().snapshotPath(name, { kind: 'screenshot' }));
  28 |     const dir = join(screenshot.dir, '__scene_snapshots__');
  29 |     mkdirSync(dir, { recursive: true });
  30 |     for (const [i, root] of roots.entries()) {
  31 |         const id = roots.length > 1 ? `${screenshot.name}-chart${i}` : screenshot.name;
  32 |         const json = sceneSampleToJSON(sampleSerializedRoots(root, { includeChrome: true }));
  33 |         writeFileSync(join(dir, `${id}.json`), JSON.stringify(json, null, 2));
  34 |     }
  35 | }
  36 | 
  37 | /**
  38 |  * Screenshot a chart target and, unless `AG_SCENE_SNAPSHOTS=off`, capture an adjacent scene-graph JSON
  39 |  * beside the image baseline (`<spec>.ts-snapshots/__scene_snapshots__/<name>.json`) in the identical
  40 |  * shape as the unit capture, for mechanical (coordinate-level) diff review. One JSON per chart on the
  41 |  * page, suffixed `-chart<i>` when more than one.
  42 |  *
  43 |  * Playwright exposes no per-assertion image-diff result (unlike jest-image-snapshot), so `all` and
  44 |  * `diff` behave identically here — capture whenever the flag is not `off`. CI sets `all` on baseline
  45 |  * pushes and `diff` on PRs; both capture.
  46 |  */
  47 | export async function expectChartScreenshot(
  48 |     page: Page,
  49 |     target: Page | Locator,
  50 |     name: string,
  51 |     options?: Parameters<ReturnType<typeof expect<Locator>>['toHaveScreenshot']>[1]
  52 | ): Promise<void> {
  53 |     await waitForAllChartUpdates(page);
  54 |     if (sceneCaptureMode() === 'off') {
  55 |         await expect(target).toHaveScreenshot(name, options);
  56 |         return;
  57 |     }
  58 |     // The JSON explains a pixel change, so it must be written even when the screenshot comparison fails.
  59 |     let screenshotError: unknown;
  60 |     let screenshotFailed = false;
  61 |     try {
> 62 |         await expect(target).toHaveScreenshot(name, options);
     |                              ^ Error: expect(locator).toHaveScreenshot(expected) failed
  63 |     } catch (error) {
  64 |         screenshotFailed = true;
  65 |         screenshotError = error;
  66 |     }
  67 | 
  68 |     try {
  69 |         const roots = (await evalPageFunction(page, 'captureScenes')) as SerializedSceneRoots[];
  70 |         writeSceneSnapshots(name, roots);
  71 |     } catch (captureError) {
  72 |         // A missing scene artifact must not hide behind a passing screenshot; when the screenshot also failed,
  73 |         // that is the more actionable error.
  74 |         if (!screenshotFailed) {
  75 |             throw captureError;
  76 |         }
  77 |         process.stderr.write(`AG_SCENE_SNAPSHOTS: e2e scene capture failed: ${String(captureError)}\n`);
  78 |     }
  79 | 
  80 |     if (screenshotFailed) {
  81 |         throw screenshotError;
  82 |     }
  83 | }
  84 | 
```