# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: generated/examples-nightingale-series.spec.ts >> examples-nightingale-series >> Framework: angular >> Example docs/nightingale-series: radius-axis-position >> should load http://e2e.ag-grid.com:4601/angular/nightingale-series/examples/radius-axis-position
- Location: e2e/examples-util.ts:362:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('canvas').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('canvas').first()

```

# Test source

```ts
  194 | 
  195 |     return {
  196 |         clear,
  197 |         async expectLogs(calls: string[]) {
  198 |             const expectedCount: number = calls.length;
  199 |             await expect
  200 |                 .poll(() => consoleLogs.length, { message: `Waiting for ${expectedCount} console logs` })
  201 |                 .toBeGreaterThanOrEqual(expectedCount);
  202 |             expect(consoleLogs).toEqual(calls);
  203 |         },
  204 |         getLogs() {
  205 |             return consoleLogs;
  206 |         },
  207 |     };
  208 | }
  209 | 
  210 | // A variant of createConsoleLogs that offer more fine-tuned config & assertions
  211 | export function createConsoleTracker(page: Page) {
  212 |     type Message = {
  213 |         args: ReturnType<ConsoleMessage['args']>;
  214 |         text: ReturnType<ConsoleMessage['text']>;
  215 |         type: ReturnType<ConsoleMessage['type']>;
  216 |     };
  217 |     type ConsoleTracker = {
  218 |         init(): void;
  219 |         teardown(): void;
  220 |         popMessages(expectedCount: number): Promise<Message[]>;
  221 |     };
  222 |     const messages: Message[] = [];
  223 |     function onConsoleMessage(msg: ConsoleMessage): void {
  224 |         const args = msg.args();
  225 |         const text = msg.text();
  226 |         const type = msg.type();
  227 |         const ignore = ignoreMessageRegexes.some((regex) => regex.test(text));
  228 |         if (!ignore) {
  229 |             messages.push({ type, args, text });
  230 |         }
  231 |     }
  232 | 
  233 |     const consoleTracker: ConsoleTracker = {
  234 |         init() {
  235 |             page.on('console', onConsoleMessage);
  236 |         },
  237 |         teardown() {
  238 |             page.off('console', onConsoleMessage);
  239 |         },
  240 |         async popMessages(expectedCount: number) {
  241 |             await waitForChartUpdate(page.locator(SELECTORS.wrapper));
  242 |             const pollopts = { message: `Waiting for ${expectedCount} console logs` };
  243 |             await expect.poll(() => messages.length, pollopts).toBeGreaterThanOrEqual(expectedCount);
  244 |             return messages.splice(0, messages.length);
  245 |         },
  246 |     };
  247 |     return consoleTracker;
  248 | }
  249 | 
  250 | export async function repeat(repCount: number, fn: () => Promise<void>): Promise<void>;
  251 | export function repeat(repCount: number, fn: () => void): void;
  252 | export async function repeat(repCount: number, fn: () => void | Promise<void>): Promise<void> {
  253 |     for (let i = 0; i < repCount; i++) {
  254 |         await fn();
  255 |     }
  256 | }
  257 | 
  258 | /**
  259 |  * Example pages request the chart font only once the chart has initialised, and loading it
  260 |  * triggers a re-render, so the network can reopen long after `load` and never go idle on pages
  261 |  * holding several charts. Bound the wait instead of letting it run to the test timeout: pages
  262 |  * that do settle are unaffected, and the rest still get the settling time that callers relying
  263 |  * on a quiet page expect.
  264 |  */
  265 | const NETWORK_IDLE_TIMEOUT_MS = 5_000;
  266 | 
  267 | export async function gotoUrl(page: Page, url: string) {
  268 |     // 'commit' rather than Playwright's default 'load'. The load event does not fire until every
  269 |     // subresource in the document's delay-the-load-event set has settled, and on the deployed site
  270 |     // that set reaches hosts nobody here controls - plausible.io and Google Tag Manager are on
  271 |     // every page. One slow vendor otherwise times out a navigation to a page that rendered
  272 |     // perfectly well: post-deploy verification lost 15 navigations that way on 2 September 2026,
  273 |     // every one of them "waiting until load" against a site that was serving correctly.
  274 |     //
  275 |     // 'domcontentloaded' would not be enough - the Plausible tag is `defer`, and deferred scripts
  276 |     // block DOMContentLoaded too. The bounded networkidle wait below is what settles the page, and
  277 |     // a page that does settle still reaches it, so nothing here loosens for a healthy page.
  278 |     await page.goto(url, { waitUntil: 'commit' });
  279 |     // The title assertion reads the parsed document, and 'commit' resolves before the parser has
  280 |     // reached <title>. readyState leaves 'loading' at the end of parsing, ahead of the deferred
  281 |     // scripts that block DOMContentLoaded, so this waits for the document, not for a vendor.
  282 |     await page.waitForFunction(() => document.readyState !== 'loading');
  283 |     await page.waitForLoadState('networkidle', { timeout: NETWORK_IDLE_TIMEOUT_MS }).catch(() => {});
  284 |     expect(await page.title()).not.toMatch(/Page Not Found/);
  285 | }
  286 | 
  287 | export async function gotoExample(page: Page, url: string, opts = { skipStabilityChecks: false }) {
  288 |     // gotoUrl settles the page as far as it can and asserts the page was found.
  289 |     await gotoUrl(page, url + '#e2e=true');
  290 | 
  291 |     // Wait for synchronous JS execution to complete before we start waiting
  292 |     // for <canvas/> to appear.
  293 |     await page.evaluate(() => 1);
> 294 |     await expect(page.locator(SELECTORS.canvas).first()).toBeVisible({ timeout: 10_000 });
      |                                                          ^ Error: expect(locator).toBeVisible() failed
  295 |     for (const elements of await page.locator(SELECTORS.canvas).all()) {
  296 |         await expect(elements).toBeVisible();
  297 |     }
  298 | 
  299 |     if (opts.skipStabilityChecks) return;
  300 |     await waitForAllChartUpdates(page);
  301 | }
  302 | 
  303 | export async function waitForAllChartUpdates(page: Page) {
  304 |     for (const elements of await page.locator(SELECTORS.wrapper).all()) {
  305 |         const count: number = await elements.count();
  306 |         for (let i = 0; i < count; i++) {
  307 |             await expect(elements.nth(i)).toHaveAttribute('data-scene-renders', { timeout: 5_000 });
  308 |             await waitForChartUpdate(elements.nth(i));
  309 |         }
  310 |     }
  311 | }
  312 | 
  313 | export async function waitForChartUpdate(wrapper: Locator) {
  314 |     await expect(wrapper).toHaveAttribute('data-update-pending', 'false', { timeout: 5_000 });
  315 |     await expect(wrapper).toHaveAttribute('data-animating', 'false', { timeout: 5_000 });
  316 | }
  317 | 
  318 | export async function getAnimationTime(wrapper: Locator): Promise<number> {
  319 |     const timeAttr = await wrapper.getAttribute('data-animation-time-ms');
  320 |     return timeAttr == null || timeAttr === '' ? 0 : parseFloat(timeAttr);
  321 | }
  322 | 
  323 | export async function expectAnimationOccurred(wrapper: Locator, minTimeMs: number = 10) {
  324 |     const animationTime = await getAnimationTime(wrapper);
  325 |     expect(animationTime).toBeGreaterThan(minTimeMs);
  326 | }
  327 | 
  328 | // `.ag-charts-canvas-proxy` is `pointer-events: none`, so Playwright's hit-test resolves to <html> and
  329 | // `locator.hover()` times out on WebKit; move the mouse directly, as `dragCanvas` below does.
  330 | export async function hoverCanvas(page: Page, position: { x: number; y: number }) {
  331 |     const point = await canvasToPageTransformer(page);
  332 |     const p = point(position.x, position.y);
  333 |     await page.mouse.move(p.x, p.y);
  334 | }
  335 | 
  336 | // The in-built `page.dragAndDrop()` methods do not trigger our canvas drag events
  337 | export async function dragCanvas(
  338 |     page: Page,
  339 |     start: { x: number; y: number },
  340 |     end: { x: number; y: number },
  341 |     // `stepDelay` paces the moves. Panning only engages once the chart has processed a move, so a drag
  342 |     // whose moves arrive back-to-back is swallowed and the chart never moves.
  343 |     options: { steps?: number; stepDelay?: number } = {}
  344 | ) {
  345 |     const { steps = 4, stepDelay = 0 } = options;
  346 |     const point = await canvasToPageTransformer(page);
  347 |     let p = point(start.x, start.y);
  348 | 
  349 |     await page.mouse.move(p.x, p.y);
  350 |     await page.mouse.down();
  351 |     for (let step = 0; step < steps; step++) {
  352 |         const x = start.x + ((end.x - start.x) * step) / steps;
  353 |         const y = start.y + ((end.y - start.y) * step) / steps;
  354 |         p = point(x, y);
  355 |         await page.mouse.move(Math.round(p.x), Math.round(p.y));
  356 |         if (stepDelay > 0) await delay(stepDelay);
  357 |     }
  358 |     await page.mouse.up();
  359 | }
  360 | 
  361 | export async function locateCanvas(page: Page) {
  362 |     const canvasElem = page.locator('canvas');
  363 |     const canvas = page.locator(SELECTORS.canvasProxy);
  364 |     const wrapper = page.locator(SELECTORS.wrapper);
  365 |     const width = Number(await canvasElem.getAttribute('width'));
  366 |     const height = Number(await canvasElem.getAttribute('height'));
  367 |     const bbox = await canvas.boundingBox();
  368 | 
  369 |     if ([width, height].some((n) => [-Infinity, 0, Infinity].includes(n) || Number.isNaN(n))) {
  370 |         throw new Error(`Invalid canvasDims: { width: ${width}, height: ${height} }`);
  371 |     }
  372 |     if (bbox == null) {
  373 |         throw new Error(`Invalid canvas bbox!`);
  374 |     }
  375 | 
  376 |     return { wrapper, canvas, width, height, bbox };
  377 | }
  378 | 
  379 | type PointTransformer = (x: number, y: number) => { x: number; y: number };
  380 | 
  381 | export async function canvasToPageTransformer(page: Page): Promise<PointTransformer> {
  382 |     const offset = await (await page.$(SELECTORS.canvasProxy))?.boundingBox();
  383 |     if (!offset) throw new Error("Couldn't get the canvas bbox");
  384 |     return (x: number, y: number) => {
  385 |         return { x: offset.x + x, y: offset.y + y };
  386 |     };
  387 | }
  388 | 
  389 | export async function delay(ms: number) {
  390 |     return new Promise((resolve) => setTimeout(resolve, ms));
  391 | }
  392 | 
  393 | export async function readSwapchainText(page: Page): Promise<string | null> {
  394 |     const activeAnnouncer = page.locator('.ag-charts-series-area [aria-hidden="false"]');
```