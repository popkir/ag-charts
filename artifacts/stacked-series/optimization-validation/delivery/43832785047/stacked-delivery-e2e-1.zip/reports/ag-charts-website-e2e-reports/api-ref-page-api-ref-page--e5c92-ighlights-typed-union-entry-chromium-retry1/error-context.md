# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> direct bar series hash loads and highlights typed union entry
- Location: e2e/api-ref-page.spec.ts:284:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('pre code').locator('.highlight').filter({ hasText: /type\s*= 'bar'/ })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('pre code').locator('.highlight').filter({ hasText: /type\s*= 'bar'/ })

```

```yaml
- checkbox "Use dark theme"
- text: Use dark theme
- banner:
  - heading "Error" [level=2]
  - heading "An error occurred." [level=1]
- text: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
- heading "server/getInterfacesReference.ts:12:26" [level=2]
- button "Open in editor"
- code: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types'; import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages'; import { pathJoin } from '@utils/pathJoin'; import { readFileSync } from 'node:fs'; import { entries } from 'ag-charts-core'; type DevFileKey = keyof typeof DEV_FILE_PATH_MAP; function getJsonFromDevFile(devFileKey: DevFileKey) { const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]); const fileContents = readFileSync(file).toString(); ^ return fileContents === '' ? null : JSON.parse(fileContents); } /** * Get interfaces reference from the file system * * For static site generation */ export function getInterfacesReference() { const jsonContent = getJsonFromDevFile('resolved-interfaces.json'); return new Map(entries(jsonContent)) as ApiReferenceType; }"
- heading "Stack Trace" [level=2]
- text: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at Module.getStaticPaths (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options/[...memberName]/[type].astro:3:1) at callGetStaticPaths (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/route-cache.js:19:27) at getProps (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/params-and-props.js:13:9) at matchRoute (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/routing/dev.js:15:13) at async DevFacadeApp.devMatch (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/app/dev-facade.js:16:23) at async run (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:43:9) at async runWithErrorHandling (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-astro-server/controller.js:63:3) at async handleDevRequest (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:39:3)"
```

```
Error: expect(received).toHaveLength(expected)

Expected length: 0
Received length: 1
Received array:  ["Failed to load resource: the server responded with a status of 500 (Internal Server Error)"]
```

# Test source

```ts
  55  | }
  56  | 
  57  | /**
  58  |  * Pins non-Chromium browsers (Firefox, WebKit) to the `vanilla` framework variant.
  59  |  *
  60  |  * Call as a describe-level modifier inside the per-framework `test.describe`, passing that
  61  |  * describe's framework. Chromium keeps the full framework sweep; Firefox and WebKit run the vanilla
  62  |  * variant only, on every CI event type — their value is browser-engine coverage, which the other
  63  |  * five variants of the same example re-render identically.
  64  |  *
  65  |  * The modifier form (rather than a `test.skip(...)` call in the test body) means a skipped variant
  66  |  * never creates a browser context, so the skip costs nothing.
  67  |  */
  68  | export function pinNonChromiumToVanilla(
  69  |     testFn: { skip: (condition: (args: { browserName: string }) => boolean, description: string) => void },
  70  |     framework: string
  71  | ) {
  72  |     testFn.skip(
  73  |         ({ browserName }) => browserName !== 'chromium' && framework !== 'vanilla',
  74  |         'Non-Chromium browsers cover the vanilla variant only'
  75  |     );
  76  | }
  77  | 
  78  | export function setupIntrinsicAssertions(
  79  |     testFn: {
  80  |         beforeEach: (fn: ({ page }: { page: Page }, testInfo: { titlePath?: string[] }) => Promise<void>) => void;
  81  |         afterEach: (fn: () => void) => void;
  82  |     },
  83  |     opts: { viewportSize?: { width: number; height: number }; ignoreConsolePatterns?: string[] } = {}
  84  | ) {
  85  |     let consoleWarnOrErrors: string[] = [];
  86  |     const config = { ignore404s: false, ignoreConsoleWarnings: false };
  87  | 
  88  |     function titlePathIncludes(testInfo: { titlePath?: string[] }, searchString: string): boolean {
  89  |         for (const pathComponent of testInfo.titlePath ?? []) {
  90  |             if (pathComponent.includes(searchString)) {
  91  |                 return true;
  92  |             }
  93  |         }
  94  |         return false;
  95  |     }
  96  | 
  97  |     testFn.beforeEach(async ({ page }, testInfo) => {
  98  |         consoleWarnOrErrors = [];
  99  |         config.ignore404s = titlePathIncludes(testInfo, 'should 404 on') || titlePathIncludes(testInfo, '[ignore404s]');
  100 |         config.ignoreConsoleWarnings = titlePathIncludes(testInfo, '[ignoreConsoleWarnings]');
  101 | 
  102 |         if (opts?.viewportSize) {
  103 |             await page.setViewportSize(opts.viewportSize);
  104 |         }
  105 | 
  106 |         page.on('console', (msg: any) => {
  107 |             // Chrome emits violations/interventions as 'log', so they need capturing separately.
  108 |             if (msg.type() === 'log') {
  109 |                 const text = msg.text();
  110 |                 if (text.startsWith('[Violation]') || text.startsWith('[Intervention]')) {
  111 |                     consoleWarnOrErrors.push(text);
  112 |                 }
  113 |                 return;
  114 |             }
  115 | 
  116 |             if (msg.type() !== 'warning' && msg.type() !== 'error') return;
  117 | 
  118 |             // AG Charts licence banner.
  119 |             if (msg.text().startsWith('*')) return;
  120 | 
  121 |             if (msg.text().includes('This page is in Quirks Mode')) return;
  122 | 
  123 |             // Caller-supplied patterns to ignore (e.g. staging-specific noise not relevant to other specs).
  124 |             // Matched against the resource URL as well as the text: a failed request reports only
  125 |             // its status, so the URL is the only thing naming what actually failed.
  126 |             const messageText: string = msg.text();
  127 |             const resourceUrl: string = msg.location().url;
  128 |             if (opts.ignoreConsolePatterns?.some((p) => messageText.includes(p) || resourceUrl.includes(p))) {
  129 |                 return;
  130 |             }
  131 | 
  132 |             // Browser/OS noise.
  133 |             if (msg.text().includes('GL Driver Message')) return;
  134 | 
  135 |             // Emitted when a third-party script probes a feature the server-level policy disallows.
  136 |             if (msg.text().includes('Permissions policy violation')) return;
  137 | 
  138 |             const notFoundMatcher = /the server responded with a status of 404/;
  139 |             if (msg.location().url.includes('/favicon.ico')) return;
  140 |             if (notFoundMatcher.test(msg.text())) {
  141 |                 if (config.ignore404s) return;
  142 |                 expect(`${msg.location().url} - ${msg.text()}`).not.toMatch(notFoundMatcher);
  143 |             }
  144 | 
  145 |             consoleWarnOrErrors.push(msg.text());
  146 |         });
  147 | 
  148 |         page.on('pageerror', (err: any) => {
  149 |             consoleWarnOrErrors.push(err.message);
  150 |         });
  151 |     });
  152 | 
  153 |     testFn.afterEach(() => {
  154 |         if (!config.ignoreConsoleWarnings) {
> 155 |             expect(consoleWarnOrErrors).toHaveLength(0);
      |                                         ^ Error: expect(received).toHaveLength(expected)
  156 |         }
  157 |     });
  158 | 
  159 |     return {
  160 |         ...config,
  161 |     };
  162 | }
  163 | 
  164 | const ignoreMessageRegexes = [
  165 |     // Vite messages
  166 |     /^\[vite].*/,
  167 |     // Astro dev-server debug output, e.g. the client router's "Initializing prefetch script".
  168 |     // Emitted via debug() and so absent from a production build.
  169 |     /^\[astro].*/,
  170 |     // AG Charts license error message
  171 |     /^\*.*/,
  172 | ];
  173 | export function createConsoleLogs() {
  174 |     const consoleLogs: string[] = [];
  175 |     const clear = () => {
  176 |         consoleLogs.length = 0;
  177 |     };
  178 | 
  179 |     test.beforeEach(({ page }) => {
  180 |         page.on('console', (msg) => {
  181 |             const text = msg.text();
  182 |             const ignore = ignoreMessageRegexes.some((regex) => regex.test(text));
  183 |             if (ignore) {
  184 |                 return;
  185 |             }
  186 | 
  187 |             consoleLogs.push(text);
  188 |         });
  189 |     });
  190 | 
  191 |     test.afterEach(() => {
  192 |         clear();
  193 |     });
  194 | 
  195 |     return {
  196 |         clear,
  197 |         async expectLogs(calls: string[]) {
  198 |             const expectedCount: number = calls.length;
  199 |             await expect
  200 |                 .poll(() => consoleLogs.length, { message: `Waiting for ${expectedCount} console logs` })
  201 |                 .toBeGreaterThanOrEqual(expectedCount);
  202 |             expect(consoleLogs).toEqual(calls);
  203 |         },
  204 |         getLogs() {
  205 |             return consoleLogs;
  206 |         },
  207 |     };
  208 | }
  209 | 
  210 | // A variant of createConsoleLogs that offer more fine-tuned config & assertions
  211 | export function createConsoleTracker(page: Page) {
  212 |     type Message = {
  213 |         args: ReturnType<ConsoleMessage['args']>;
  214 |         text: ReturnType<ConsoleMessage['text']>;
  215 |         type: ReturnType<ConsoleMessage['type']>;
  216 |     };
  217 |     type ConsoleTracker = {
  218 |         init(): void;
  219 |         teardown(): void;
  220 |         popMessages(expectedCount: number): Promise<Message[]>;
  221 |     };
  222 |     const messages: Message[] = [];
  223 |     function onConsoleMessage(msg: ConsoleMessage): void {
  224 |         const args = msg.args();
  225 |         const text = msg.text();
  226 |         const type = msg.type();
  227 |         const ignore = ignoreMessageRegexes.some((regex) => regex.test(text));
  228 |         if (!ignore) {
  229 |             messages.push({ type, args, text });
  230 |         }
  231 |     }
  232 | 
  233 |     const consoleTracker: ConsoleTracker = {
  234 |         init() {
  235 |             page.on('console', onConsoleMessage);
  236 |         },
  237 |         teardown() {
  238 |             page.off('console', onConsoleMessage);
  239 |         },
  240 |         async popMessages(expectedCount: number) {
  241 |             await waitForChartUpdate(page.locator(SELECTORS.wrapper));
  242 |             const pollopts = { message: `Waiting for ${expectedCount} console logs` };
  243 |             await expect.poll(() => messages.length, pollopts).toBeGreaterThanOrEqual(expectedCount);
  244 |             return messages.splice(0, messages.length);
  245 |         },
  246 |     };
  247 |     return consoleTracker;
  248 | }
  249 | 
  250 | export async function repeat(repCount: number, fn: () => Promise<void>): Promise<void>;
  251 | export function repeat(repCount: number, fn: () => void): void;
  252 | export async function repeat(repCount: number, fn: () => void | Promise<void>): Promise<void> {
  253 |     for (let i = 0; i < repCount; i++) {
  254 |         await fn();
  255 |     }
```