# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> links a nested contextMenu items row back to its ancestor
- Location: e2e/api-ref-page.spec.ts:379:9

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.original: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#reference-AgChartOptions-contextMenu-items-axis-items').getByRole('link', { name: 'Recursive, see contextMenu.items' })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e4]:
        - link "Home" [ref=e6] [cursor=pointer]:
          - /url: /
          - img [ref=e7]
          - img [ref=e9]
        - button "Products" [ref=e24] [cursor=pointer]: Products
        - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page." [ref=e28] [cursor=pointer]:
          - img [ref=e29]
          - generic [ref=e31]: Search
          - generic [ref=e32]: Ctrl K
        - navigation [ref=e35]:
          - list [ref=e36]:
            - listitem [ref=e37]:
              - link "AG Charts Examples" [ref=e38] [cursor=pointer]:
                - /url: /examples/
                - text: Examples
            - listitem [ref=e39]:
              - link "AG Charts Gallery" [ref=e40] [cursor=pointer]:
                - /url: /gallery/
                - text: Gallery
            - listitem [ref=e41]:
              - link "AG Charts Theme Builder" [ref=e42] [cursor=pointer]:
                - /url: /theme-builder/
                - text: Theme Builder
            - listitem [ref=e43]:
              - link "AG Charts Docs" [ref=e44] [cursor=pointer]:
                - /url: /react/quick-start/
                - text: Docs
            - listitem [ref=e45]:
              - link "AG Charts API" [ref=e46] [cursor=pointer]:
                - /url: /options/
                - text: API
            - listitem [ref=e47]:
              - link "AG Charts Community" [ref=e48] [cursor=pointer]:
                - /url: /community/
                - text: Community
            - listitem [ref=e49]:
              - link "AG Charts Pricing" [ref=e50] [cursor=pointer]:
                - /url: /license-pricing/
                - text: Pricing
            - listitem [ref=e51]:
              - link "AG Charts Contact Us" [ref=e52] [cursor=pointer]:
                - /url: /contact/
                - text: Contact Us
            - listitem [ref=e53]:
              - link "AG Charts GitHub" [ref=e54] [cursor=pointer]:
                - /url: https://github.com/ag-grid/ag-charts
                - img [ref=e55]
            - listitem [ref=e57]:
              - button "Dark mode selector" [ref=e58] [cursor=pointer]
    - navigation [ref=e64]:
      - list [ref=e65]:
        - listitem [ref=e66]:
          - link "Options API" [ref=e67] [cursor=pointer]:
            - /url: /options/
        - listitem [ref=e68]:
          - link "Themes API" [ref=e69] [cursor=pointer]:
            - /url: /themes-api/
        - listitem [ref=e70]:
          - link "Theme Parameters" [ref=e71] [cursor=pointer]:
            - /url: /theme-parameters-api/
        - listitem [ref=e72]:
          - link "Chart API" [ref=e73] [cursor=pointer]:
            - /url: /react/api-create-update/
        - listitem [ref=e74]:
          - link "Events API" [ref=e75] [cursor=pointer]:
            - /url: /react/events/
        - listitem [ref=e76]:
          - link "Download API" [ref=e77] [cursor=pointer]:
            - /url: /react/api-download/
        - listitem [ref=e78]:
          - link "State API" [ref=e79] [cursor=pointer]:
            - /url: /react/api-state/
        - listitem [ref=e80]:
          - link "Context API" [ref=e81] [cursor=pointer]:
            - /url: /react/context/
        - listitem [ref=e82]:
          - link "TypeScript Generics" [ref=e83] [cursor=pointer]:
            - /url: /react/ts-generics/
    - main [ref=e84]
  - generic [ref=e88]:
    - generic [ref=e89]:
      - checkbox "Use dark theme" [ref=e90]
      - generic [ref=e91] [cursor=pointer]:
        - img [ref=e92]
        - img [ref=e96]
        - generic [ref=e100]: Use dark theme
    - banner [ref=e101]:
      - generic [ref=e102]:
        - heading "Error" [level=2] [ref=e103]
        - heading "An error occurred." [level=1] [ref=e104]
      - img [ref=e107]
    - generic [ref=e111]:
      - img [ref=e113]
      - generic [ref=e115]: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
    - generic [ref=e116]:
      - generic [ref=e117]:
        - heading "server/getInterfacesReference.ts:12:26" [level=2] [ref=e118]
        - button "Open in editor" [ref=e120]:
          - text: Open in editor
          - img [ref=e121]
      - code [ref=e126]:
        - generic [ref=e127]: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types';"
        - generic [ref=e128]: "import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages';"
        - generic [ref=e129]: "import { pathJoin } from '@utils/pathJoin';"
        - generic [ref=e130]: "import { readFileSync } from 'node:fs';"
        - generic [ref=e132]: "import { entries } from 'ag-charts-core';"
        - generic [ref=e134]: type DevFileKey = keyof typeof DEV_FILE_PATH_MAP;
        - generic [ref=e136]: "function getJsonFromDevFile(devFileKey: DevFileKey) {"
        - generic [ref=e137]: const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]);
        - generic [ref=e138]: const fileContents = readFileSync(file).toString();
        - generic [ref=e139]: ^
        - generic [ref=e140]: "return fileContents === '' ? null : JSON.parse(fileContents);"
        - generic [ref=e141]: "}"
        - generic [ref=e143]: /**
        - generic [ref=e144]: "* Get interfaces reference from the file system"
        - generic [ref=e145]: "*"
        - generic [ref=e146]: "* For static site generation"
        - generic [ref=e147]: "*/"
        - generic [ref=e148]: "export function getInterfacesReference() {"
        - generic [ref=e149]: const jsonContent = getJsonFromDevFile('resolved-interfaces.json');
        - generic [ref=e150]: return new Map(entries(jsonContent)) as ApiReferenceType;
        - generic [ref=e151]: "}"
    - generic [ref=e153]:
      - generic [ref=e154]:
        - heading "Stack Trace" [level=2] [ref=e155]
        - img [ref=e157] [cursor=pointer]
      - generic [ref=e161]: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at Module.getStaticPaths (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options/[...memberName]/[type].astro:3:1) at callGetStaticPaths (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/route-cache.js:19:27) at getProps (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/params-and-props.js:13:9) at matchRoute (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/routing/dev.js:15:13) at async DevFacadeApp.devMatch (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/app/dev-facade.js:16:23) at async run (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:43:9) at async runWithErrorHandling (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-astro-server/controller.js:63:3) at async handleDevRequest (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:39:3)"
```

# Test source

```ts
  1   | import { Page, test as base, expect } from '@playwright/test';
  2   | 
  3   | const LOCATOR_ACTIONS = new Set([
  4   |     'click',
  5   |     'dblclick',
  6   |     'tap',
  7   |     'fill',
  8   |     'press',
  9   |     'pressSequentially',
  10  |     'selectOption',
  11  |     'setChecked',
  12  |     'setInputFiles',
  13  |     'check',
  14  |     'uncheck',
  15  |     'hover',
  16  |     'focus',
  17  |     'blur',
  18  |     'dragTo',
  19  | ]);
  20  | 
  21  | const LOCATOR_FACTORIES = new Set([
  22  |     'first',
  23  |     'last',
  24  |     'nth',
  25  |     'locator',
  26  |     'getByText',
  27  |     'getByRole',
  28  |     'getByLabel',
  29  |     'getByPlaceholder',
  30  |     'getByTestId',
  31  |     'getByTitle',
  32  |     'getByAltText',
  33  |     'filter',
  34  |     'and',
  35  |     'or',
  36  | ]);
  37  | 
  38  | // A chart wrapper whose stability attributes are missing or not yet both 'false'.
  39  | const UNSETTLED_CHART = '.ag-charts-wrapper:not([data-update-pending="false"][data-animating="false"])';
  40  | 
  41  | export async function waitForCharts(page: Page) {
  42  |     // rAF then setTimeout(0): lets rAF-scheduled chart updates start and DOMElementProxy's deferred
  43  |     // DOM flush run, so the stability attributes are not read before an animation is scheduled.
  44  |     await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => setTimeout(resolve, 0))));
  45  |     // One page-wide count rather than a locator per wrapper: the site's ClientRouter swaps in the
  46  |     // next page after a link click, so a wrapper listed on the outgoing page can vanish mid-wait.
  47  |     await expect(page.locator(UNSETTLED_CHART)).toHaveCount(0, { timeout: 10_000 });
  48  | }
  49  | 
  50  | function stabilityProxy(page: Page, instance: any) {
  51  |     return new Proxy(instance, {
  52  |         get(target, prop, receiver) {
  53  |             const value = target[prop];
  54  |             if (value instanceof Function) {
  55  |                 return async function (...args: unknown[]) {
  56  |                     await waitForCharts(page);
  57  |                     const result = target[prop].apply(this === receiver ? target : this, args);
  58  |                     await waitForCharts(page);
  59  |                     return result;
  60  |                 };
  61  |             }
  62  |             return value;
  63  |         },
  64  |     });
  65  | }
  66  | 
  67  | function stableLocator(page: Page, locator: any): any {
  68  |     for (const action of LOCATOR_ACTIONS) {
  69  |         if (typeof locator[action] === 'function') {
  70  |             const original = locator[action].bind(locator);
  71  |             locator[action] = async function (...args: unknown[]) {
  72  |                 await waitForCharts(page);
> 73  |                 const result = await original(...args);
      |                                      ^ Error: locator.original: Test timeout of 30000ms exceeded.
  74  |                 await waitForCharts(page);
  75  |                 return result;
  76  |             };
  77  |         }
  78  |     }
  79  | 
  80  |     for (const factory of LOCATOR_FACTORIES) {
  81  |         if (typeof locator[factory] === 'function') {
  82  |             const original = locator[factory].bind(locator);
  83  |             locator[factory] = function (...args: unknown[]) {
  84  |                 return stableLocator(page, original(...args));
  85  |             };
  86  |         }
  87  |     }
  88  | 
  89  |     return locator;
  90  | }
  91  | 
  92  | const PAGE_LOCATOR_METHODS = [
  93  |     'locator',
  94  |     'getByText',
  95  |     'getByRole',
  96  |     'getByLabel',
  97  |     'getByPlaceholder',
  98  |     'getByTestId',
  99  |     'getByTitle',
  100 |     'getByAltText',
  101 | ] as const;
  102 | 
  103 | export const test = base.extend({
  104 |     page: ({ page }, use) => {
  105 |         Object.assign(page, {
  106 |             mouse: stabilityProxy(page, page.mouse),
  107 |             keyboard: stabilityProxy(page, page.keyboard),
  108 |             touchscreen: stabilityProxy(page, page.touchscreen),
  109 |         });
  110 | 
  111 |         for (const method of PAGE_LOCATOR_METHODS) {
  112 |             const original = (page as any)[method].bind(page);
  113 |             (page as any)[method] = function (...args: unknown[]) {
  114 |                 return stableLocator(page, original(...args));
  115 |             };
  116 |         }
  117 | 
  118 |         use(page);
  119 |     },
  120 | });
  121 | 
  122 | export { expect };
  123 | 
```