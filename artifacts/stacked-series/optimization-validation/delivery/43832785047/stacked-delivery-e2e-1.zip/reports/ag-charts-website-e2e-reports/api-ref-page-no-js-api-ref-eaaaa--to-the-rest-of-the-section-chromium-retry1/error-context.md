# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page-no-js.spec.ts >> api-ref-page without JavaScript >> reference page links to the rest of the section
- Location: e2e/api-ref-page-no-js.spec.ts:47:9

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('navigation', { name: 'Options API reference' }).getByRole('link', { name: 'series[type=\'bar\']', exact: true })
Expected: "page"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for getByRole('navigation', { name: 'Options API reference' }).getByRole('link', { name: 'series[type=\'bar\']', exact: true })

```

# Test source

```ts
  1  | import { type Page, expect, test } from '@playwright/test';
  2  | 
  3  | import { toPageUrl } from './util';
  4  | 
  5  | // The shared fixture and `gotoUrl` evaluate script in the page, which never resolves with JavaScript
  6  | // disabled, so these tests use Playwright's own `test` and `page.goto`.
  7  | test.use({ javaScriptEnabled: false, viewport: { width: 1400, height: 900 } });
  8  | 
  9  | function getFallbackNav(page: Page, section: 'Options' | 'Themes' = 'Options') {
  10 |     return page.getByRole('navigation', { name: `${section} API reference` });
  11 | }
  12 | 
  13 | function getNavLink(page: Page, name: string, section?: 'Options' | 'Themes') {
  14 |     return getFallbackNav(page, section).getByRole('link', { name, exact: true });
  15 | }
  16 | 
  17 | test.describe('api-ref-page without JavaScript', () => {
  18 |     test('options root links to each reference page', async ({ page }) => {
  19 |         await page.goto(toPageUrl('options/'), { waitUntil: 'domcontentloaded' });
  20 | 
  21 |         await expect(getNavLink(page, 'options')).toHaveAttribute('aria-current', 'page');
  22 |         await expect(getNavLink(page, "series[type='bar']")).toHaveAttribute('href', /\/options\/series\/bar\/$/);
  23 |         await expect(getNavLink(page, "axes.key[type='number']")).toHaveAttribute('href', /\/options\/axes\/number\/$/);
  24 |         // Past the depth cut-off, but kept because it is a page of its own.
  25 |         await expect(getNavLink(page, "navigator.miniChart.series[type='line']")).toHaveAttribute(
  26 |             'href',
  27 |             /\/options\/navigator\/miniChart\/series\/line\/$/
  28 |         );
  29 |     });
  30 | 
  31 |     test('options root links to its own properties', async ({ page }) => {
  32 |         await page.goto(toPageUrl('options/'), { waitUntil: 'domcontentloaded' });
  33 | 
  34 |         const nav = getFallbackNav(page);
  35 |         await expect(nav.locator('a[href$="/options/#reference-AgChartOptions-data"]')).toHaveText('data');
  36 |         await expect(nav.locator('a[href$="/options/#reference-AgChartOptions-legend-item"]')).toHaveText('item');
  37 |         await expect(page.locator('#reference-AgChartOptions-data')).toBeAttached();
  38 |     });
  39 | 
  40 |     test('options root renders a target for each nested link', async ({ page }) => {
  41 |         await page.goto(toPageUrl('options/'), { waitUntil: 'domcontentloaded' });
  42 | 
  43 |         await expect(page.locator('#reference-AgChartOptions-legend-item')).toBeAttached();
  44 |         await expect(page.locator('#reference-AgChartOptions-navigator-miniChart-series')).toBeAttached();
  45 |     });
  46 | 
  47 |     test('reference page links to the rest of the section', async ({ page }) => {
  48 |         await page.goto(toPageUrl('options/series/bar/'), { waitUntil: 'domcontentloaded' });
  49 | 
  50 |         const nav = getFallbackNav(page);
> 51 |         await expect(getNavLink(page, "series[type='bar']")).toHaveAttribute('aria-current', 'page');
     |                                                              ^ Error: expect(locator).toHaveAttribute(expected) failed
  52 |         await expect(getNavLink(page, 'options')).toHaveAttribute('href', /\/options\/$/);
  53 |         await expect(nav.locator('a[href$="/options/series/bar/#reference-AgBarSeriesOptions-fill"]')).toHaveText(
  54 |             'fill'
  55 |         );
  56 | 
  57 |         await getNavLink(page, "series[type='line']").click();
  58 |         await expect(page).toHaveURL(/\/options\/series\/line\/$/);
  59 |         await expect(page.locator('h1')).toContainText('line');
  60 |     });
  61 | 
  62 |     test('themes root links to its own properties', async ({ page }) => {
  63 |         await page.goto(toPageUrl('themes-api/'), { waitUntil: 'domcontentloaded' });
  64 | 
  65 |         const nav = getFallbackNav(page, 'Themes');
  66 |         await expect(getNavLink(page, 'theme', 'Themes')).toHaveAttribute('aria-current', 'page');
  67 |         await expect(nav.locator('a[href$="/themes-api/#reference-AgChartTheme-palette-fills"]')).toHaveText('fills');
  68 |         await expect(nav.locator('a[href$="/themes-api/#reference-AgChartTheme-overrides-bar"]')).toHaveText('bar');
  69 |         await expect(page.locator('#reference-AgChartTheme-palette-fills')).toBeAttached();
  70 |     });
  71 | });
  72 | 
```