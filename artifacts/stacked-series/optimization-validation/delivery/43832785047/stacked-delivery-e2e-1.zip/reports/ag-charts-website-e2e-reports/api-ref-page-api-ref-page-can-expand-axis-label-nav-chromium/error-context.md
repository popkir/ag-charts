# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> can expand axis label nav
- Location: e2e/api-ref-page.spec.ts:80:9

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(received).toHaveLength(expected)

Expected length: 0
Received length: 1
Received array:  ["Failed to load resource: the server responded with a status of 500 (Internal Server Error)"]
```

```
Error: locator.evaluate: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.highlight').first()

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic [ref=e5]:
    - checkbox "Use dark theme" [ref=e6]
    - generic [ref=e7] [cursor=pointer]:
      - img [ref=e8]
      - img [ref=e12]
      - generic [ref=e16]: Use dark theme
  - banner [ref=e17]:
    - generic [ref=e18]:
      - heading "Error" [level=2] [ref=e19]
      - heading "An error occurred." [level=1] [ref=e20]
    - img [ref=e23]
  - generic [ref=e27]:
    - img [ref=e29]
    - generic [ref=e31]: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
  - generic [ref=e32]:
    - generic [ref=e33]:
      - heading "server/getInterfacesReference.ts:12:26" [level=2] [ref=e34]
      - button "Open in editor" [ref=e36]:
        - text: Open in editor
        - img [ref=e37]
    - code [ref=e42]:
      - generic [ref=e43]: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types';"
      - generic [ref=e44]: "import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages';"
      - generic [ref=e45]: "import { pathJoin } from '@utils/pathJoin';"
      - generic [ref=e46]: "import { readFileSync } from 'node:fs';"
      - generic [ref=e48]: "import { entries } from 'ag-charts-core';"
      - generic [ref=e50]: type DevFileKey = keyof typeof DEV_FILE_PATH_MAP;
      - generic [ref=e52]: "function getJsonFromDevFile(devFileKey: DevFileKey) {"
      - generic [ref=e53]: const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]);
      - generic [ref=e54]: const fileContents = readFileSync(file).toString();
      - generic [ref=e55]: ^
      - generic [ref=e56]: "return fileContents === '' ? null : JSON.parse(fileContents);"
      - generic [ref=e57]: "}"
      - generic [ref=e59]: /**
      - generic [ref=e60]: "* Get interfaces reference from the file system"
      - generic [ref=e61]: "*"
      - generic [ref=e62]: "* For static site generation"
      - generic [ref=e63]: "*/"
      - generic [ref=e64]: "export function getInterfacesReference() {"
      - generic [ref=e65]: const jsonContent = getJsonFromDevFile('resolved-interfaces.json');
      - generic [ref=e66]: return new Map(entries(jsonContent)) as ApiReferenceType;
      - generic [ref=e67]: "}"
  - generic [ref=e69]:
    - generic [ref=e70]:
      - heading "Stack Trace" [level=2] [ref=e71]
      - img [ref=e73] [cursor=pointer]
    - generic [ref=e77]: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at Module.getStaticPaths (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options/[...memberName]/[type].astro:3:1) at callGetStaticPaths (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/route-cache.js:19:27) at getProps (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/params-and-props.js:13:9) at matchRoute (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/routing/dev.js:15:13) at async DevFacadeApp.devMatch (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/app/dev-facade.js:16:23) at async run (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:43:9) at async runWithErrorHandling (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-astro-server/controller.js:63:3) at async handleDevRequest (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:39:3)"
```

# Test source

```ts
  1   | import type { Locator, Page } from '@playwright/test';
  2   | 
  3   | import { expect, test } from './fixture';
  4   | import { createConsoleLogs, gotoUrl, setupIntrinsicAssertions, toPageUrl } from './util';
  5   | 
  6   | test.use({ viewport: { width: 1400, height: 900 } });
  7   | 
  8   | const NAV_TREE_SELECTOR = 'pre code';
  9   | const PROPERTY_NAME_SELECTOR = '[class*="propertyName"]';
  10  | const PROPERTY_EXPANDER_SELECTOR = '[class*="propertyExpander"]';
  11  | const SEARCH_OPTION_SELECTOR = '[class*="searchOption"]';
  12  | const SEARCH_DROPDOWN_SELECTOR = '[class*="searchDropdown"]';
  13  | 
  14  | function getSearchInput(page: Page) {
  15  |     return page.getByPlaceholder('Search properties...');
  16  | }
  17  | 
  18  | function getNavigationTree(page: Page) {
  19  |     return page.locator(NAV_TREE_SELECTOR);
  20  | }
  21  | 
  22  | function getNavigationProperty(page: Page, matcher: string | RegExp): Locator {
  23  |     return getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR, { hasText: matcher }).first();
  24  | }
  25  | 
  26  | function getNavigationClickable(page: Page, matcher: string | RegExp): Locator {
  27  |     return getNavigationProperty(page, matcher).locator('a').first();
  28  | }
  29  | 
  30  | function getNavigationHighlight(page: Page, matcher: string | RegExp): Locator {
  31  |     return getNavigationTree(page).locator('.highlight', { hasText: matcher });
  32  | }
  33  | 
  34  | function getNavigationText(page: Page, text: string): Locator {
  35  |     return getNavigationTree(page).getByText(text, { exact: false });
  36  | }
  37  | 
  38  | async function expandNavNode(page: Page, matcher: string | RegExp) {
  39  |     const node = getNavigationProperty(page, matcher);
  40  |     await expect(node).toBeVisible();
  41  |     await node.locator(PROPERTY_EXPANDER_SELECTOR).click();
  42  | }
  43  | 
  44  | async function waitForApiReady(page: Page) {
  45  |     await expect(page.locator('header h1')).toContainText('AgChartOptions');
  46  |     await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  47  | }
  48  | 
  49  | function normaliseLabel(value: string) {
  50  |     return value.replace(/[^a-z0-9]+/gi, '').toLowerCase();
  51  | }
  52  | 
  53  | async function selectSearchOption(page: Page, text: string) {
  54  |     const options = page.locator(SEARCH_OPTION_SELECTOR);
  55  |     await expect(options).not.toHaveCount(0, { timeout: 10_000 });
  56  | 
  57  |     const target = normaliseLabel(text);
  58  |     const count = await options.count();
  59  |     let matchIndex = -1;
  60  |     for (let i = 0; i < count; i++) {
  61  |         const optionText = await options.nth(i).innerText();
  62  |         if (normaliseLabel(optionText).includes(target)) {
  63  |             matchIndex = i;
  64  |             break;
  65  |         }
  66  |     }
  67  | 
  68  |     expect(matchIndex).not.toBe(-1);
  69  | 
  70  |     for (let i = 0; i < matchIndex; i++) {
  71  |         await page.keyboard.press('ArrowDown');
  72  |     }
  73  | }
  74  | 
  75  | test.describe('api-ref-page', () => {
  76  |     const consoleLogs = createConsoleLogs();
  77  | 
  78  |     setupIntrinsicAssertions(test);
  79  | 
  80  |     test('can expand axis label nav', async ({ page }) => {
  81  |         await gotoUrl(page, toPageUrl('options/axes/number/#reference-AgNumberAxisOptions-label'));
  82  | 
  83  |         const highlight = page.locator('.highlight').first();
> 84  |         const siblingsBefore = await highlight.evaluate(countSiblings);
      |                                                ^ Error: locator.evaluate: Test timeout of 30000ms exceeded.
  85  | 
  86  |         await highlight.locator('svg').first().click();
  87  | 
  88  |         const siblingsAfter = await highlight.evaluate(countSiblings);
  89  |         expect(siblingsAfter).toBe(siblingsBefore + 2);
  90  | 
  91  |         await consoleLogs.expectLogs([
  92  |             '%cDownload the React DevTools for a better development experience: https://reactjs.org/link/react-devtools font-weight:bold',
  93  |         ]);
  94  |     });
  95  | 
  96  |     // setupIntrinsicAssertions guards the union's variant recursion through NodeFactory against a pageerror.
  97  |     test('expands the fill union into discrete variant types and their properties', async ({ page }) => {
  98  |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-fill'));
  99  |         await expect(getNavigationProperty(page, /^fill/)).toBeVisible();
  100 | 
  101 |         await page.getByRole('button', { name: 'See available interfaces of fill', exact: true }).click();
  102 | 
  103 |         const gradientVariant = page.locator('#reference-AgBarSeriesOptions-fill-gradient');
  104 |         await expect(gradientVariant).toBeVisible();
  105 |         await expect(gradientVariant).toContainText("fill[type='gradient']");
  106 |         const colorRefVariant = page.locator('#reference-AgBarSeriesOptions-fill-AgColorRefMixOntoColor');
  107 |         await expect(colorRefVariant).toContainText('fill[AgColorRefMixOntoColor]');
  108 | 
  109 |         // The signature code block (`-details`) belongs to the separate "See more details" affordance and stays absent here.
  110 |         await page.getByRole('button', { name: 'See child properties of gradient', exact: true }).click();
  111 |         await expect(page.locator('#reference-AgBarSeriesOptions-fill-gradient-rotation')).toBeVisible();
  112 |         await expect(page.locator('#reference-AgBarSeriesOptions-fill-details')).toHaveCount(0);
  113 |     });
  114 | 
  115 |     test('deep links into a fill union variant property and auto-expands the chain', async ({ page }) => {
  116 |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-fill-gradient-rotation'));
  117 | 
  118 |         // Landing on the deep hash expands fill -> gradient and scrolls to the variant sub-property.
  119 |         const rotation = page.locator('#reference-AgBarSeriesOptions-fill-gradient-rotation');
  120 |         await expect(rotation).toBeVisible();
  121 |     });
  122 | 
  123 |     // The themes API search index is far larger than the options page's, so building it must not
  124 |     // exceed V8's argument limit; setupIntrinsicAssertions fails the test on the resulting pageerror.
  125 |     test('themes API page loads without overflowing', async ({ page }) => {
  126 |         await gotoUrl(page, toPageUrl('themes-api/'));
  127 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  128 |     });
  129 | 
  130 |     // Drilling overrides -> common -> axes renders every axis-type variant through the themeable
  131 |     // types, mirroring the options-page axis surface.
  132 |     test('themes API page expands the common axes node into its axis-type variants', async ({ page }) => {
  133 |         await gotoUrl(page, toPageUrl('themes-api/'));
  134 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  135 | 
  136 |         await expandNavNode(page, /^overrides/);
  137 |         await expandNavNode(page, /^common/);
  138 |         await expandNavNode(page, /^axes/);
  139 | 
  140 |         await expect(getNavigationProperty(page, /^number\b/)).toBeVisible();
  141 |     });
  142 | 
  143 |     // A per-series override (here `bar`) exposes a themeable `series` node. `\b` keeps the matcher
  144 |     // off the sibling `seriesArea` node.
  145 |     test('themes API page expands a series override into its themeable series properties', async ({ page }) => {
  146 |         await gotoUrl(page, toPageUrl('themes-api/'));
  147 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  148 | 
  149 |         await expandNavNode(page, /^overrides/);
  150 |         await expandNavNode(page, /^bar/);
  151 |         await expandNavNode(page, /^series\b/);
  152 | 
  153 |         await expect(getNavigationProperty(page, /^direction\b/)).toBeVisible();
  154 |     });
  155 | 
  156 |     test('shows fallback when search returns no matches', async ({ page }) => {
  157 |         await gotoUrl(page, toPageUrl('options/'));
  158 |         await waitForApiReady(page);
  159 | 
  160 |         const searchInput = getSearchInput(page);
  161 |         await searchInput.click();
  162 |         await searchInput.fill('definitely-no-match');
  163 | 
  164 |         await expect(
  165 |             page.getByText(`We couldn't find any matches for "definitely-no-match"`, { exact: false })
  166 |         ).toBeVisible();
  167 |     });
  168 | 
  169 |     test('navigates to bar series via search keyboard flow', async ({ page }) => {
  170 |         await gotoUrl(page, toPageUrl('options/'));
  171 |         await waitForApiReady(page);
  172 | 
  173 |         const searchInput = getSearchInput(page);
  174 |         await searchInput.click();
  175 |         await searchInput.fill('bar');
  176 | 
  177 |         await selectSearchOption(page, 'series type bar');
  178 |         await page.keyboard.press('Enter');
  179 | 
  180 |         // Selecting a result hands off to Astro's router, which swaps in the target document, so
  181 |         // the address bar catches up a tick after the keypress rather than during it.
  182 |         await page.waitForURL(/\/options\/series\/bar\/#reference-AgBarSeriesOptions-type$/);
  183 |         await expect(page.locator('header h1')).toContainText("type = 'bar'");
  184 |     });
```