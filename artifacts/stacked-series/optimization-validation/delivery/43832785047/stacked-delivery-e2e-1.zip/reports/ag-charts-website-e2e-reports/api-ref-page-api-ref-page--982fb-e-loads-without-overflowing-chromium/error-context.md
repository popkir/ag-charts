# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> themes API page loads without overflowing
- Location: e2e/api-ref-page.spec.ts:125:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('pre code').locator('[class*="propertyName"]').first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('pre code').locator('[class*="propertyName"]').first()

```

```yaml
- banner:
  - link "Home":
    - /url: /
    - img
    - img
  - button "Products"
  - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.": Search Ctrl K
  - navigation:
    - list:
      - listitem:
        - link "AG Charts Examples":
          - /url: /examples/
          - text: Examples
      - listitem:
        - link "AG Charts Gallery":
          - /url: /gallery/
          - text: Gallery
      - listitem:
        - link "AG Charts Theme Builder":
          - /url: /theme-builder/
          - text: Theme Builder
      - listitem:
        - link "AG Charts Docs":
          - /url: /react/quick-start/
          - text: Docs
      - listitem:
        - link "AG Charts API":
          - /url: /options/
          - text: API
      - listitem:
        - link "AG Charts Community":
          - /url: /community/
          - text: Community
      - listitem:
        - link "AG Charts Pricing":
          - /url: /license-pricing/
          - text: Pricing
      - listitem:
        - link "AG Charts Contact Us":
          - /url: /contact/
          - text: Contact Us
      - listitem:
        - link "AG Charts GitHub":
          - /url: https://github.com/ag-grid/ag-charts
      - listitem:
        - button "Dark mode selector"
- navigation:
  - list:
    - listitem:
      - link "Options API":
        - /url: /options/
    - listitem:
      - link "Themes API":
        - /url: /themes-api/
    - listitem:
      - link "Theme Parameters":
        - /url: /theme-parameters-api/
    - listitem:
      - link "Chart API":
        - /url: /react/api-create-update/
    - listitem:
      - link "Events API":
        - /url: /react/events/
    - listitem:
      - link "Download API":
        - /url: /react/api-download/
    - listitem:
      - link "State API":
        - /url: /react/api-state/
    - listitem:
      - link "Context API":
        - /url: /react/context/
    - listitem:
      - link "TypeScript Generics":
        - /url: /react/ts-generics/
- main
```

# Test source

```ts
  27  |     return getNavigationProperty(page, matcher).locator('a').first();
  28  | }
  29  | 
  30  | function getNavigationHighlight(page: Page, matcher: string | RegExp): Locator {
  31  |     return getNavigationTree(page).locator('.highlight', { hasText: matcher });
  32  | }
  33  | 
  34  | function getNavigationText(page: Page, text: string): Locator {
  35  |     return getNavigationTree(page).getByText(text, { exact: false });
  36  | }
  37  | 
  38  | async function expandNavNode(page: Page, matcher: string | RegExp) {
  39  |     const node = getNavigationProperty(page, matcher);
  40  |     await expect(node).toBeVisible();
  41  |     await node.locator(PROPERTY_EXPANDER_SELECTOR).click();
  42  | }
  43  | 
  44  | async function waitForApiReady(page: Page) {
  45  |     await expect(page.locator('header h1')).toContainText('AgChartOptions');
  46  |     await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  47  | }
  48  | 
  49  | function normaliseLabel(value: string) {
  50  |     return value.replace(/[^a-z0-9]+/gi, '').toLowerCase();
  51  | }
  52  | 
  53  | async function selectSearchOption(page: Page, text: string) {
  54  |     const options = page.locator(SEARCH_OPTION_SELECTOR);
  55  |     await expect(options).not.toHaveCount(0, { timeout: 10_000 });
  56  | 
  57  |     const target = normaliseLabel(text);
  58  |     const count = await options.count();
  59  |     let matchIndex = -1;
  60  |     for (let i = 0; i < count; i++) {
  61  |         const optionText = await options.nth(i).innerText();
  62  |         if (normaliseLabel(optionText).includes(target)) {
  63  |             matchIndex = i;
  64  |             break;
  65  |         }
  66  |     }
  67  | 
  68  |     expect(matchIndex).not.toBe(-1);
  69  | 
  70  |     for (let i = 0; i < matchIndex; i++) {
  71  |         await page.keyboard.press('ArrowDown');
  72  |     }
  73  | }
  74  | 
  75  | test.describe('api-ref-page', () => {
  76  |     const consoleLogs = createConsoleLogs();
  77  | 
  78  |     setupIntrinsicAssertions(test);
  79  | 
  80  |     test('can expand axis label nav', async ({ page }) => {
  81  |         await gotoUrl(page, toPageUrl('options/axes/number/#reference-AgNumberAxisOptions-label'));
  82  | 
  83  |         const highlight = page.locator('.highlight').first();
  84  |         const siblingsBefore = await highlight.evaluate(countSiblings);
  85  | 
  86  |         await highlight.locator('svg').first().click();
  87  | 
  88  |         const siblingsAfter = await highlight.evaluate(countSiblings);
  89  |         expect(siblingsAfter).toBe(siblingsBefore + 2);
  90  | 
  91  |         await consoleLogs.expectLogs([
  92  |             '%cDownload the React DevTools for a better development experience: https://reactjs.org/link/react-devtools font-weight:bold',
  93  |         ]);
  94  |     });
  95  | 
  96  |     // setupIntrinsicAssertions guards the union's variant recursion through NodeFactory against a pageerror.
  97  |     test('expands the fill union into discrete variant types and their properties', async ({ page }) => {
  98  |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-fill'));
  99  |         await expect(getNavigationProperty(page, /^fill/)).toBeVisible();
  100 | 
  101 |         await page.getByRole('button', { name: 'See available interfaces of fill', exact: true }).click();
  102 | 
  103 |         const gradientVariant = page.locator('#reference-AgBarSeriesOptions-fill-gradient');
  104 |         await expect(gradientVariant).toBeVisible();
  105 |         await expect(gradientVariant).toContainText("fill[type='gradient']");
  106 |         const colorRefVariant = page.locator('#reference-AgBarSeriesOptions-fill-AgColorRefMixOntoColor');
  107 |         await expect(colorRefVariant).toContainText('fill[AgColorRefMixOntoColor]');
  108 | 
  109 |         // The signature code block (`-details`) belongs to the separate "See more details" affordance and stays absent here.
  110 |         await page.getByRole('button', { name: 'See child properties of gradient', exact: true }).click();
  111 |         await expect(page.locator('#reference-AgBarSeriesOptions-fill-gradient-rotation')).toBeVisible();
  112 |         await expect(page.locator('#reference-AgBarSeriesOptions-fill-details')).toHaveCount(0);
  113 |     });
  114 | 
  115 |     test('deep links into a fill union variant property and auto-expands the chain', async ({ page }) => {
  116 |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-fill-gradient-rotation'));
  117 | 
  118 |         // Landing on the deep hash expands fill -> gradient and scrolls to the variant sub-property.
  119 |         const rotation = page.locator('#reference-AgBarSeriesOptions-fill-gradient-rotation');
  120 |         await expect(rotation).toBeVisible();
  121 |     });
  122 | 
  123 |     // The themes API search index is far larger than the options page's, so building it must not
  124 |     // exceed V8's argument limit; setupIntrinsicAssertions fails the test on the resulting pageerror.
  125 |     test('themes API page loads without overflowing', async ({ page }) => {
  126 |         await gotoUrl(page, toPageUrl('themes-api/'));
> 127 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
      |                                                                                       ^ Error: expect(locator).toBeVisible() failed
  128 |     });
  129 | 
  130 |     // Drilling overrides -> common -> axes renders every axis-type variant through the themeable
  131 |     // types, mirroring the options-page axis surface.
  132 |     test('themes API page expands the common axes node into its axis-type variants', async ({ page }) => {
  133 |         await gotoUrl(page, toPageUrl('themes-api/'));
  134 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  135 | 
  136 |         await expandNavNode(page, /^overrides/);
  137 |         await expandNavNode(page, /^common/);
  138 |         await expandNavNode(page, /^axes/);
  139 | 
  140 |         await expect(getNavigationProperty(page, /^number\b/)).toBeVisible();
  141 |     });
  142 | 
  143 |     // A per-series override (here `bar`) exposes a themeable `series` node. `\b` keeps the matcher
  144 |     // off the sibling `seriesArea` node.
  145 |     test('themes API page expands a series override into its themeable series properties', async ({ page }) => {
  146 |         await gotoUrl(page, toPageUrl('themes-api/'));
  147 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR).first()).toBeVisible();
  148 | 
  149 |         await expandNavNode(page, /^overrides/);
  150 |         await expandNavNode(page, /^bar/);
  151 |         await expandNavNode(page, /^series\b/);
  152 | 
  153 |         await expect(getNavigationProperty(page, /^direction\b/)).toBeVisible();
  154 |     });
  155 | 
  156 |     test('shows fallback when search returns no matches', async ({ page }) => {
  157 |         await gotoUrl(page, toPageUrl('options/'));
  158 |         await waitForApiReady(page);
  159 | 
  160 |         const searchInput = getSearchInput(page);
  161 |         await searchInput.click();
  162 |         await searchInput.fill('definitely-no-match');
  163 | 
  164 |         await expect(
  165 |             page.getByText(`We couldn't find any matches for "definitely-no-match"`, { exact: false })
  166 |         ).toBeVisible();
  167 |     });
  168 | 
  169 |     test('navigates to bar series via search keyboard flow', async ({ page }) => {
  170 |         await gotoUrl(page, toPageUrl('options/'));
  171 |         await waitForApiReady(page);
  172 | 
  173 |         const searchInput = getSearchInput(page);
  174 |         await searchInput.click();
  175 |         await searchInput.fill('bar');
  176 | 
  177 |         await selectSearchOption(page, 'series type bar');
  178 |         await page.keyboard.press('Enter');
  179 | 
  180 |         // Selecting a result hands off to Astro's router, which swaps in the target document, so
  181 |         // the address bar catches up a tick after the keypress rather than during it.
  182 |         await page.waitForURL(/\/options\/series\/bar\/#reference-AgBarSeriesOptions-type$/);
  183 |         await expect(page.locator('header h1')).toContainText("type = 'bar'");
  184 |     });
  185 | 
  186 |     test('clears search query after navigating to a result', async ({ page }) => {
  187 |         await gotoUrl(page, toPageUrl('options/'));
  188 |         await waitForApiReady(page);
  189 | 
  190 |         const searchInput = getSearchInput(page);
  191 |         await searchInput.click();
  192 |         await searchInput.fill('bar');
  193 |         await selectSearchOption(page, 'series type bar');
  194 |         await page.keyboard.press('Enter');
  195 | 
  196 |         await expect(getSearchInput(page)).toHaveValue('');
  197 |     });
  198 | 
  199 |     // `legend.position` is a union whose interface variant carries no string literal, so it is keyed
  200 |     // on the interface name in both the tree anchor and the search index.
  201 |     test('finds a property under a union variant that has no discriminator', async ({ page }) => {
  202 |         await gotoUrl(page, toPageUrl('options/'));
  203 |         await waitForApiReady(page);
  204 | 
  205 |         const searchInput = getSearchInput(page);
  206 |         await searchInput.click();
  207 |         await searchInput.fill('floating');
  208 | 
  209 |         await selectSearchOption(page, 'legend.position[AgChartLegendPositionOptions].floating');
  210 |         await page.keyboard.press('Enter');
  211 | 
  212 |         await page.waitForURL(/#reference-AgChartOptions-legend-position-AgChartLegendPositionOptions-floating$/);
  213 |         const floating = page.locator(
  214 |             '#reference-AgChartOptions-legend-position-AgChartLegendPositionOptions-floating'
  215 |         );
  216 |         await expect(floating).toBeVisible();
  217 |         await expect(floating).toContainText('legend.position[AgChartLegendPositionOptions].floating');
  218 |     });
  219 | 
  220 |     // The dropdown scrolls on both axes; wheeling vertically moves the pointer onto a new option,
  221 |     // and that selection must leave the horizontal scroll position alone.
  222 |     test('keeps the horizontal scroll position when scrolling the results vertically', async ({ page }) => {
  223 |         await gotoUrl(page, toPageUrl('options/'));
  224 |         await waitForApiReady(page);
  225 | 
  226 |         const searchInput = getSearchInput(page);
  227 |         await searchInput.click();
```