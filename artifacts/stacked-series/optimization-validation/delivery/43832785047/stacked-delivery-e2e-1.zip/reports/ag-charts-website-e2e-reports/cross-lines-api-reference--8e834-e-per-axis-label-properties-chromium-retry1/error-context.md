# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cross-lines-api-reference.spec.ts >> Cross Lines API reference >> AgAngleRangeCrossLineOptions >> documents the per-axis label properties
- Location: e2e/cross-lines-api-reference.spec.ts:41:17

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[tab-id="AgAngleRangeCrossLineOptions"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('[tab-id="AgAngleRangeCrossLineOptions"]')

```

```yaml
- banner:
  - link "Home":
    - /url: /
    - img
    - img
  - button "Products"
  - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.": Search Ctrl K
  - navigation:
    - list:
      - listitem:
        - link "AG Charts Examples":
          - /url: /examples/
          - text: Examples
      - listitem:
        - link "AG Charts Gallery":
          - /url: /gallery/
          - text: Gallery
      - listitem:
        - link "AG Charts Theme Builder":
          - /url: /theme-builder/
          - text: Theme Builder
      - listitem:
        - link "AG Charts Docs":
          - /url: /javascript/quick-start/
          - text: Docs
      - listitem:
        - link "AG Charts API":
          - /url: /options/
          - text: API
      - listitem:
        - link "AG Charts Community":
          - /url: /community/
          - text: Community
      - listitem:
        - link "AG Charts Pricing":
          - /url: /license-pricing/
          - text: Pricing
      - listitem:
        - link "AG Charts Contact Us":
          - /url: /contact/
          - text: Contact Us
      - listitem:
        - link "AG Charts GitHub":
          - /url: https://github.com/ag-grid/ag-charts
      - listitem:
        - button "Dark mode selector"
- main:
  - link "What's New":
    - /url: /whats-new/
  - heading "Getting started" [level=5]
  - link "Quick Start":
    - /url: /javascript/quick-start/
  - link "Key Features":
    - /url: /javascript/key-features/
  - link "Community vs. Enterprise":
    - /url: /javascript/community-vs-enterprise/
  - button "Setup"
  - button "Tutorials"
  - button "Security & Compatibility"
  - separator
  - heading "AI Features" [level=5]
  - link "Skills":
    - /url: /javascript/skills/
  - separator
  - heading "Core features" [level=5]
  - button "Data"
  - button "Axes"
  - button "Data Elements"
  - link "Cross Lines":
    - /url: /javascript/axes-cross-lines/
  - link "Legend":
    - /url: /javascript/legend/
  - link "Formatters":
    - /url: /javascript/formatters/
  - link "Stylers":
    - /url: /javascript/stylers/
  - link "Series Bars":
    - /url: /javascript/bars/
  - link "Series Fills":
    - /url: /javascript/fills/
  - link "Series Labels":
    - /url: /javascript/series-labels/
  - link "Series Markers":
    - /url: /javascript/markers/
  - link "Style Segments":
    - /url: /javascript/style-segments/
  - link "Annotations":
    - /url: /javascript/annotations/
  - link "Background Regions":
    - /url: /javascript/background-regions/
  - link "Colour Scale":
    - /url: /javascript/colour-scale/
  - link "Error Bars":
    - /url: /javascript/error-bars/
  - button "Interactivity"
  - button "Layout & Styling"
  - separator
  - heading "Specialised Charts" [level=5]
  - button "Financial Charts"
  - button "Maps"
  - link "Org Chart":
    - /url: /javascript/org-chart/
  - link "Quadrant Chart":
    - /url: /javascript/quadrant-chart/
  - separator
  - heading "Series" [level=5]
  - link "Bar":
    - /url: /javascript/bar-series/
  - link "Line":
    - /url: /javascript/line-series/
  - link "Area":
    - /url: /javascript/area-series/
  - link "Scatter":
    - /url: /javascript/scatter-series/
  - link "Bubble":
    - /url: /javascript/bubble-series/
  - link "Pie":
    - /url: /javascript/pie-series/
  - link "Donut":
    - /url: /javascript/donut-series/
  - link "Combination":
    - /url: /javascript/combination-series/
  - link "Box Plot":
    - /url: /javascript/box-plot-series/
  - link "Candlestick":
    - /url: /javascript/candlestick-series/
  - link "HLC":
    - /url: /javascript/hlc-series/
  - link "OHLC":
    - /url: /javascript/ohlc-series/
  - link "Heatmap":
    - /url: /javascript/heatmap-series/
  - link "Histogram":
    - /url: /javascript/histogram-series/
  - link "Nightingale":
    - /url: /javascript/nightingale-series/
  - link "Radar Area":
    - /url: /javascript/radar-area-series/
  - link "Radar Line":
    - /url: /javascript/radar-line-series/
  - link "Radial Bar":
    - /url: /javascript/radial-bar-series/
  - link "Radial Column":
    - /url: /javascript/radial-column-series/
  - link "Range Area":
    - /url: /javascript/range-area-series/
  - link "Range Bar":
    - /url: /javascript/range-bar-series/
  - link "Waterfall":
    - /url: /javascript/waterfall-series/
  - link "Sunburst":
    - /url: /javascript/sunburst-series/
  - link "Treemap":
    - /url: /javascript/treemap-series/
  - link "Sankey":
    - /url: /javascript/sankey-series/
  - link "Chord":
    - /url: /javascript/chord-series/
  - link "Funnel":
    - /url: /javascript/funnel-series/
  - link "Cone Funnel":
    - /url: /javascript/cone-funnel-series/
  - link "Pyramid":
    - /url: /javascript/pyramid-series/
  - separator
  - heading "Gauges" [level=5]
  - link "Radial Gauge":
    - /url: /javascript/radial-gauge/
  - link "Linear Gauge":
    - /url: /javascript/linear-gauge/
  - heading "JavaScript Charts Cross Lines" [level=1]
  - text: Version 15.0.0
  - button "AI Options"
  - combobox "Framework selector":
    - img "javascript logo"
    - text: JavaScript
  - navigation "Other framework versions of this page":
    - list:
      - listitem:
        - link "React Charts":
          - /url: /react/axes-cross-lines/
      - listitem:
        - link "Angular Charts":
          - /url: /angular/axes-cross-lines/
      - listitem:
        - link "Vue Charts":
          - /url: /vue/axes-cross-lines/
- checkbox "Use dark theme"
- text: Use dark theme
- banner:
  - heading "Error" [level=2]
  - heading "An error occurred." [level=1]
- text: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
- heading "server/getInterfacesReference.ts:12:26" [level=2]
- button "Open in editor"
- code: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types'; import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages'; import { pathJoin } from '@utils/pathJoin'; import { readFileSync } from 'node:fs'; import { entries } from 'ag-charts-core'; type DevFileKey = keyof typeof DEV_FILE_PATH_MAP; function getJsonFromDevFile(devFileKey: DevFileKey) { const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]); const fileContents = readFileSync(file).toString(); ^ return fileContents === '' ? null : JSON.parse(fileContents); } /** * Get interfaces reference from the file system * * For static site generation */ export function getInterfacesReference() { const jsonContent = getJsonFromDevFile('resolved-interfaces.json'); return new Map(entries(jsonContent)) as ApiReferenceType; }"
- heading "Stack Trace" [level=2]
- text: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/ApiReference.astro:15:1) at AstroComponentInstance.ApiReference (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:83:23 at Array.map (<anonymous>) at renderSlots (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:82:21) at renderFrameworkComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:66:3) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:358:5) at renderTreeNodeToFactoryResult (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:153:17) at factory (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:118:10) at AstroComponentInstance.eval (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at Slots.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/slots.js:62:22) at eval (/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/tabs/TabsWithHtmlChildren.astro:13:1) at AstroComponentInstance.TabsWithHtmlChildren (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:52:18 at new BufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:162:18) at createBufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:186:5) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:51:22)"
```

# Test source

```ts
  1  | import { expect, test } from './fixture';
  2  | import { gotoUrl, setupIntrinsicAssertions, toPageUrl } from './util';
  3  | 
  4  | test.use({ viewport: { width: 1400, height: 900 } });
  5  | 
  6  | const PAGE_URL = 'javascript/axes-cross-lines/';
  7  | 
  8  | const CARTESIAN = {
  9  |     labelType: 'AgCartesianCrossLineLabelOptions',
  10 |     present: ['placement', 'rotation'],
  11 |     absent: ['position', 'positionAngle'],
  12 | };
  13 | const ANGLE = {
  14 |     labelType: 'AgBaseCrossLineLabelOptions',
  15 |     present: ['text'],
  16 |     absent: ['position', 'placement', 'rotation', 'positionAngle'],
  17 | };
  18 | const RADIUS = {
  19 |     labelType: 'AgRadiusCrossLineLabelOptions',
  20 |     present: ['positionAngle'],
  21 |     absent: ['position', 'placement', 'rotation'],
  22 | };
  23 | 
  24 | const TABS = [
  25 |     { id: 'AgCartesianLineCrossLineOptions', ...CARTESIAN },
  26 |     { id: 'AgCartesianRangeCrossLineOptions', ...CARTESIAN },
  27 |     { id: 'AgAngleLineCrossLineOptions', ...ANGLE },
  28 |     { id: 'AgAngleRangeCrossLineOptions', ...ANGLE },
  29 |     { id: 'AgRadiusLineCrossLineOptions', ...RADIUS },
  30 |     { id: 'AgRadiusRangeCrossLineOptions', ...RADIUS },
  31 | ];
  32 | 
  33 | test.describe('Cross Lines API reference', () => {
  34 |     setupIntrinsicAssertions(test);
  35 | 
  36 |     for (const { id, labelType, present, absent } of TABS) {
  37 |         test.describe(id, () => {
  38 |             // Landing on a deep hash selects the tab and expands `label`, so no tab nav click is needed.
  39 |             test.beforeEach(({ page }) => gotoUrl(page, toPageUrl(`${PAGE_URL}#reference-${id}-label-text`)));
  40 | 
  41 |             test('documents the per-axis label properties', async ({ page }) => {
  42 |                 const panel = page.locator(`[tab-id="${id}"]`);
> 43 |                 await expect(panel).toBeVisible();
     |                                     ^ Error: expect(locator).toBeVisible() failed
  44 |                 await expect(panel.locator(`#reference-${id}-type`)).toBeVisible();
  45 |                 await expect(panel.locator(`#reference-${id}-label`)).toContainText(labelType);
  46 | 
  47 |                 for (const name of present) {
  48 |                     await expect(panel.locator(`#reference-${id}-label-${name}`)).toBeVisible();
  49 |                 }
  50 |                 for (const name of absent) {
  51 |                     await expect(panel.locator(`#reference-${id}-label-${name}`)).toHaveCount(0);
  52 |                 }
  53 |             });
  54 |         });
  55 |     }
  56 | });
  57 | 
```