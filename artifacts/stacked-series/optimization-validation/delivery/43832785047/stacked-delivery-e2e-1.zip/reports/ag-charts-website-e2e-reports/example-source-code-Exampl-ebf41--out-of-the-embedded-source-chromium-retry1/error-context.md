# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: example-source-code.spec.ts >> Example source embedded for crawlers >> leaves data files out of the embedded source
- Location: e2e/example-source-code.spec.ts:72:9

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "<code data-file-name=\"main.ts\">"
Received string:    "<!DOCTYPE html><link rel=\"preconnect\" href=\"https://fonts.googleapis.com\"> <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin> <link href=\"https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap\" rel=\"stylesheet\"> <html lang=\"en\" data-announcement-id=\"c32e9b7f1422\" data-announcement-until-date=\"2026-10-19\" style=\"--lightModeCSSUrl: url(&quot;/images/sun.svg&quot;);--darkModeCSSUrl: url(&quot;/images/moon.svg&quot;);\" data-astro-cid-ju4pidww> <head><meta charset=\"UTF-8\"><meta name=\"description\" content=\"The Map Line Series visualises geographic lines, such as roads or flight paths, with the ability to vary width and colour to represent data values. Download AG Charts v15.0.0 today: The best JavaScript Charts and JavaScript Graphs, in the World.\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"icon\" type=\"image/png\" sizes=\"196x196\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-196.png?origWidth=196&amp;origHeight=196&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"192x192\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-192.png?origWidth=192&amp;origHeight=192&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"180x180\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-180.png?origWidth=180&amp;origHeight=180&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"167x167\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-167.png?origWidth=167&amp;origHeight=167&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"152x152\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-152.png?origWidth=152&amp;origHeight=152&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"128x128\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-128.png?origWidth=128&amp;origHeight=128&amp;origFormat=png\"><link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-32.png?origWidth=32&amp;origHeight=32&amp;origFormat=png\"><link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-180-touch.png?origWidth=180&amp;origHeight=180&amp;origFormat=png\"><link rel=\"apple-touch-icon\" sizes=\"167x167\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-167-touch.png?origWidth=167&amp;origHeight=167&amp;origFormat=png\"><link rel=\"apple-touch-icon\" sizes=\"152x152\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/favicons/favicon-152-touch.png?origWidth=152&amp;origHeight=152&amp;origFormat=png\"><meta name=\"robots\" content=\"noindex\"><meta name=\"generator\" content=\"Astro v7.3.4\"><title>JavaScript Charts: Maps - Routes and Connections | AG Charts</title><meta name=\"astro-view-transitions-enabled\" content=\"true\"> <meta name=\"astro-view-transitions-fallback\" content=\"animate\"><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/astro/components/ClientRouter.astro?astro&type=script&index=0&lang.ts\"></script> <script src=\"/scripts/csp-zone-navigation.js\"></script><link rel=\"canonical\" href=\"https://www.ag-grid.com/javascript/map-lines/\"><link rel=\"alternate\" type=\"text/markdown\" href=\"/javascript/map-lines.md\"><link rel=\"sitemap\" type=\"application/xml\" title=\"Sitemap\" href=\"/sitemap-index.xml\"><!-- Import all global design system CSS --><link rel=\"stylesheet\" href=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/design-system/design-system.scss\"><!-- Facebook Meta Tags --><meta property=\"og:url\" content=\"https://www.ag-grid.com/javascript/map-lines/\"><meta property=\"og:type\" content=\"website\"><meta property=\"og:title\" content=\"JavaScript Charts: Maps - Routes and Connections | AG Charts\"><meta property=\"og:description\" content=\"The Map Line Series visualises geographic lines, such as roads or flight paths, with the ability to vary width and colour to represent data values. Download AG Charts v15.0.0 today: The best JavaScript Charts and JavaScript Graphs, in the World.\"><meta property=\"og:image\" content=\"https://www.ag-grid.com/images/ag-charts-social.png\"><!-- Twitter Meta Tags --><meta name=\"twitter:card\" content=\"summary_large_image\"><meta property=\"twitter:domain\" content=\"www.ag-grid.com\"><meta property=\"twitter:url\" content=\"https://www.ag-grid.com/javascript/map-lines/\"><meta name=\"twitter:title\" content=\"JavaScript Charts: Maps - Routes and Connections | AG Charts\"><meta name=\"twitter:description\" content=\"The Map Line Series visualises geographic lines, such as roads or flight paths, with the ability to vary width and colour to represent data values. Download AG Charts v15.0.0 today: The best JavaScript Charts and JavaScript Graphs, in the World.\"><meta name=\"twitter:image\" content=\"https://www.ag-grid.com/images/ag-charts-social.png\"><script type=\"application/ld+json\">{\"@context\":\"https://schema.org\",\"@graph\":[{\"@type\":\"Organization\",\"@id\":\"https://www.ag-grid.com/#organization\",\"name\":\"AG Grid\",\"url\":\"https://www.ag-grid.com/\",\"logo\":\"https://www.ag-grid.com/images/ag-logos/png-logos/AG-Grid-Logo_Light-Theme_476_140.png\",\"sameAs\":[\"https://github.com/ag-grid\",\"https://x.com/ag_grid\",\"https://youtube.com/c/ag-grid\",\"https://www.linkedin.com/company/ag-grid\",\"https://www.crunchbase.com/organization/ag-grid\",\"https://www.wikidata.org/wiki/Q128283374\"],\"description\":\"AG Grid is a JavaScript data grid and charting library for building enterprise web applications, developed by AG Grid Ltd. Its product family is AG Grid, AG Charts and AG Studio.\",\"legalName\":\"AG Grid Ltd\",\"foundingDate\":\"2010-07-19\",\"address\":{\"@type\":\"PostalAddress\",\"streetAddress\":\"70 Wilson Street\",\"addressLocality\":\"London\",\"postalCode\":\"EC2A 2DB\",\"addressCountry\":\"GB\"},\"identifier\":[{\"@type\":\"PropertyValue\",\"propertyID\":\"Companies House\",\"value\":\"07318192\"},{\"@type\":\"PropertyValue\",\"propertyID\":\"VAT\",\"value\":\"GB998360167\"}],\"founder\":{\"@type\":\"Person\",\"name\":\"Niall Crosby\",\"sameAs\":[\"https://www.wikidata.org/wiki/Q114758691\"]},\"contactPoint\":[{\"@type\":\"ContactPoint\",\"contactType\":\"sales\",\"url\":\"https://www.ag-grid.com/contact/\",\"areaServed\":\"Worldwide\",\"availableLanguage\":\"English\"},{\"@type\":\"ContactPoint\",\"contactType\":\"technical support\",\"url\":\"https://ag-grid.zendesk.com/\",\"areaServed\":\"Worldwide\",\"availableLanguage\":\"English\"}]},{\"@type\":\"WebSite\",\"@id\":\"https://www.ag-grid.com/charts/#website\",\"url\":\"https://www.ag-grid.com/charts/\",\"name\":\"AG Charts: JavaScript Charting Library for React, Angular and Vue\",\"description\":\"Create interactive, animated, high-performance charts & graphs with AG Charts JavaScript Charting library, from the makers of AG Grid. Built with JavaScript for React, Angular and Vue.\",\"inLanguage\":\"en\",\"publisher\":{\"@id\":\"https://www.ag-grid.com/#organization\"}},{\"@type\":\"SoftwareApplication\",\"@id\":\"https://www.ag-grid.com/charts/#software-application\",\"name\":\"AG Charts\",\"applicationCategory\":\"DeveloperApplication\",\"operatingSystem\":\"Web Browser\",\"softwareVersion\":\"14.3.0\",\"url\":\"https://www.ag-grid.com/charts/\",\"publisher\":{\"@id\":\"https://www.ag-grid.com/#organization\"},\"offers\":[{\"@type\":\"Offer\",\"name\":\"AG Charts Community\",\"price\":\"0\",\"priceCurrency\":\"USD\",\"url\":\"https://www.ag-grid.com/charts/license-pricing/\"}]},{\"@type\":\"TechArticle\",\"@id\":\"https://www.ag-grid.com/charts/javascript/map-lines/#article\",\"headline\":\"Maps - Routes and Connections\",\"description\":\"The Map Line Series visualises geographic lines, such as roads or flight paths, with the ability to vary width and colour to represent data values.\",\"inLanguage\":\"en\",\"url\":\"https://www.ag-grid.com/charts/javascript/map-lines/\",\"mainEntityOfPage\":{\"@type\":\"WebPage\",\"@id\":\"https://www.ag-grid.com/charts/javascript/map-lines/\"},\"isPartOf\":[{\"@id\":\"https://www.ag-grid.com/charts/#website\"},{\"@id\":\"https://www.ag-grid.com/charts/#docs-topic-map-lines\"}],\"publisher\":{\"@id\":\"https://www.ag-grid.com/#organization\"},\"about\":{\"@id\":\"https://www.ag-grid.com/charts/#software-application\"},\"keywords\":[\"JavaScript\",\"JavaScript Charts\",\"AG Charts\",\"Maps - Routes and Connections\"],\"dependencies\":\"ag-charts-community, ag-charts-enterprise\"},{\"@type\":\"CreativeWork\",\"@id\":\"https://www.ag-grid.com/charts/#docs-topic-map-lines\",\"name\":\"Maps - Routes and Connections\",\"inLanguage\":\"en\",\"isPartOf\":{\"@id\":\"https://www.ag-grid.com/charts/#website\"},\"hasPart\":[{\"@id\":\"https://www.ag-grid.com/charts/react/map-lines/#article\"},{\"@id\":\"https://www.ag-grid.com/charts/angular/map-lines/#article\"},{\"@id\":\"https://www.ag-grid.com/charts/vue/map-lines/#article\"},{\"@id\":\"https://www.ag-grid.com/charts/javascript/map-lines/#article\"}]},{\"@type\":\"BreadcrumbList\",\"@id\":\"https://www.ag-grid.com/charts/javascript/map-lines/#breadcrumb\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"AG Charts\",\"item\":\"https://www.ag-grid.com/charts/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"JavaScript Charts\",\"item\":\"https://www.ag-grid.com/charts/javascript/quick-start/\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Maps - Routes and Connections\",\"item\":\"https://www.ag-grid.com/charts/javascript/map-lines/\"}]}]}</script><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/node_modules/astro/components/ClientRouter.astro?astro&amp;type=style&amp;index=0&amp;lang.css\">/* Route announcer */
	.astro-route-announcer {
		position: absolute;
		left: 0;
		top: 0;
		clip: rect(0 0 0 0);
		clip-path: inset(50%);
		overflow: hidden;
		white-space: nowrap;
		width: 1px;
		height: 1px;
	}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/icon/Icon.module.scss\">._icon_1jqgc_1 {
  fill: var(--icon-color, var(--color-fg-primary));
  width: var(--icon-size);
  height: var(--icon-size);
  transition: fill 0.25s ease-in-out;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/site-header/SiteHeader.module.scss\">._header_1bxi9_1 {
  display: flex;
  align-items: center;
  position: relative;
  background-color: var(--color-bg-site-header);
  transition: background-color 0.5s ease-in-out;
  container-type: inline-size;
  container-name: site-header;
}
@media screen and (min-width: 1275px) {
  ._header_1bxi9_1 {
    position: sticky;
    top: 0;
    width: 100%;
    z-index: 10002;
  }
  ._header_1bxi9_1:has(._mobileMenuButton_1bxi9_17[aria-expanded=true]) {
    position: relative;
  }
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._header_1bxi9_1, [data-dark-mode=true]:has([data-is-homepage=true]) ._header_1bxi9_1.header-scrolled {
  background: var(--color-bg-primary);
  border-bottom: 1px solid var(--color-border-primary);
}·
._header_1bxi9_1 ._headerInner_1bxi9_26 {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  position: relative;
  width: 100%;
  max-width: calc(var(--layout-max-width) + var(--layout-horizontal-margins) * 2);
  margin-left: auto;
  margin-right: auto;
  justify-content: space-between;
}
@container site-header (min-width: 1520px) {
  ._header_1bxi9_1 ._headerInner_1bxi9_26 {
    display: grid;
    grid-template-columns: auto 1fr auto auto;
    grid-template-areas: \"logo docs-search switcher nav\";
    align-items: center;
    column-gap: 16px;
  }
}·
._headerLogo_1bxi9_47 {
  display: flex;
  align-items: center;
  min-height: var(--layout-site-header-height);
  padding: 8px 10px;
  margin-left: calc(var(--layout-horizontal-margins) - 16px);
  grid-area: logo;
}
._headerLogo_1bxi9_47 .logotype {
  width: unset;
  height: 34px;
}
._headerLogo_1bxi9_47 .logo-mark {
  width: 48px;
  height: unset;
  transform: translateY(0.5px);
}·
._docsNavBtnSearchContainer_1bxi9_65 {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 16px;
  width: 100%;
  margin: 0 var(--layout-horizontal-margins) 16px var(--layout-horizontal-margins);
  grid-area: docs-search;
}
@container site-header (min-width: 520px) {
  ._docsNavBtnSearchContainer_1bxi9_65 {
    flex-wrap: nowrap;
  }
}
@container site-header (min-width: 1275px) {
  ._docsNavBtnSearchContainer_1bxi9_65 {
    order: 4;
  }
}
@container site-header (min-width: 1520px) {
  ._docsNavBtnSearchContainer_1bxi9_65 {
    margin: 0;
    width: auto;
  }
}·
button._mobileNavButton_1bxi9_90 {
  width: 100%;
  background-color: rgba(255, 255, 255, 0.15);
  border: none;
  border-radius: var(--radius-lg);
  color: var(--color-button-primary-fg);
  border: 1px solid rgba(255, 255, 255, 0.05);
}
button._mobileNavButton_1bxi9_90:hover {
  background-color: rgba(255, 255, 255, 0.19);
  color: var(--color-button-primary-fg);
}
button._mobileNavButton_1bxi9_90 .icon {
  --icon-size: 24px;
  --icon-color: var(--color-button-primary-fg);
  margin-left: 4px;
  margin-right: -4px;
  fill: var(--color-button-primary-fg);
}
[data-dark-mode=true] button._mobileNavButton_1bxi9_90 .icon {
  --icon-color: var(--color-fg-white);
  fill: var(--color-fg-white);
}
@container site-header (min-width: 520px) {
  button._mobileNavButton_1bxi9_90 {
    max-width: 120px;
  }
}
@media screen and (min-width: 1100px) {
  button._mobileNavButton_1bxi9_90 {
    display: none;
  }
}
[data-dark-mode=true] button._mobileNavButton_1bxi9_90 {
  background-color: rgba(255, 255, 255, 0.1);
  color: var(--color-fg-white);
}
[data-dark-mode=true] button._mobileNavButton_1bxi9_90:hover {
  background-color: rgba(255, 255, 255, 0.19);
}·
._mobileMenuButton_1bxi9_17 {
  appearance: none;
  position: absolute;
  top: 0;
  right: 6px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: var(--layout-site-header-height);
  width: var(--layout-site-header-height);
  padding: 0 16px 0 14px;
  border-radius: var(--radius-none);
  border: none;
  color: transparent;
  background-color: transparent;
  transition: background-color 0.4s ease-in-out;
}
._mobileMenuButton_1bxi9_17:hover {
  background-color: transparent;
}
._mobileMenuButton_1bxi9_17:focus {
  box-shadow: none;
}
._mobileMenuButton_1bxi9_17:focus-visible {
  box-shadow: inset 0 0 0 2px var(--color-button-primary-shadow-focus);
}
._mobileMenuButton_1bxi9_17 svg {
  position: relative;
  left: 1px;
}
@container site-header (min-width: 1275px) {
  ._mobileMenuButton_1bxi9_17 {
    display: none;
  }
}·
._menuIcon_1bxi9_167 g {
  transition: transform 0.2s 0.2s;
}
._menuIcon_1bxi9_167 rect {
  fill: var(--color-white);
  transition: transform 0.2s;
}
._menuIcon_1bxi9_167 .middle {
  transition: opacity 0s 0.2s;
}
._menuIcon_1bxi9_167 .top rect {
  transform-origin: center 8px;
}
._menuIcon_1bxi9_167 .bottom rect {
  transform-origin: center 28px;
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 g {
  transition: transform 0.2s;
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 rect {
  transition: transform 0.2s 0.2s;
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 .top {
  transform: translateY(10px);
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 .top rect {
  transform: rotate(45deg);
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 .middle {
  opacity: 0;
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 .bottom {
  transform: translateY(-10px);
}
._mobileMenuButton_1bxi9_17[aria-expanded=true] ._menuIcon_1bxi9_167 .bottom rect {
  transform: rotate(-45deg);
}·
._mainNavLarge_1bxi9_205 {
  display: none;
}
@container site-header (min-width: 1275px) {
  ._mainNavLarge_1bxi9_205 {
    display: block;
  }
}·
._mainNavLargeContainer_1bxi9_214 {
  grid-area: nav;
}·
#_mainNavSmall_1bxi9_1 {
  width: 100%;
  grid-area: nav;
}
@container site-header (min-width: 1275px) {
  #_mainNavSmall_1bxi9_1 {
    display: none;
  }
}·
._mainNav_1bxi9_205,
#_mainNav_1bxi9_205 {
  width: 100%;
  background-color: var(--color-bg-mobile-nav);
  transition: background-color 0.5s ease-in-out;
}
@container site-header (min-width: 1275px) {
  ._mainNav_1bxi9_205,
  #_mainNav_1bxi9_205 {
    width: auto;
    margin-right: 8px;
    margin-left: 8px;
  }
}·
@container site-header (min-width: 1275px) {
  ._navItemList_1bxi9_244 {
    display: flex;
    height: var(--layout-site-header-height);
    align-items: center;
    justify-content: flex-end;
  }
}·
@container site-header (max-width: 1275px) {
  ._navItem_1bxi9_244 {
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  }
}
@container site-header (min-width: 1275px) {
  ._navItem_1bxi9_244:hover a::after {
    opacity: 0.25;
    transform: scaleX(1);
  }
  [data-dark-mode=true] ._navItem_1bxi9_244._navItemActive_1bxi9_262 ._navLink_1bxi9_262 {
    opacity: 1;
  }
  ._navItem_1bxi9_244._navItemActive_1bxi9_262 a::after {
    opacity: 0.5;
    transform: scaleX(1);
  }
  [data-dark-mode=true] ._navItem_1bxi9_244._navItemActive_1bxi9_262 a::after {
    opacity: 0.75;
  }
}
@container site-header (min-width: 1275px) {
  [data-dark-mode=true] ._navItem_1bxi9_244 {
    border-bottom: none;
  }
}·
a._navLink_1bxi9_262,
button._navLink_1bxi9_262 {
  --horizontal-padding: clamp(8px, 1vw, 14px);
  display: block;
  position: relative;
  width: 100%;
  padding: 19px var(--layout-horizontal-margins) 16px;
  font-size: 17px;
  white-space: nowrap;
  font-weight: 500;
  letter-spacing: 0.01em;
  color: var(--color-white);
  transition: color 0.25s ease-in-out, opacity 0.25s ease-in-out;
  cursor: pointer;
}
buttona._navLink_1bxi9_262, button._navLink_1bxi9_262 {
  color: var(--color-white);
}·
a._navLink_1bxi9_262:hover,
button._navLink_1bxi9_262:hover {
  text-decoration: none;
  color: var(--color-white);
}
@container site-header (min-width: 1275px) {
  a._navLink_1bxi9_262,
  button._navLink_1bxi9_262 {
    padding-left: var(--horizontal-padding);
    padding-right: var(--horizontal-padding);
  }
  a._navLink_1bxi9_262::after,
  button._navLink_1bxi9_262::after {
    content: \"\";
    position: absolute;
    height: 2px;
    bottom: 12px;
    left: calc(var(--horizontal-padding) - 4px);
    right: calc(var(--horizontal-padding) - 4px);
    border-radius: 2px;
    background-color: var(--color-white);
    opacity: 0;
    transform: scaleX(0);
    transition: transform 0.33s ease-in-out, opacity 0.33s ease-in-out;
  }
}
[data-dark-mode=true]:has([data-is-homepage=false]) a._navLink_1bxi9_262, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) a._navLink_1bxi9_262,
[data-dark-mode=true]:has([data-is-homepage=false]) button._navLink_1bxi9_262,
[data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) button._navLink_1bxi9_262 {
  opacity: 0.8;
}·
button._navLink_1bxi9_262 {
  display: flex;
  align-items: center;
}·
._githubItem_1bxi9_335 {
  order: 2;
}·
._buttonItem_1bxi9_339 a::after {
  display: none;
}
._buttonItem_1bxi9_339 svg.icon,
._buttonItem_1bxi9_339 ._pseudoIcon_1bxi9_343 {
  --icon-size: 24px;
  margin-right: 4px;
  border-radius: 50%;
  fill: var(--color-white);
}
@container site-header (min-width: 1275px) {
  ._buttonItem_1bxi9_339 span:not(._navLink_1bxi9_262) {
    display: none;
  }
  ._buttonItem_1bxi9_339 ._navLink_1bxi9_262 {
    padding-left: 12px;
    padding-right: 12px;
  }
  ._buttonItem_1bxi9_339 svg,
  ._buttonItem_1bxi9_339 ._pseudoIcon_1bxi9_343 {
    margin-right: 0;
    transition: box-shadow 0.33s ease-in-out;
  }
  ._buttonItem_1bxi9_339 ._navLink_1bxi9_262:hover svg,
  ._buttonItem_1bxi9_339 ._navLink_1bxi9_262:hover ._pseudoIcon_1bxi9_343 {
    box-shadow: 0 0 0 4px var(--color-bg-mobile-nav), 0 0 0 6px rgba(255, 255, 255, 0.3);
  }
  [data-dark-mode=true]:has([data-is-homepage=false]) ._buttonItem_1bxi9_339 ._navLink_1bxi9_262:hover svg,
  [data-dark-mode=true]:has([data-is-homepage=false]) ._buttonItem_1bxi9_339 ._navLink_1bxi9_262:hover ._pseudoIcon_1bxi9_343 {
    box-shadow: 0 0 0 4px var(--color-bg-primary), 0 0 0 6px rgba(255, 255, 255, 0.3);
  }
}·
._toggleDarkText_1bxi9_372 {
  display: none;
}
@container site-header (max-width: 1275px) {
  ._toggleDarkText_1bxi9_372 {
    display: inline;
  }
}·
._icon_1bxi9_102 {
  width: 24px;
  height: 24px;
  margin: 2px;
  background-image: var(--dark-icon);
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/logo/LogoMark.module.scss\">.logo-mark .aqua {
  fill: var(--color-logo-aqua);
}
.logo-mark .orange {
  fill: var(--color-logo-orange);
}
.logo-mark .red {
  fill: var(--color-logo-red);
}
.logo-mark .grey {
  fill: var(--color-logo-grey);
}
.logo-mark rect {
  animation-iteration-count: infinite;
  animation-timing-function: ease-in-out;
  animation-play-state: paused;
}
.logo-mark:not(._bounce_1oiud_18, ._loading_1oiud_18) rect {
  transform: translateX(0);
}·
._bounce_1oiud_18 rect[class*=right] {
  animation-name: _logo-mark-bounce-right_1oiud_1;
  animation-duration: 1.15s;
  animation-play-state: running;
}
._bounce_1oiud_18 rect[class*=right].right-2 {
  animation-delay: 0.1916666667s;
}
._bounce_1oiud_18 rect[class*=right].right-3 {
  animation-delay: 0.3833333333s;
}·
._loading_1oiud_18 rect[class*=right] {
  animation-name: _logo-mark-bounce-right_1oiud_1;
  animation-duration: 1.25s;
  animation-play-state: running;
}
._loading_1oiud_18 rect[class*=right].right-2 {
  animation-delay: 0.2083333333s;
}
._loading_1oiud_18 rect[class*=right].right-3 {
  animation-delay: 0.4166666667s;
}·
._loading_1oiud_18 rect[class*=left] {
  animation-name: _logo-mark-bounce-left_1oiud_1;
  animation-duration: 1.25s;
  animation-play-state: running;
}
._loading_1oiud_18 rect[class*=left].left-3 {
  animation-delay: 0.625s;
}
._loading_1oiud_18 rect[class*=left].left-2 {
  animation-delay: 0.8333333333s;
}
._loading_1oiud_18 rect[class*=left].left-1 {
  animation-delay: 1.0416666667s;
}·
@keyframes _logo-mark-bounce-right_1oiud_1 {
  0% {
    transform: translateX(0%);
  }
  16.6666% {
    transform: translateX(3px);
  }
  33.3333% {
    transform: translateX(0);
  }
}
@keyframes _logo-mark-bounce-left_1oiud_1 {
  0% {
    transform: translateX(0%);
  }
  16.6666% {
    transform: translateX(-3px);
  }
  33.3333% {
    transform: translateX(0);
  }
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/Search.module.scss\">._headerSearchBox_14kty_1 {
  display: flex;
  align-items: center;
  position: relative;
  width: 100%;
  max-width: 100%;
  margin-left: auto;
  margin-right: auto;
  padding: 8px 12px;
  border-radius: var(--radius-lg);
  background-color: rgba(255, 255, 255, 0.15);
  color: var(--color-fg-white);
  cursor: pointer;
  transition: background-color 0.5s ease-in-out, border 0.5s ease-in-out, box-shadow 0.5s ease-in-out;
  border: 1px solid rgba(255, 255, 255, 0.05);
  font-weight: var(--text-semibold);
}
@container site-header (min-width: 1520px) {
  ._headerSearchBox_14kty_1 {
    max-width: 372px;
  }
}
[data-dark-mode=true] ._headerSearchBox_14kty_1 {
  background-color: rgba(255, 255, 255, 0.1);
  border: 1px solid color-mix(in srgb, var(--color-brand-200), var(--color-bg-primary) 90%);
}
._headerSearchBox_14kty_1:hover {
  background-color: rgba(255, 255, 255, 0.15);
  transition: all 0.5s;
  box-shadow: var(--shadow-lg);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
._headerSearchBox_14kty_1::-webkit-search-decoration, ._headerSearchBox_14kty_1::-webkit-search-cancel-button {
  display: none;
}
._headerSearchBox_14kty_1:hover ._placeholder_14kty_36, ._headerSearchBox_14kty_1:hover .icon {
  opacity: 1;
}
._headerSearchBox_14kty_1:hover ._kbdShortcut_14kty_39 {
  opacity: 0.9;
  box-shadow: var(--shadow-lg);
}
._headerSearchBox_14kty_1 > * {
  transition: opacity 0.25s ease-in-out;
}
._headerSearchBox_14kty_1 .icon {
  --icon-size: 18px;
  --icon-color: var(--color-fg-white);
  margin-right: 4px;
  opacity: 1;
}·
._placeholder_14kty_36 {
  opacity: 0.9;
}·
._kbdShortcut_14kty_39 {
  margin-left: auto;
  opacity: 1;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-semibold);
  background-color: rgba(255, 255, 255, 0.2);
  color: var(--color-fg-white);
  padding-right: 4px;
  padding-left: 4px;
  border-radius: var(--radius-sm);
}
._kbdShortcut_14kty_39 ._kbdShortcutMac_14kty_68 {
  display: none;
}
html[data-os=mac] ._kbdShortcut_14kty_39 ._kbdShortcutDefault_14kty_71 {
  display: none;
}
html[data-os=mac] ._kbdShortcut_14kty_39 ._kbdShortcutMac_14kty_68 {
  display: inline;
}
[data-dark-mode=true] ._kbdShortcut_14kty_39 {
  color: var(--color-fg-white);
  background-color: rgba(255, 255, 255, 0.2);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/getting-started/getting-started.module.scss\">._container_zs2db_1 {
  display: flex;
  gap: 16px;
  font-weight: 400;
  width: 100%;
}
@media (max-width: 768px) {
  ._container_zs2db_1 {
    flex-direction: column;
  }
}·
._card_zs2db_13 {
  width: 100%;
  background: var(--color-bg-primary);
  border-radius: 10px;
  padding: 20px;
  text-align: left;
  transition: transform 0.2s ease-in-out;
  border: 1px solid var(--color-border-secondary);
  min-height: 180px;
  color: var(--color-bg-secondary);
}
._card_zs2db_13:hover {
  transform: translateY(-5px);
  background-color: var(--color-bg-secondary);
  transition: all 0.3s;
}
._card_zs2db_13 svg {
  margin-bottom: 16px;
}
._card_zs2db_13 path {
  fill: var(--color-util-brand-700);
}·
._iconGroup_zs2db_36 {
  display: flex;
  justify-content: space-between;
}·
._titleIcon_zs2db_41 {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;
  padding-bottom: 8px;
}
._titleIcon_zs2db_41 div {
  height: 20px;
}
._titleIcon_zs2db_41 svg {
  height: 20px;
  width: 20px;
}
._titleIcon_zs2db_41 path {
  fill: var(--color-fg-primary);
  opacity: 0.4;
}·
._icon_zs2db_36 {
  font-size: 2rem;
  padding: 10px;
  border-radius: 50%;
  display: inline-block;
}·
._title_zs2db_41 {
  font-size: 18px;
  margin-top: 10px;
  font-weight: 700;
}·
._description_zs2db_73 {
  color: color-mix(in srgb, var(--color-text-secondary), var(--color-bg-primary) 20%);
  font-weight: normal;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchBox.module.scss\">._searchBox_1uvbx_1 {
  display: flex;
  border-radius: var(--radius-md);
  cursor: text;
}
[data-dark-mode=true] ._searchBox_1uvbx_1 input {
  background: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-primary) 6%);
}
[data-dark-mode=true] ._searchBox_1uvbx_1 input::placeholder {
  color: rgba(255, 255, 255, 0.6);
}·
._searchIcon_1uvbx_13 {
  --icon-size: 28px;
  --icon-color: var(--color-fg-secondary);
  position: absolute;
  top: 24px;
  left: 24px;
}·
input[type=search]._searchInput_1uvbx_21 {
  width: 100%;
  height: 76px;
  padding: 24px 24px 24px 64px;
  font-size: 20px;
  border: none;
  outline: none;
  box-shadow: none;
}
input[type=search]._searchInput_1uvbx_21:focus, input[type=search]._searchInput_1uvbx_21:focus-visible {
  box-shadow: none !important;
}
input[type=search]._searchInput_1uvbx_21::placeholder {
  color: var(--color-fg-quinary);
}
input[type=search]._searchInput_1uvbx_21::-webkit-search-decoration, input[type=search]._searchInput_1uvbx_21::-webkit-search-cancel-button {
  display: none;
}·
._gettingStarted_1uvbx_40 {
  padding: 20px;
}
._gettingStarted_1uvbx_40 span {
  text-transform: uppercase;
  font-weight: 600;
  letter-spacing: 1.2px;
  color: var(--color-text-secondary);
  opacity: 0.6;
  font-size: 13px;
}
._gettingStarted_1uvbx_40 h3 {
  color: var(--color-link);
  font-size: 17px;
}
._gettingStarted_1uvbx_40 p {
  font-size: 15px;
}
._gettingStarted_1uvbx_40 a {
  margin-top: 12px;
  box-shadow: var(--shadow-sm);
  height: 100px !important;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchControls.module.scss\">._controlsOuter_1tdto_1,
._keyboardSection_1tdto_2,
._kbdIcon_1tdto_3 {
  display: flex;
  align-items: center;
}·
._controlsOuter_1tdto_1 {
  justify-content: flex-end;
  gap: 16px;
  padding: 0 20px;
  height: 56px;
  border-top: 1px solid var(--color-border-secondary);
}
[data-dark-mode=true] ._controlsOuter_1tdto_1 {
  border-top: 1px solid var(--color-border-primary);
}
@media screen and (max-width: 420px) {
  ._controlsOuter_1tdto_1 {
    display: none;
  }
}·
._keyboardSection_1tdto_2 {
  justify-content: center;
  gap: 8px;
}·
._kbdIcon_1tdto_3 {
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: var(--radius-md);
  background-color: var(--color-bg-secondary);
  border: 1px solid var(--color-border-secondary);
  box-shadow: var(--shadow-xs);
}
[data-dark-mode=true] ._kbdIcon_1tdto_3 {
  background-color: var(--color-border-tertiary);
}
._kbdIcon_1tdto_3 + ._kbdIcon_1tdto_3 {
  margin-left: -4px;
}
._kbdIcon_1tdto_3 .icon {
  --icon-size: 20px;
  --icon-color: var(--color-util-gray-400);
}
[data-dark-mode=true] ._kbdIcon_1tdto_3 .icon {
  --icon-color: var(--color-fg-primary);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchHits.module.scss\">._results_18i13_1 {
  position: relative;
  padding-top: 8px;
  padding-bottom: 16px;
  font-size: 18px;
  border-top: 1px solid var(--color-border-secondary);
  max-height: min(643px, 100vh - 246px);
  overflow: auto;
  overscroll-behavior: contain;
}
[data-dark-mode=true] ._results_18i13_1 {
  border-top: 1px solid var(--color-border-primary);
}
._results_18i13_1 > div:last-child ._hit_18i13_14:last-child {
  position: relative;
  z-index: 1;
}·
._hit_18i13_14 {
  position: relative;
  gap: 16px;
  display: flex;
  margin: 0 24px;
  padding: 12px;
  border-radius: var(--radius-md);
  cursor: pointer;
  align-items: center;
}
._hit_18i13_14[data-selected=true] {
  background-color: var(--color-brand-50);
  box-shadow: inset 0px 0px 0px 1px var(--color-brand-300);
  z-index: 1;
}
[data-dark-mode=true] ._hit_18i13_14[data-selected=true] {
  background-color: var(--color-bg-secondary);
}
._hit_18i13_14[data-selected=true] .icon {
  --icon-color: var(--color-text-brand-primary);
}·
._hitIcon_18i13_41 {
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 40px;
  height: 40px;
  border-radius: var(--radius-md);
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  box-shadow: var(--shadow-xs);
}
[data-dark-mode=true] ._hitIcon_18i13_41 {
  background-color: var(--color-border-tertiary);
}
._hitIcon_18i13_41 .icon {
  --icon-size: 24px;
  --icon-color: var(--color-fg-secondary);
  transition: none;
}
[data-dark-mode=true] ._hitIcon_18i13_41 .icon {
  --icon-color: var(--color-fg-primary);
  opacity: 0.5;
}·
._hitTextWrapper_18i13_66 {
  max-width: 100%;
  overflow: hidden;
}·
._titleSection_18i13_71,
._title_18i13_71,
._text_18i13_73 {
  white-space: nowrap;
  text-overflow: ellipsis;
  text-decoration: none;
  overflow: hidden;
  font-size: var(--text-fs-base);
  width: 100%;
}·
._titleSection_18i13_71 {
  margin-bottom: 0;
}·
._title_18i13_71 {
  color: var(--color-fg-primary);
  font-weight: var(--text-semibold);
}
[data-selected=true] ._title_18i13_71 {
  color: var(--color-text-brand-primary);
}·
._text_18i13_73 {
  font-weight: var(--text-regular);
  font-size: var(--text-fs-sm);
}
._text_18i13_73::after {
  content: \"\";
  display: block;
}·
._crumbContainer_18i13_103 {
  padding: 12px 0 8px 24px;
}·
._crumb_18i13_103 {
  font-weight: var(--text-semibold);
  text-decoration: none;
  color: var(--color-text-primary);
  font-size: var(--text-fs-sm);
}
[data-dark-mode=true] ._crumb_18i13_103 {
  color: var(--color-white);
}·
._chevronRight_18i13_117 {
  color: var(--color-fg-quinary);
}·
._noResults_18i13_121 {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 160px;
  padding-left: 16px;
  padding-right: 16px;
  border-top: 1px solid var(--color-border-primary);
  color: var(--color-text-tertiary);
}
._noResults_18i13_121 .icon {
  --icon-size: 40px;
  --icon-color: var(--color-text-secondary);
  opacity: 0.7;
  margin-bottom: 8px;
}
._noResults_18i13_121 span {
  text-align: center;
}·
._hitLink_18i13_142 {
  color: var(--color-text-tertiary);
}
._hitLink_18i13_142:hover {
  color: inherit;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchModal.module.scss\">._backdrop_abtmr_1 {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(255, 255, 255, 0.5);
  backdrop-filter: blur(5px);
  -webkit-backdrop-filter: blur(5px);
  z-index: 10;
}
[data-dark-mode=true] ._backdrop_abtmr_1 {
  background: rgba(12, 17, 26, 0.4);
  backdrop-filter: blur(5px);
  -webkit-backdrop-filter: blur(5px);
}·
._backdropEnter_abtmr_18 {
  animation: _fadeIn_abtmr_1 0.3s ease-in;
  opacity: 1;
}·
._backdropExit_abtmr_23 {
  animation: _fadeOut_abtmr_1 0.3s ease-out;
  opacity: 0;
}·
@keyframes _fadeIn_abtmr_1 {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes _fadeOut_abtmr_1 {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
._container_abtmr_44 {
  position: fixed;
  top: 50px;
  left: 50%;
  transform: translateX(-50%);
  width: 850px;
  max-width: calc(100vw - 32px);
  background: var(--color-bg-primary);
  border-radius: 12px;
  box-shadow: 0px 25px 50px -12px rgba(16, 24, 40, 0.25);
  overflow: hidden;
}
[data-dark-mode=true] ._container_abtmr_44 {
  background: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-primary) 6%);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/product-dropdown/ProductDropdown.module.scss\">._customMenu_p7rjh_1 {
  display: none;
  margin-left: auto;
  user-select: none;
  grid-area: switcher;
}
@container site-header (min-width: 1275px) {
  ._customMenu_p7rjh_1 {
    display: block;
  }
}
@container site-header (min-width: 1520px) {
  ._customMenu_p7rjh_1 {
    margin-right: -20px;
  }
}·
._customTrigger_p7rjh_18 {
  padding: 12px;
  padding-top: 4px;
  padding-bottom: 4px;
  transform: translateY(1px);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: space-between;
  transition: background-color 0.3s, color 0.3s;
  font-weight: 500;
  font-size: 17px;
  border: none;
  border-radius: var(--radius-3xl);
  box-shadow: none;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._customTrigger_p7rjh_18, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._customTrigger_p7rjh_18 {
  background-color: var(--color-bg-primary);
  border-radius: var(--radius-3xl);
  border: none;
  opacity: 0.8;
  color: var(--color-fg-white);
}·
._customTrigger_p7rjh_18:hover {
  background: rgba(255, 255, 255, 0.1);
  border: none;
  border-radius: var(--radius-3xl);
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._customTrigger_p7rjh_18:hover, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._customTrigger_p7rjh_18:hover {
  background-color: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 7.5%);
}·
._customTrigger_p7rjh_18._open_p7rjh_51 ._arrow_p7rjh_51 {
  margin-top: 4px;
  transform: rotate(225deg);
}·
._customTrigger_p7rjh_18._open_p7rjh_51 {
  background: rgba(255, 255, 255, 0.1);
  border: none;
}·
._arrow_p7rjh_51 {
  display: inline-block;
  border: solid #fff;
  border-width: 0 2px 2px 0;
  padding: 3px;
  transform: rotate(45deg);
  transition: transform 0.3s;
  margin-left: 12px;
  margin-bottom: 2px;
}·
._customContent_p7rjh_72 {
  position: absolute;
  top: 52px;
  right: 12px;
  left: 12px;
  padding: 12px;
  border-radius: var(--radius-md);
  background: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  box-shadow: var(--shadow-sm);
  z-index: 2;
  opacity: 0;
  transform: translateY(10px) scale(0.95);
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.15s ease, transform 0.15s ease, visibility 0s linear 0.15s;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._customContent_p7rjh_72, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._customContent_p7rjh_72 {
  background: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 5%);
}
@container site-header (min-width: 620px) {
  ._customContent_p7rjh_72 {
    top: var(--layout-site-header-height);
    left: clamp(8px, var(--switcher-popup-left, 100%), 100% - 800px - 8px);
    right: auto;
    width: 800px;
    max-width: calc(100% - 8px * 2);
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}·
._column_p7rjh_104 {
  display: flex;
  flex-direction: column;
  min-width: 0;
}·
._columnHeading_p7rjh_110 {
  padding: 4px 8px 8px;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-semibold);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-fg-tertiary);
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._columnHeading_p7rjh_110, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._columnHeading_p7rjh_110 {
  color: var(--color-fg-secondary);
}·
._customMenu_p7rjh_1._open_p7rjh_51 ._customContent_p7rjh_72 {
  opacity: 1;
  transform: translateY(0) scale(1);
  visibility: visible;
  pointer-events: auto;
  transition: opacity 0.15s ease, transform 0.15s ease, visibility 0s linear 0s;
}·
._productTitle_p7rjh_130 {
  font-weight: var(--text-semibold);
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._productTitle_p7rjh_130, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._productTitle_p7rjh_130 {
  color: var(--color-fg-primary);
}·
._productDescription_p7rjh_137 {
  color: var(--color-text-secondary);
  opacity: 0.85;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-regular);
}·
._itemsWrapper_p7rjh_144 {
  display: flex;
  align-items: center;
  padding: 8px;
  border-radius: var(--radius-md);
  transition: 0.5s all;
}·
._productsWrapper_p7rjh_152 {
  display: flex;
  flex-direction: column;
  padding-left: 12px;
}·
._placeholderIcon_p7rjh_158 {
  flex: 0 0 48px;
  width: 48px;
  height: 48px;
  background: var(--color-util-brand-100);
  border-radius: var(--radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
}
._placeholderIcon_p7rjh_158 svg {
  width: 24px;
  height: 24px;
}
._placeholderIcon_p7rjh_158 ._iconLight_p7rjh_172 {
  display: block;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._placeholderIcon_p7rjh_158 ._iconLight_p7rjh_172, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._placeholderIcon_p7rjh_158 ._iconLight_p7rjh_172 {
  display: none;
}
._placeholderIcon_p7rjh_158 ._iconDark_p7rjh_178 {
  display: none;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._placeholderIcon_p7rjh_158 ._iconDark_p7rjh_178, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._placeholderIcon_p7rjh_158 ._iconDark_p7rjh_178 {
  display: block;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._placeholderIcon_p7rjh_158, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._placeholderIcon_p7rjh_158 {
  background: color-mix(in srgb, var(--color-fg-white), var(--color-bg-primary) 85%);
  box-shadow: var(--shadow-lg);
}·
._inlineHeading_p7rjh_189 {
  margin-top: 8px;
  color: var(--color-fg-quinary);
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._inlineHeading_p7rjh_189, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._inlineHeading_p7rjh_189 {
  color: var(--color-fg-quinary);
}·
._itemsWrapper_p7rjh_144:hover {
  background: var(--color-util-brand-50);
  cursor: pointer;
  transition: 0.3s all ease-in-out;
}
[data-dark-mode=true]:has([data-is-homepage=false]) ._itemsWrapper_p7rjh_144:hover, [data-dark-mode=true]:has([data-is-homepage=true] .header-scrolled) ._itemsWrapper_p7rjh_144:hover {
  background: color-mix(in srgb, var(--color-fg-white), var(--color-bg-primary) 85%);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/design-system/design-system.scss?url\">export default \"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/design-system/design-system.scss\"</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/dev-tools/DevTools.module.scss\">._devToolsTrigger_wxjss_1 {
  user-select: none;
}·
._devToolsContainer_wxjss_5 {
  max-width: calc(var(--layout-max-width-small) + var(--layout-horizontal-margins) * 2);
  margin-right: auto;
  margin-left: auto;
  padding: 16px;
  background: var(--color-dev-50);
  color: var(--color-text-primary);
}
@media screen and (min-width: 920px) {
  ._devToolsContainer_wxjss_5 {
    justify-content: space-between;
  }
}
._devToolsContainer_wxjss_5 h2 {
  font-size: var(--text-fs-base);
  margin-top: 0;
}
[data-dark-mode=true] ._devToolsContainer_wxjss_5 {
  background: var(--color-dev-950);
}·
._options_wxjss_26 {
  display: flex;
  flex-direction: row;
  gap: 16px;
  align-items: center;
}
._options_wxjss_26 > div {
  display: flex;
  align-items: center;
  min-height: 38px;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/footer/Footer.module.scss\">@charset \"UTF-8\";
._footer_14gre_2 {
  width: 100%;
  border-top: 1px solid var(--color-border-secondary);
  padding-top: 40px;
  padding-bottom: 80px;
  background-color: var(--color-bg-primary);
  color: var(--color-white);
}
[data-dark-mode=true] ._footer_14gre_2 {
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  border-top: 1px solid var(--color-border-primary);
}
._footer_14gre_2 p {
  color: var(--color-text-secondary);
  opacity: 0.666;
}
._footer_14gre_2 h4 {
  color: var(--color-fg-primary);
  font-weight: var(--text-semibold);
  opacity: 1;
}
[data-dark-mode=true] ._footer_14gre_2 h4 {
  color: var(--color-fg-white);
}
._footer_14gre_2 svg {
  fill: var(--color-white);
}·
._footerColumns_14gre_31 {
  max-width: calc(var(--layout-max-width-small) + var(--layout-horizontal-margins) * 2);
  margin-right: auto;
  margin-left: auto;
  padding: 8px;
}
@media screen and (min-width: 920px) {
  ._footerColumns_14gre_31 {
    justify-content: space-between;
  }
}·
._footerColumns_14gre_31 ._menuColumn_14gre_43:last-child a::after {
  content: \" ↗\";
  opacity: 0.85;
}·
._linkButton_14gre_48:focus-visible {
  outline: 2px solid currentColor;
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}·
._footerInfo_14gre_54 {
  margin-top: -4%;
  display: flex;
  flex-direction: column;
  gap: 16px;
}·
._menuColumn_14gre_43 {
  margin-bottom: 40px;
  width: var(--layout-width-4-4);
  display: flex;
  gap: 12px;
  flex-direction: column;
}
._menuColumn_14gre_43 p {
  margin-bottom: 0;
}
._menuColumn_14gre_43 ._menuColumnTitle_14gre_71 {
  display: block;
  font-size: var(--text-fs-base);
  line-height: var(--text-lh-body-base);
  font-weight: var(--text-semibold);
  color: var(--color-text-primary);
}
._menuColumn_14gre_43:first-child {
  width: 100%;
  text-align: center;
}
@media screen and (min-width: 480px) and (max-width: 920px) {
  ._menuColumn_14gre_43 {
    width: var(--layout-width-2-4);
  }
  ._menuColumn_14gre_43:nth-child(even) {
    text-align: right;
  }
}
@media screen and (min-width: 920px) {
  ._menuColumn_14gre_43 {
    width: auto;
  }
  ._menuColumn_14gre_43:first-child {
    max-width: 18%;
    min-width: 230px;
    margin-right: -4%;
    text-align: left;
  }
  ._menuColumn_14gre_43:last-child {
    text-align: right;
  }
}
._menuColumn_14gre_43 ul {
  display: block;
}
._menuColumn_14gre_43 li {
  overflow: hidden;
}
._menuColumn_14gre_43 li a,
._menuColumn_14gre_43 li ._linkButton_14gre_48 {
  text-decoration: underline;
  display: inline-block;
  min-width: 48px;
  margin-top: -12px;
  margin-bottom: -12px;
  padding-top: 12px;
  padding-bottom: 20px;
  text-decoration-color: color-mix(in srgb, var(--color-text-secondary), var(--color-bg-primary) 80%);
  text-underline-offset: 4px;
  color: var(--color-text-secondary);
  transition: color 0.25s ease-in-out;
  opacity: 1;
  font-weight: var(--text-regular);
}
._menuColumn_14gre_43 li a:hover,
._menuColumn_14gre_43 li ._linkButton_14gre_48:hover {
  color: var(--color-text-primary);
  opacity: 0.6;
}
._menuColumn_14gre_43 li a:hover .icon,
._menuColumn_14gre_43 li ._linkButton_14gre_48:hover .icon {
  opacity: 1;
}
._menuColumn_14gre_43 .icon {
  display: inline;
  position: relative;
  width: 22px;
  height: 22px;
  top: -1px;
  margin-right: 4px;
  opacity: 0.6666;
  transition: opacity 0.25s ease-in-out;
  fill: var(--color-text-tertiary);
}
[data-dark-mode=true] ._menuColumn_14gre_43 .icon {
  fill: var(--color-fg-white);
}·
._logoContainer_14gre_150 a {
  display: inline-block;
}
@media screen and (min-width: 920px) {
  ._logoContainer_14gre_150 a {
    margin-top: -18px;
    margin-left: -12px;
  }
}
._logoContainer_14gre_150 a .logotype * {
  fill: var(--color-logo-text);
}
[data-dark-mode=true] ._logoContainer_14gre_150 a .logotype * {
  fill: var(--color-white);
}·
._listStyleNone_14gre_166 {
  display: flex;
  flex-direction: row;
  list-style: none;
  padding-left: 0;
  opacity: 0.7;
}
[data-dark-mode=true] ._listStyleNone_14gre_166 {
  opacity: 1;
}·
._headerTitle_14gre_177 {
  padding-top: 16px;
  color: var(--color-text-secondary);
}·
._legalBar_14gre_182 {
  display: flex;
  justify-content: center;
  max-width: calc(var(--layout-max-width-small) + var(--layout-horizontal-margins) * 2);
  margin-right: auto;
  margin-left: auto;
  padding: 24px 8px 0;
}·
._legalLinks_14gre_191 {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px 16px;
  margin: 0;
  overflow: hidden;
}
._legalLinks_14gre_191 li {
  position: relative;
}
._legalLinks_14gre_191 a,
._legalLinks_14gre_191 ._linkButton_14gre_48 {
  color: var(--color-text-secondary);
  font-weight: var(--text-regular);
}
._legalLinks_14gre_191 a:hover,
._legalLinks_14gre_191 ._linkButton_14gre_48:hover {
  color: var(--color-text-primary);
  opacity: 0.6;
}
@media screen and (min-width: 920px) {
  ._legalLinks_14gre_191 {
    justify-content: flex-start;
  }
  ._legalLinks_14gre_191 li::before {
    content: \"|\" / \"\";
    position: absolute;
    left: calc(16px / -2);
    transform: translateX(-50%);
    color: var(--color-text-secondary);
    opacity: 0.4;
  }
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/top-bar/ApiTopBar.module.scss\">:root {
  --tab-bar-height: 52px;
}·
._toolbar_13ev0_5 {
  width: 100%;
  position: relative;
  background-color: var(--color-util-brand-100);
}
[data-dark-mode=true] ._toolbar_13ev0_5 {
  background-color: var(--color-bg-primary);
  border-bottom: 1px solid var(--color-border-primary);
}·
._controlsContainer_13ev0_15 {
  display: flex;
  align-items: center;
  height: var(--tab-bar-height);
  padding-left: var(--layout-horizontal-margins);
  margin-left: auto;
  margin-right: auto;
  overflow-x: auto;
}
@media screen and (min-width: 1896px) {
  ._controlsContainer_13ev0_15 {
    padding-left: 0;
    max-width: var(--layout-max-width);
  }
}·
._controls_13ev0_15 {
  display: flex;
  align-items: center;
  min-height: 36px;
}
._controls_13ev0_15 > * {
  flex-shrink: 0;
}
._controls_13ev0_15 > *:last-child {
  padding-right: 90px;
}
._controls_13ev0_15 select,
._controls_13ev0_15 input {
  max-width: 200px;
  margin-right: 32px;
}·
._scrollIndicator_13ev0_48 {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  width: 70px;
  background: linear-gradient(90deg, transparent 0%, var(--color-util-brand-100));
  pointer-events: none;
}
[data-dark-mode=true] ._scrollIndicator_13ev0_48 {
  background: linear-gradient(90deg, transparent 0%, var(--color-bg-primary));
}·
._videoTour_13ev0_61 {
  display: flex;
  align-items: center;
  gap: 4px;
}
._videoTour_13ev0_61 .icon {
  /* stylelint-disable-next-line color-no-hex -- bespoke pure red video icon (light mode only), no matching token */
  fill: #f00;
}
[data-dark-mode=true] ._videoTour_13ev0_61 .icon {
  fill: var(--color-text-primary);
}·
._toolbarNav_13ev0_74 {
  position: sticky;
  top: var(--header-nav-height);
  z-index: 2;
}
._toolbarNav_13ev0_74 ul {
  display: flex;
  gap: 32px;
}
._toolbarNav_13ev0_74 li {
  position: relative;
}
._toolbarNav_13ev0_74 li::before {
  content: \"\";
  position: absolute;
  width: 100%;
  height: 2px;
  left: 0;
  bottom: -2px;
  border-radius: 1px;
  background-color: var(--color-link);
  opacity: 0;
  transform: scaleX(0);
  transition: transform 0.33s ease-in-out, opacity 0.33s ease-in-out;
}
._toolbarNav_13ev0_74 li:hover::before {
  opacity: 0.4;
  transform: scaleX(1);
}
._toolbarNav_13ev0_74 li._active_13ev0_103::before {
  opacity: 1;
  transform: scaleX(1);
}
._toolbarNav_13ev0_74 a {
  display: block;
  font-weight: 500;
}
[data-dark-mode=true] ._toolbarNav_13ev0_74 a {
  color: var(--color-fg-primary);
}
._toolbarNav_13ev0_74 a:hover {
  color: var(--color-link);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/announcement-banner/AnnouncementBanner.module.scss\">._banner_1o6uq_1 {
  display: none;
  position: relative;
  overflow: hidden;
  max-height: 200px;
  background-color: var(--color-brand-900);
  z-index: 10005;
  transition: max-height 0.25s ease-in-out, transform 0.25s ease-in-out, opacity 0.25s ease-in-out;
}
._banner_1o6uq_1.is-dismissing {
  max-height: 0;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-100%);
}·
html[data-show-announcement='true'] ._banner_1o6uq_1 {
  display: block;
}·
._link_1o6uq_21 {
  display: block;
  color: var(--color-white);
  text-decoration: none;
  transition: background-color 0.25s ease-in-out;
}
._link_1o6uq_21:hover {
  background-color: var(--color-brand-950);
  color: var(--color-white);
  text-decoration: none;
}
._link_1o6uq_21:hover ._ctaLabel_1o6uq_32 {
  text-decoration: underline;
}
._link_1o6uq_21:hover ._cta_1o6uq_32 .icon {
  transform: translateX(2px);
}
._link_1o6uq_21:focus-visible {
  outline: 2px solid var(--color-button-primary-shadow-focus);
  outline-offset: -2px;
}·
._inner_1o6uq_43 {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  max-width: calc(var(--layout-max-width) + var(--layout-horizontal-margins) * 2);
  margin: 0 auto;
  padding: 8px calc(var(--layout-horizontal-margins) + 24px) 8px var(--layout-horizontal-margins);
  line-height: 1.3;
  text-align: center;
}
@media screen and (min-width: 960px) {
  ._inner_1o6uq_43 {
    gap: 16px;
  }
}·
._close_1o6uq_60 {
  position: absolute;
  top: 50%;
  right: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0 0 0 2px;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--color-white);
  opacity: 0.8;
  cursor: pointer;
  transform: translateY(-50%);
  transition: opacity 0.25s ease-in-out, background-color 0.25s ease-in-out;
}
._close_1o6uq_60:hover {
  opacity: 1;
  background-color: rgba(255, 255, 255, 0.1);
}
._close_1o6uq_60:focus-visible {
  outline: 2px solid var(--color-button-primary-shadow-focus);
  outline-offset: -2px;
  opacity: 1;
}
._close_1o6uq_60 .icon {
  --icon-size: 16px;
  --icon-color: var(--color-white);
  fill: var(--color-white);
}·
._badge_1o6uq_94 {
  flex-shrink: 0;
  padding: 2px 8px;
  border-radius: var(--radius-md);
  background-color: var(--color-util-brand-500);
  color: var(--color-white);
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  white-space: nowrap;
}·
._text_1o6uq_106 {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: baseline;
  justify-content: center;
  gap: 4px 8px;
  min-width: 0;
}·
._title_1o6uq_115 {
  font-weight: 600;
}·
._description_1o6uq_119 {
  color: var(--color-brand-200);
}
@media screen and (max-width: 520px) {
  ._description_1o6uq_119 {
    display: none;
  }
}·
._cta_1o6uq_32 {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  gap: 4px;
  font-weight: 500;
  white-space: nowrap;
}
._cta_1o6uq_32 .icon {
  --icon-size: 16px;
  --icon-color: var(--color-white);
  fill: var(--color-white);
  transition: transform 0.25s ease-in-out;
}·
@media screen and (max-width: 520px) {
  ._ctaLabel_1o6uq_32 {
    display: none;
  }
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/layouts/Layout.astro?astro&amp;type=style&amp;index=0&amp;lang.css\">:root {
  --dark-icon: var(--darkModeCSSUrl);
}·
html[data-dark-mode=\"true\"] {
  --dark-icon: var(--lightModeCSSUrl);
}
</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/layouts/Layout.astro?astro&amp;type=style&amp;index=1&amp;lang.css\">html, body {
  overflow-x: clip;
}·
html {
  position: relative;
}·
main[data-astro-cid-ju4pidww] {
  display: contents;
}·
body {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}·
.mainContainer[data-astro-cid-ju4pidww] {
  display: flex;
  flex-direction: column;
  flex: 1 0 auto;
  width: 100%;
  padding: 0;
}
</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/markdown-actions/MarkdownActions.module.scss\">._markdownActions_qgpvn_1 {
  display: flex;
  align-items: stretch;
}·
._trigger_qgpvn_6 {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  height: 36px;
  padding-block: 0;
  border: 1px solid var(--color-input-border);
  border-radius: var(--radius-sm);
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  font-size: var(--text-fs-base);
  font-weight: var(--text-regular);
  white-space: nowrap;
}
._trigger_qgpvn_6:hover, ._trigger_qgpvn_6:active {
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-input-border-hover);
}
[data-dark-mode=true] ._trigger_qgpvn_6:hover, [data-dark-mode=true] ._trigger_qgpvn_6:active {
  border: 1px solid var(--color-brand-200);
}
[data-dark-mode=true] ._trigger_qgpvn_6:focus-visible {
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--color-brand-200), var(--color-bg-primary) 60%), var(--shadow-xs);
}·
._triggerLabel_qgpvn_33 {
  display: flex;
  align-items: center;
  gap: 8px;
}·
._triggerIcon_qgpvn_39 {
  flex: none;
  width: 16px;
  height: 16px;
}·
._labelStack_qgpvn_45 {
  display: grid;
}
._labelStack_qgpvn_45 > * {
  grid-area: 1/1;
}·
._labelSizer_qgpvn_52 {
  visibility: hidden;
}·
._chevron_qgpvn_56 {
  width: 16px;
  height: 16px;
  opacity: 0.5;
}·
._content_qgpvn_62 {
  min-width: 260px;
  overflow: hidden;
  padding: 6px;
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  border-radius: var(--radius-sm);
  box-shadow: 0px 10px 38px -10px rgba(22, 23, 24, 0.35), 0px 10px 20px -15px rgba(22, 23, 24, 0.2);
  z-index: 1000;
}
[data-dark-mode=true] ._content_qgpvn_62 {
  background: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 12%);
  border: 1px solid color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 22%);
}
._content_qgpvn_62[data-state=open] {
  animation: _menuScaleInDown_qgpvn_1 150ms cubic-bezier(0.4, 0, 1, 1);
}·
@keyframes _menuScaleInDown_qgpvn_1 {
  from {
    opacity: 0;
    transform: translateY(-10px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0px) scale(1);
  }
}
._item_qgpvn_90 {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 3px;
  color: var(--color-text-primary);
  white-space: nowrap;
  user-select: none;
  cursor: pointer;
}
[data-dark-mode=true] ._item_qgpvn_90 {
  color: var(--color-fg-white);
}
._item_qgpvn_90[data-highlighted] {
  outline: none;
  background-color: var(--color-util-brand-50);
}
[data-dark-mode=true] ._item_qgpvn_90[data-highlighted] {
  background-color: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 20%);
}·
._itemIcon_qgpvn_112 {
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 16px;
  height: calc(var(--text-fs-base) * var(--text-lh-body-base));
}
._itemIcon_qgpvn_112 svg {
  display: block;
  width: 16px;
  height: auto;
}·
._itemText_qgpvn_126 {
  display: flex;
  flex-direction: column;
}·
._itemLabel_qgpvn_131 {
  font-size: var(--text-fs-base);
  line-height: var(--text-lh-body-base);
  font-weight: var(--text-regular);
  color: var(--color-fg-primary);
}·
._itemDescription_qgpvn_138 {
  font-size: var(--text-fs-sm);
  font-weight: var(--text-regular);
  color: var(--color-text-secondary);
  opacity: 0.85;
}·
._srOnly_qgpvn_145 {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}·
[data-dark-mode=true] ._monochromeIcon_qgpvn_154 path[fill=\"#000\"] {
  fill: var(--color-fg-white);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/select/Select.module.scss\">._trigger_64ihr_1._large_64ihr_1 {
  height: 36px;
}
._trigger_64ihr_1._large_64ihr_1 span {
  font-size: var(--text-fs-base);
}·
._trigger_64ihr_1 {
  display: flex;
  align-items: center;
  border-radius: var(--radius-sm);
  font-weight: normal;
  height: 32px;
  padding-block: 0;
  gap: 16px;
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-input-border);
  font-size: 14px;
  justify-content: space-between;
}
._trigger_64ihr_1:hover, ._trigger_64ihr_1:active {
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-input-border-hover);
}
[data-dark-mode=true] ._trigger_64ihr_1:hover, [data-dark-mode=true] ._trigger_64ihr_1:active {
  border: 1px solid var(--color-brand-200);
}
[data-dark-mode=true] ._trigger_64ihr_1:focus-visible {
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--color-brand-200), var(--color-bg-primary) 60%), var(--shadow-xs);
}·
._content_64ihr_34._large_64ihr_1 {
  min-width: 150px;
}·
._content_64ihr_34 {
  min-width: max(230px, var(--radix-popper-anchor-width, 230px));
  position: absolute;
  overflow: hidden;
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  border-radius: 6px;
  box-shadow: 0px 10px 38px -10px rgba(22, 23, 24, 0.35), 0px 10px 20px -15px rgba(22, 23, 24, 0.2);
  z-index: 10010;
  padding: 6px;
}
[data-dark-mode=true] ._content_64ihr_34 {
  background: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 12%);
  border: 1px solid color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 22%);
}
._content_64ihr_34 ._SelectScrollButton_64ihr_53 {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 25px;
  color: var(--violet-11);
  cursor: default;
}
._content_64ihr_34._constrainHeight_64ihr_61 {
  max-height: 400px;
}·
._item_64ihr_65._large_64ihr_1 {
  font-size: var(--text-fs-base);
  height: 32px;
}·
._item_64ihr_65 {
  font-size: 14px;
  line-height: 1;
  color: var(--color-text-primary);
  border-radius: 3px;
  display: flex;
  gap: 8px;
  align-items: center;
  height: 28px;
  padding: 0 12px;
  position: relative;
  user-select: none;
  cursor: pointer;
  justify-content: space-between;
}
[data-dark-mode=true] ._item_64ihr_65 {
  color: var(--color-fg-white);
}
._item_64ihr_65[data-disabled] {
  opacity: 0.5;
  pointer-events: none;
}
._item_64ihr_65[data-highlighted] {
  outline: none;
  background-color: var(--color-util-brand-50);
}
[data-dark-mode=true] ._item_64ihr_65[data-highlighted] {
  background-color: color-mix(in srgb, var(--color-bg-primary), var(--color-fg-white) 20%);
}·
._indicator_64ihr_100 {
  position: absolute;
  left: 0;
  width: 25px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}·
._chevronDown_64ihr_109 {
  display: block;
  opacity: 0.5;
  height: 16px;
  width: 16px;
}·
._label_64ihr_116 {
  padding: 0 12px;
  font-size: 14px;
  line-height: 25px;
  font-weight: 600;
  color: var(--mauve-11);
}·
@keyframes _fadeIn_64ihr_1 {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes _fadeOut_64ihr_1 {
  from {
    opacity: 0.8;
  }
  to {
    opacity: 0;
  }
}
@keyframes _selectScaleInDown_64ihr_1 {
  from {
    opacity: 0;
    transform: translateY(-10px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0px) scale(1);
  }
}
._content_64ihr_34._popper_64ihr_150[data-state=open] {
  animation: _selectScaleInDown_64ihr_1 150ms cubic-bezier(0.4, 0, 1, 1);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/framework-selector-inside-doc/FrameworkSelectorInsideDocs.module.scss\">._frameworkLogo_tqwu3_1 {
  width: 16px;
  height: 16px;
  border-radius: 4px;
}·
._frameworkItem_tqwu3_7 {
  display: flex;
  gap: 8px;
  align-items: center;
}·
._select_tqwu3_13 {
  width: 160px;
}·
._frameworkVersionLinks_tqwu3_17 {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/docs/components/Header.module.scss\">._docsPageHeader_xp6zp_1 {
  position: relative;
}
@media screen and (min-width: 1475px) {
  .largeExamples ._docsPageHeader_xp6zp_1 {
    width: calc(139% - 40px);
  }
}·
._docsPageTitle_xp6zp_10 {
  display: contents;
  color: var(--color-fg-primary);
}
@media screen and (min-width: 1100px) {
  ._docsPageTitle_xp6zp_10 {
    line-height: var(--line-height-ultra-tight);
  }
}·
._titleText_xp6zp_20 {
  grid-area: title;
  margin-bottom: 16px;
  letter-spacing: -1.2px;
}·
._pageTitleContainer_xp6zp_26, ._pageTitleContainerNoEyebrow_xp6zp_26 {
  display: grid;
  width: 100%;
  grid-template-columns: auto 1fr;
  grid-template-areas: \"meta version\" \"actions actions\" \"title title\";
  row-gap: 12px;
  column-gap: 12px;
}
@media screen and (min-width: 720px) {
  ._pageTitleContainer_xp6zp_26, ._pageTitleContainerNoEyebrow_xp6zp_26 {
    grid-template-columns: auto 1fr auto;
    grid-template-areas: \"meta version actions\" \"title title actions\";
  }
}·
._pageTitleContainerNoEyebrow_xp6zp_26 {
  grid-template-columns: 1fr;
  grid-template-areas: \"version\" \"actions\" \"title\";
}
@media screen and (min-width: 720px) {
  ._pageTitleContainerNoEyebrow_xp6zp_26 {
    grid-template-columns: 1fr auto;
    grid-template-areas: \"version actions\" \"title actions\";
  }
}·
._headerFramework_xp6zp_52 {
  grid-area: meta;
  align-self: baseline;
  font-size: var(--text-fs-base);
  font-weight: var(--text-semibold);
  line-height: var(--text-lh-body-base);
  color: var(--color-text-brand-primary);
}·
._headerFrameworkLink_xp6zp_61 {
  color: inherit;
  text-decoration: none;
}
._headerFrameworkLink_xp6zp_61:hover, ._headerFrameworkLink_xp6zp_61:focus-visible {
  text-decoration: underline;
}·
._version_xp6zp_69 {
  grid-area: version;
  align-self: baseline;
  justify-self: start;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-regular);
  line-height: var(--text-lh-body-sm);
  color: var(--color-text-tertiary);
}·
._headerActions_xp6zp_79 {
  grid-area: actions;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  align-self: start;
  justify-self: start;
  gap: 12px;
}
@media screen and (min-width: 720px) {
  ._headerActions_xp6zp_79 {
    justify-self: end;
    gap: 8px;
  }
}·
._frameworkSelectorSlot_xp6zp_95 {
  order: -1;
}
@media screen and (min-width: 720px) {
  ._frameworkSelectorSlot_xp6zp_95 {
    order: 0;
  }
}·
._enterpriseLabel_xp6zp_104 {
  display: inline-block;
  position: relative;
  bottom: 0.05em;
  font-size: var(--text-fs-xl);
  font-weight: var(--text-regular);
  color: var(--color-text-tertiary);
  text-decoration: none;
}
._enterpriseLabel_xp6zp_104:hover, ._enterpriseLabel_xp6zp_104:focus-visible {
  text-decoration: underline;
}
@media screen and (min-width: 720px) {
  ._enterpriseLabel_xp6zp_104 {
    position: absolute;
    top: 2.25em;
    right: -2px;
    bottom: auto;
    padding-left: 0;
  }
}
._enterpriseLabel_xp6zp_104 .icon {
  --icon-size: 1.25em;
  --icon-color: var(--color-enterprise-icon);
  position: relative;
  top: -0.1em;
  margin-left: 4px;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/pages-navigation/components/SideNavigation.module.scss\">._sideNav_cvzbf_1 {
  --left-margin: 64px;
  --link-color: var(--color-util-gray-500);
  --active-color: var(--color-brand-500);
  --active-border: var(--color-brand-500);
  --hover-background: var(--color-util-brand-50);
  --active-background: var(--color-util-brand-50);
  display: none;
  width: calc(var(--layout-width-3-12) - var(--left-margin));
  margin-left: 32px;
  padding-top: 34px;
  padding-bottom: 16px;
  padding-left: 8px;
  line-height: var(--text-lh-ratio-base);
}
[data-dark-mode=true] ._sideNav_cvzbf_1 {
  --link-color: var(--color-gray-400);
  --active-color: var(--color-brand-300);
  --active-border: var(--color-brand-300);
  /* stylelint-disable function-disallowed-list -- old brand blue (#3892f9) tints, no matching token */
  --hover-background: rgba(56, 146, 249, 0.06);
  --active-background: rgba(56, 146, 249, 0.09);
  /* stylelint-enable function-disallowed-list */
}
@supports (position: sticky) {
  ._sideNav_cvzbf_1 {
    padding-top: 0;
    padding-bottom: 0;
  }
}
@media screen and (min-width: 1475px) {
  ._sideNav_cvzbf_1 {
    display: block;
  }
}
@supports (position: sticky) {
  ._sideNav_cvzbf_1 > div {
    display: flex;
    flex-direction: column;
    margin-right: calc(var(--layout-horizontal-margins) * -1);
    padding-top: 34px;
    padding-right: 32px;
    padding-bottom: 4px;
    position: sticky;
    top: var(--layout-site-header-height);
    max-height: calc(100vh - var(--layout-site-header-height));
    overflow: hidden;
    overflow-y: auto;
  }
}·
._sideNav_cvzbf_1 ul {
  --nav-line-color: var(--color-util-gray-300);
  display: inline-flex;
  position: relative;
  flex-direction: column;
  padding-left: 0;
  padding-bottom: 0;
  margin-top: 0;
  margin-bottom: 0;
  list-style: none;
  z-index: -2;
}
[data-dark-mode=true] ._sideNav_cvzbf_1 ul {
  --nav-line-color: var(--color-border-primary);
}·
._sideNav_cvzbf_1 li:where(:not(._level1_cvzbf_68)) {
  --item-gap: 0.875em;
  position: relative;
  margin-bottom: 0;
  padding-top: calc(var(--item-gap) / 2);
  padding-right: 8px;
  padding-bottom: calc(var(--item-gap) / 2);
  padding-left: 16px;
  transition: background-color 0.25s ease-in-out;
}
._sideNav_cvzbf_1 li:where(:not(._level1_cvzbf_68))::before {
  content: \"\";
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 1px;
  background-color: var(--color-util-brand-200);
  transition: width 0.25s ease-in-out, background-color 0.25s ease-in-out;
}
[data-dark-mode=true] ._sideNav_cvzbf_1 li:where(:not(._level1_cvzbf_68))::before {
  background-color: var(--color-border-primary);
}
._sideNav_cvzbf_1 li:where(:not(._level1_cvzbf_68)):has(.active) {
  background-color: var(--active-background);
}
._sideNav_cvzbf_1 li:where(:not(._level1_cvzbf_68)):has(.active)::before {
  background-color: var(--active-border);
}·
._sideNav_cvzbf_1 li:first-child:has(.active) + li {
  background-color: var(--active-background);
}
._sideNav_cvzbf_1 li:first-child:has(.active) + li::before {
  background-color: var(--active-border);
}
._sideNav_cvzbf_1 li:first-child:has(.active) + li a {
  color: var(--active-color);
}·
._sideNav_cvzbf_1 a {
  display: inline-block;
  padding: 0;
  color: var(--link-color);
  transition: color 0.25s ease-in-out;
  font-weight: 500;
}
._sideNav_cvzbf_1 a:hover, ._sideNav_cvzbf_1 a.active {
  color: var(--active-color);
}·
._sideNav_cvzbf_1 ._level1_cvzbf_68 {
  margin-top: 0;
}
._sideNav_cvzbf_1 ._level1_cvzbf_68 a {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding-left: 0;
  padding-bottom: 8px;
  color: var(--color-text-secondary);
  font-size: 19px;
}
._sideNav_cvzbf_1 ._level1_cvzbf_68 a.active {
  color: var(--color-fg-secondary);
}
._sideNav_cvzbf_1 ._level1_cvzbf_68 a:hover {
  color: var(--color-text-secondary);
}·
._backToTop_cvzbf_138 {
  margin-top: 0;
  padding-top: 16px;
  padding-bottom: 0.4375em;
  padding-right: 8px;
  border-left: none;
  align-self: flex-start;
}
._backToTop_cvzbf_138 a {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding-left: 0;
  color: var(--color-text-secondary) !important;
  font-size: 15px;
  font-weight: 500;
  text-decoration: none;
  transition: color 0.25s ease-in-out;
}
._backToTop_cvzbf_138 a:hover {
  color: var(--color-fg-primary);
}
._backToTop_cvzbf_138 a:hover ._backToTopIcon_cvzbf_160 {
  color: var(--color-fg-primary);
  fill: var(--color-fg-primary);
}·
._backToTopIcon_cvzbf_160 {
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  width: 20px;
  height: 20px;
  vertical-align: middle;
  color: var(--color-util-gray-500);
  fill: var(--color-util-gray-500);
  transition: color 0.25s ease-in-out, fill 0.25s ease-in-out;
}·
._sideNav_cvzbf_1 ._level3_cvzbf_177 {
  --item-gap: calc(0.5em + 4px);
  font-weight: var(--text-regular);
}·
._sideNav_cvzbf_1 ._level3_cvzbf_177,
._sideNav_cvzbf_1 ._level4_cvzbf_183,
._sideNav_cvzbf_1 ._level5_cvzbf_184,
._sideNav_cvzbf_1 ._level6_cvzbf_185 {
  padding-left: 32px;
}·
._sideNav_cvzbf_1 ._level4_cvzbf_183,
._sideNav_cvzbf_1 ._level5_cvzbf_184,
._sideNav_cvzbf_1 ._level6_cvzbf_185 {
  --item-gap: 0.4375em;
  font-size: var(--text-fs-base);
  opacity: 0.8;
}·
._hidden_cvzbf_197 {
  display: none;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/docs-navigation/DocsNav.module.scss\">@media screen and (min-width: 1100px) {
  .layout-grid:has(#docs-mobile-nav-collapser) {
    flex: 1 0 auto;
  }
  #docs-mobile-nav-collapser {
    --right-margin: 64px;
    height: unset !important;
    width: calc(var(--layout-width-3-12));
    overflow: unset !important;
    contain: size;
  }
  #docs-mobile-nav-collapser > div {
    display: flex !important;
    flex-direction: column;
    height: 100%;
  }
}
@media screen and (min-width: 1475px) {
  #docs-mobile-nav-collapser {
    width: calc(var(--layout-width-3-12) - var(--right-margin));
  }
}
._docsNavOuter_m2pa9_23 {
  --nav-max-width: 276px;
  --item-min-height: 34px;
  --indent-size: 16px;
  --indent-initial-offset: 8px;
  --indent-border-offset: 4px;
  --item-border-color: var(--color-util-gray-300);
  --item-active-color: var(--color-util-brand-500);
  --item-active-bg-color: var(--color-util-brand-50);
  --item-active-border-color: var(--color-util-brand-400);
  --item-focus-color: var(--color-util-brand-300);
  --item-chevron-color: var(--color-util-gray-400);
  position: sticky;
  width: 100%;
  top: 0;
  overflow-x: hidden;
  overflow-y: auto;
}
@media screen and (min-width: 1100px) {
  ._docsNavOuter_m2pa9_23 {
    flex: 1 1 auto;
    min-height: 0;
    max-height: 100vh;
  }
}
@media screen and (min-width: 1100px) and (min-width: 1275px) {
  ._docsNavOuter_m2pa9_23 {
    max-height: calc(100vh - var(--layout-site-header-height));
  }
}
@media screen and (min-width: 1275px) {
  ._docsNavOuter_m2pa9_23 {
    top: var(--layout-site-header-height);
  }
}
[data-dark-mode=true] ._docsNavOuter_m2pa9_23 {
  --item-border-color: var(--color-util-gray-500);
  --item-active-color: var(--color-util-brand-700);
  --item-active-bg-color: color-mix(in srgb, var(--color-brand-400) 10%, transparent);
  color: var(--color-util-brand-700);
  --item-active-border-color: var(--color-util-brand-700);
  --item-focus-color: var(--color-util-brand-700);
  --item-chevron-color: var(--color-util-gray-500);
}·
._docsNavInner_m2pa9_68 {
  padding-top: 40px;
  padding-bottom: 32px;
}
@media screen and (min-width: 1100px) {
  ._docsNavInner_m2pa9_68 {
    padding-bottom: 128px;
  }
}
@media screen and (min-width: 1475px) {
  ._docsNavInner_m2pa9_68 {
    max-width: var(--nav-max-width);
  }
}·
._whatsNewLink_m2pa9_83 a {
  --height: 26px;
  --hover-bg-color: color-mix(in srgb, var(--color-logo-orange) 5%, var(--color-bg-primary));
  display: block;
  position: relative;
  width: fit-content;
  height: var(--height);
  margin-bottom: 16px;
  margin-left: 8px;
  padding: 2px 10px;
  border-radius: var(--height);
  font-size: var(--text-fs-sm);
  text-decoration: none;
  color: var(--color-logo-orange);
  border: 1px solid var(--color-logo-orange);
  transition: background-color 0.25s ease-in-out, color 0.25s ease-in-out;
  -webkit-font-smoothing: auto;
}
._whatsNewLink_m2pa9_83 a:hover, ._whatsNewLink_m2pa9_83 a:focus {
  background-color: var(--hover-bg-color);
  color: var(--color-logo-orange);
}
[data-dark-mode=true] ._whatsNewLink_m2pa9_83 a {
  --hover-bg-color: color-mix(in srgb, var(--color-logo-orange) 15%, var(--color-bg-primary));
}·
@media screen and (min-width: 1100px) {
  ._section_m2pa9_110 {
    max-width: var(--nav-max-width);
  }
}·
._sectionTitle_m2pa9_115,
._groupTitle_m2pa9_116,
._item_m2pa9_117 {
  display: flex;
  align-items: center;
  margin: 0;
  min-height: var(--item-min-height);
}·
._sectionTitle_m2pa9_115 {
  padding-left: var(--indent-initial-offset);
  text-transform: uppercase;
  color: var(--color-util-gray-500);
}
[data-dark-mode=true] ._sectionTitle_m2pa9_115 {
  color: var(--color-util-gray-600);
}·
._divider_m2pa9_133 {
  margin-top: 24px;
  margin-bottom: 12px;
  margin-left: var(--indent-initial-offset);
  background-color: var(--color-border-secondary);
}·
._groupTitle_m2pa9_116 {
  position: relative;
  width: 100%;
  padding-left: calc(var(--indent-size) + var(--indent-initial-offset));
  font-weight: var(--text-semibold);
  transition: color 0.25s ease-in-out;
}
._groupTitle_m2pa9_116:hover {
  color: var(--item-active-color);
}
._groupTitle_m2pa9_116:focus-visible {
  outline: var(--item-focus-color) solid 2px;
  outline-offset: -2px;
}·
._groupChevron_m2pa9_155.icon {
  position: absolute;
  left: calc(var(--indent-border-offset) * -1 + var(--indent-initial-offset));
  top: 7px;
  bottom: auto;
  width: 20px;
  height: 20px;
  margin: 0;
  fill: var(--item-chevron-color);
  transition: transform 0.25s ease-in-out, fill 0.25s ease-in-out;
}
._groupTitle_m2pa9_116:hover ._groupChevron_m2pa9_155.icon {
  transform: translate(2px, 0);
}
._group_m2pa9_116._isOpen_m2pa9_169 ._groupChevron_m2pa9_155.icon {
  fill: var(--color-fg-primary);
  transform: rotate(90deg) translate(0, 2px);
}·
._groupChildren_m2pa9_174 {
  display: flex;
  flex-direction: column;
}·
._nestedItems_m2pa9_179 {
  border-left: 1px solid var(--item-border-color);
  margin-left: calc(var(--indent-initial-offset) + var(--indent-border-offset));
  padding-left: var(--indent-initial-offset);
}·
._item_m2pa9_117 {
  color: var(--color-fg-primary);
  padding-left: var(--indent-initial-offset);
  transition: background-color 0.25s ease-in-out, color 0.25s ease-in-out, border-color 0.25s ease-in-out;
}
._item_m2pa9_117:where([href]):hover, ._item_m2pa9_117._isActive_m2pa9_190 {
  background-color: var(--item-active-bg-color);
  color: var(--item-active-color);
}
._item_m2pa9_117:focus-visible {
  outline: var(--item-focus-color) solid 2px;
  outline-offset: -2px;
  border-radius: var(--radius-sm);
}
._item_m2pa9_117._hasIcon_m2pa9_199:not(:last-child) {
  margin-bottom: 4px;
}
._groupChildren_m2pa9_174 ._item_m2pa9_117 {
  margin-left: calc(var(--indent-size) - var(--indent-border-offset));
  padding-left: calc(var(--indent-initial-offset) + var(--indent-border-offset));
  border-left: 1px solid var(--item-border-color);
}
._groupChildren_m2pa9_174 ._item_m2pa9_117:not([href]:hover, ._isActive_m2pa9_190) {
  color: var(--color-fg-secondary);
}
._groupChildren_m2pa9_174 ._item_m2pa9_117._isActive_m2pa9_190 {
  border-left: 1px solid var(--item-active-border-color);
}·
._titleTail_m2pa9_214 {
  white-space: nowrap;
}·
._itemIcon_m2pa9_218.icon,
._externalIcon_m2pa9_219.icon {
  fill: var(--color-fg-secondary);
  transition: fill 0.25s ease-in-out;
}
._item_m2pa9_117:hover ._itemIcon_m2pa9_218.icon, ._item_m2pa9_117._isActive_m2pa9_190 ._itemIcon_m2pa9_218.icon,
._item_m2pa9_117:hover ._externalIcon_m2pa9_219.icon,
._item_m2pa9_117._isActive_m2pa9_190 ._externalIcon_m2pa9_219.icon {
  fill: var(--item-active-color);
}·
._itemIcon_m2pa9_218.icon {
  margin-right: 8px;
}·
._enterpriseIcon_m2pa9_233.icon,
._externalIcon_m2pa9_219.icon {
  width: 20px;
  height: 20px;
  margin-left: 4px;
}·
._enterpriseIcon_m2pa9_233.icon {
  fill: var(--color-enterprise-icon);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/page-styles/docs.module.scss\">._contentViewport_1wzld_1 {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
}
@media (min-width: 1100px) {
  ._contentViewport_1wzld_1 {
    flex-direction: row;
  }
}
._contentViewport_1wzld_1._noLeftMenu_1wzld_11 ._docPage_1wzld_11 {
  width: 100%;
}
@media (min-width: 1475px) {
  ._contentViewport_1wzld_1._noLeftMenu_1wzld_11 ._docPage_1wzld_11 {
    width: var(--layout-width-9-12);
    margin-left: calc(var(--layout-width-3-12) + var(--layout-gap));
  }
}
@media (max-width: 1880px) {
  ._contentViewport_1wzld_1._noLeftMenu_1wzld_11 ._docPage_1wzld_11 {
    width: var(--layout-width-6-12);
  }
}
._contentViewport_1wzld_1._noLeftMenu_1wzld_11 ._docPage_1wzld_11 {
  width: 100%;
}·
._pageSections_1wzld_29 li p {
  padding-bottom: 0;
  margin-bottom: 8px;
}·
._pageSections_1wzld_29 article > h2,
._pageSections_1wzld_29 article > h3,
._pageSections_1wzld_29 article > h3 {
  display: flex;
  align-items: center;
  gap: 8px;
}
._pageSections_1wzld_29 article > h2 {
  margin-top: 48px;
}
._pageSections_1wzld_29 article > h3,
._pageSections_1wzld_29 article > h4 {
  margin-top: 48px;
}
._pageSections_1wzld_29 article > h2 + h3,
._pageSections_1wzld_29 article > h2 + h4,
._pageSections_1wzld_29 article > h3 + h4 {
  margin-top: 32px;
}
._pageSections_1wzld_29 article p,
._pageSections_1wzld_29 article > ul,
._pageSections_1wzld_29 article > ol,
._pageSections_1wzld_29 article > table {
  font-size: var(--text-fs-base);
  line-height: 27px;
}·
h2:where(:not(:last-child)),
h3:where(:not(:last-child)),
h4:where(:not(:last-child)),
h5:where(:not(:last-child)),
h6:where(:not(:last-child)) {
  margin-top: 16px;
  margin-bottom: 8px;
  letter-spacing: -0.015em;
}·
ul:where(:not(:last-child)),
ol:where(:not(:last-child)),
blockquote:where(:not(:last-child)) {
  margin-top: 20px;
  margin-bottom: 20px;
}·
._docPage_1wzld_11 enterprise-icon::after {
  display: inline-block;
  background-image: url(\"/images/enterprise.svg\");
  text-indent: -10000px;
  background-position-y: center;
  background-repeat: no-repeat;
  content: \"e\";
}·
._docPage_1wzld_11 {
  flex: 1 1 0px;
  width: 100%;
  min-width: 0px;
  padding-top: 16px;
  padding-bottom: 64px;
}
@media screen and (max-width: 1475px) {
  ._docPage_1wzld_11 {
    border: none;
  }
}
@media screen and (min-width: 1100px) {
  ._docPage_1wzld_11 {
    width: var(--layout-width-9-12);
    padding-top: 40px;
    padding-right: 12px;
  }
}
@media screen and (min-width: 1475px) {
  ._docPage_1wzld_11 {
    width: var(--layout-width-7-12);
    max-width: var(--layout-width-7-12);
    padding-right: 0;
  }
}
[data-dark-mode='true'] ._docPage_1wzld_11 h1,
[data-dark-mode='true'] ._docPage_1wzld_11 h2,
[data-dark-mode='true'] ._docPage_1wzld_11 h3,
[data-dark-mode='true'] ._docPage_1wzld_11 h4,
[data-dark-mode='true'] ._docPage_1wzld_11 h5,
[data-dark-mode='true'] ._docPage_1wzld_11 h6 {
  color: var(--color-fg-primary);
}
._docPage_1wzld_11 h1:hover .docs-header-icon,
._docPage_1wzld_11 h2:hover .docs-header-icon,
._docPage_1wzld_11 h3:hover .docs-header-icon,
._docPage_1wzld_11 h4:hover .docs-header-icon,
._docPage_1wzld_11 h5:hover .docs-header-icon,
._docPage_1wzld_11 h6:hover .docs-header-icon {
  opacity: 0.5;
}
._docPage_1wzld_11 .docs-header-icon {
  position: relative;
  padding-left: 0;
  margin-left: 8px;
  font-size: inherit;
  opacity: 0;
  transition: opacity 0.33s ease-in-out;
}
._docPage_1wzld_11 .docs-header-icon:hover {
  opacity: 1 !important;
}
._docPage_1wzld_11 .docs-header-icon svg {
  position: relative;
  width: 0.85em;
  height: 0.85em;
  top: -0.1em;
  visibility: visible;
  fill: var(--color-link);
}
[data-dark-mode='true'] ._docPage_1wzld_11 a:not(.button) {
  color: var(--color-brand-300);
}
[data-dark-mode='true'] ._docPage_1wzld_11 a:not(.button):hover {
  color: var(--color-fg-primary);
  text-decoration-color: var(--color-brand-300);
}
._docPage_1wzld_11 enterprise-icon::after {
  width: 1rem;
  margin-left: 0.25rem;
}
._docPage_1wzld_11 .nav-link p {
  margin: 0;
}
._docPage_1wzld_11 ul li > p {
  margin-bottom: 0.25rem;
}·
._pageSections_1wzld_29 > article > table {
  table-layout: fixed;
}·
._pageSections_1wzld_29 > article > p:first-child {
  font-size: var(--text-fs-lg);
  margin-bottom: 32px;
  color: var(--color-text-secondary);
  line-height: var(--text-lh-body-lg);
}
._pageSections_1wzld_29 > article > p:first-child code {
  font-size: var(--text-fs-base);
  line-height: var(--text-lh-body-base);
}·
._pageSections_1wzld_29 > article > div *:not([class]) img {
  max-width: 100%;
}·
._sideMenu_1wzld_185 {
  padding-top: 36px;
}·
#errorCodeText {
  white-space: pre-wrap;
}·
.missing-params-message {
  display: none;
}·
._docsArchiveContainer_1wzld_197 {
  width: 100%;
}
@media screen and (min-width: 1100px) {
  ._docsArchiveContainer_1wzld_197 {
    width: calc(var(--layout-width-9-12));
    padding-top: 40px;
  }
}
@media screen and (min-width: 1475px) {
  ._docsArchiveContainer_1wzld_197 {
    width: calc(var(--layout-width-9-12) + 64px);
  }
}</style><script type=\"module\" src=\"/@vite/client\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/astro/components/ClientRouter.astro?astro&type=style&index=0&lang.css\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/icon/Icon.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/site-header/SiteHeader.module.scss\"></script><script type=\"module\" src=\"/src/components/logo/LogoMark.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/Search.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/getting-started/getting-started.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchBox.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchControls.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchHits.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/SearchModal.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/product-dropdown/ProductDropdown.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/design-system/design-system.scss?url\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/dev-tools/DevTools.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/footer/Footer.module.scss\"></script><script type=\"module\" src=\"/src/components/top-bar/ApiTopBar.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/announcement-banner/AnnouncementBanner.module.scss\"></script><script type=\"module\" src=\"/src/layouts/Layout.astro?astro&type=style&index=0&lang.css\"></script><script type=\"module\" src=\"/src/layouts/Layout.astro?astro&type=style&index=1&lang.css\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/markdown-actions/MarkdownActions.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/select/Select.module.scss\"></script><script type=\"module\" src=\"/src/components/framework-selector-inside-doc/FrameworkSelectorInsideDocs.module.scss\"></script><script type=\"module\" src=\"/src/components/docs/components/Header.module.scss\"></script><script type=\"module\" src=\"/src/components/pages-navigation/components/SideNavigation.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/docs-navigation/DocsNav.module.scss\"></script><script type=\"module\" src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/page-styles/docs.module.scss\"></script><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/example-runner/components/ExampleLogger.module.scss\">._loggerOuter_r6vdv_1 {
  min-height: 154px;
  height: 154px;
  max-height: 700px;
  resize: vertical;
  display: flex;
  flex-direction: column;
  margin-top: 16px;
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border-primary);
  overflow: hidden;
}
@media screen and (max-width: 720px) {
  ._loggerOuter_r6vdv_1 {
    display: none;
  }
}·
._loggerHeader_r6vdv_19 {
  padding: 8px;
  font-family: var(--text-monospace-font-family);
  font-size: var(--text-fs-xs);
  font-weight: var(--text-semibold);
  border-bottom: 1px solid var(--color-border-secondary);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
._loggerHeader_r6vdv_19 button {
  padding: 0.08em 0.5em 0;
}·
._loggerPre_r6vdv_33 {
  margin: 0 0 -1px;
  padding: 0;
  font-size: var(--text-fs-xs);
  border-radius: 0;
  border: none;
  overflow-y: auto;
  overflow-x: hidden;
}
[data-dark-mode=true] ._loggerPre_r6vdv_33 {
  background-color: var(--color-gray-900);
  color: var(--color-text-secondary);
}·
._logItem_r6vdv_47,
._placeholder_r6vdv_48 {
  display: flex;
  flex-direction: row;
  gap: 8px;
  padding: 8px;
  border-bottom: 1px solid var(--color-border-secondary);
}
._logItem_r6vdv_47:nth-child(odd),
._placeholder_r6vdv_48:nth-child(odd) {
  background-color: color-mix(in srgb, var(--color-bg-primary) 66.66%, transparent);
}·
._count_r6vdv_60 {
  min-width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-fs-2xs);
  border-radius: 8px;
  background-color: var(--color-gray-200);
  color: var(--color-gray-800);
  opacity: 1;
  flex-shrink: 0;
  font-weight: 600;
  padding-left: 4px;
  padding-right: 4px;
}
[data-dark-mode=true] ._count_r6vdv_60 {
  background-color: var(--color-gray-600);
  color: var(--color-gray-300);
}·
._dataItem_r6vdv_81 {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  gap: 8px;
  white-space: pre-wrap;
  line-height: var(--text-lh-ratio-base);
}·
._type-null_r6vdv_90,
._type-undefined_r6vdv_91 {
  color: var(--color-code-keyword);
}·
._type-string_r6vdv_95 {
  color: var(--color-code-string);
}·
._type-symbol_r6vdv_99,
._type-boolean_r6vdv_100,
._type-number_r6vdv_101,
._type-nan_r6vdv_102,
._type-date_r6vdv_103 {
  color: var(--color-code-symbol);
}·
._type-regex_r6vdv_107 {
  color: var(--color-code-property);
}·
.react-json-view {
  font-size: 12px !important;
}
.react-json-view .variable-value {
  text-transform: lowercase;
}
.react-json-view .variable-value span:not(.string-value) {
  text-transform: lowercase;
}
.react-json-view .variable-value .string-value {
  text-transform: none;
}
.react-json-view .variable-value div {
  font-size: 12px !important;
  font-weight: 500 !important;
}
.react-json-view .node-ellipsis {
  font-size: 12px !important;
  font-weight: 500 !important;
}
.react-json-view span {
  font-weight: 500 !important;
}
.react-json-view .brace-row span {
  font-weight: 500 !important;
}
.react-json-view .collapsed-icon svg {
  fill: rgb(88, 110, 117);
}·
._clearButton_r6vdv_141 {
  font-family: var(--text-monospace-font-family);
  color: var(--color-button-secondary-fg);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/open-in-cta/OpenInCTA.module.scss\">._cta_2jr3h_1 {
  position: relative;
  display: inline-block;
}·
a._cta_2jr3h_1,
._cta_2jr3h_1 a,
._cta_2jr3h_1 button {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40px;
  height: 40px;
  border-radius: var(--radius-sm);
  transition: color 0.25s ease-in-out, background-color 0.25s ease-in-out;
  cursor: pointer;
}
a._cta_2jr3h_1:hover,
._cta_2jr3h_1 a:hover,
._cta_2jr3h_1 button:hover {
  background-color: var(--color-util-brand-100);
}
a._cta_2jr3h_1:focus-visible,
._cta_2jr3h_1 a:focus-visible,
._cta_2jr3h_1 button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 4px var(--color-button-primary-shadow-focus), var(--shadow-xs);
}
a._cta_2jr3h_1 svg,
._cta_2jr3h_1 a svg,
._cta_2jr3h_1 button svg {
  --icon-size: 1.25em;
  fill: var(--color-link);
  transform: translate(1px, 0.75px);
  transition: fill 0.25s ease-in-out;
}
li:first-child a._cta_2jr3h_1 svg,
li:first-child ._cta_2jr3h_1 a svg,
li:first-child ._cta_2jr3h_1 button svg {
  --icon-size: 1.35em;
}
[data-dark-mode=true] a._cta_2jr3h_1:hover,
[data-dark-mode=true] ._cta_2jr3h_1 a:hover,
[data-dark-mode=true] ._cta_2jr3h_1 button:hover {
  background-color: var(--color-util-brand-50);
}·
@supports (-webkit-touch-callout: none) {
  ._cta_2jr3h_1 button {
    display: none;
  }
}
._tooltip_2jr3h_53 {
  --tooltip-background: var(--color-fg-primary);
  position: absolute;
  display: block;
  color: var(--color-bg-primary);
  top: -44px;
  left: 50%;
  padding: 4px 16px;
  white-space: nowrap;
  font-weight: 600;
  background-color: var(--tooltip-background);
  border-radius: 6px;
  transform: translate(-50%, 4px);
  opacity: 0;
  pointer-events: none;
  transition-delay: 0;
  transition: opacity 0.165s ease-in, transform 0.165s ease-in;
  z-index: 1;
}
._tooltip_2jr3h_53::before {
  content: \"\";
  position: absolute;
  background-color: var(--tooltip-background);
  width: 16px;
  height: 16px;
  transform: rotate(45deg);
  bottom: -7px;
  left: calc(50% - 8px);
  border-radius: 3px;
  z-index: -1;
}
._cta_2jr3h_1:hover ._tooltip_2jr3h_53 {
  opacity: 1;
  transform: translate(-50%, 0);
  transition: opacity 0.33s ease-in, transform 0.33s ease-in;
  transition-delay: 0.165s;
}
[data-dark-mode=true] ._tooltip_2jr3h_53 {
  --tooltip-background: var(--color-bg-secondary);
  color: var(--color-fg-primary);
  box-shadow: 0 -4px 16px 0 rgba(0, 0, 0, 0.4);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/link-icon/LinkIcon.module.scss\">._linkIcon_v25xf_1 {
  position: relative;
}
._linkIcon_v25xf_1 svg {
  pointer-events: none;
}·
._docsHeaderIcon_v25xf_8 {
  flex: 0 0 28px;
  width: 28px;
  height: 28px;
  padding: 0;
  margin-left: 4px;
  font-size: var(--text-fs-base);
  opacity: 0;
  line-height: 1.2;
  transition: opacity 0.33s ease-in-out;
}
._docsHeaderIcon_v25xf_8 svg {
  --icon-size: 18px;
  --icon-color: var(--color-link);
  position: absolute;
  top: 4px;
  left: 4px;
  bottom: unset;
  margin: 0;
  visibility: visible;
}
._docsHeaderIcon_v25xf_8:hover, ._docsHeaderIcon_v25xf_8:focus-visible, ._docsHeaderIcon_v25xf_8._active_v25xf_29 {
  opacity: 1;
}·
._exampleIcon_v25xf_33 {
  color: red;
}·
h1:hover ._docsHeaderIcon_v25xf_8,
h2:hover ._docsHeaderIcon_v25xf_8,
h3:hover ._docsHeaderIcon_v25xf_8,
h4:hover ._docsHeaderIcon_v25xf_8,
h5:hover ._docsHeaderIcon_v25xf_8,
h6:hover ._docsHeaderIcon_v25xf_8 {
  opacity: 1;
}·
._tooltip_v25xf_46 {
  --tooltip-background: var(--color-fg-primary);
  position: absolute;
  display: block;
  color: var(--color-bg-primary);
  top: -38px;
  left: 50%;
  padding: 4px 16px;
  white-space: nowrap;
  font-size: var(--text-fs-sm);
  background-color: var(--tooltip-background);
  border-radius: 6px;
  transform: translate(-50%, 4px);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.165s ease-in, transform 0.165s ease-in;
  z-index: 1;
}
._tooltip_v25xf_46::before {
  content: \"\";
  position: absolute;
  background-color: var(--tooltip-background);
  width: 16px;
  height: 16px;
  transform: rotate(45deg);
  bottom: -7px;
  left: calc(50% - 8px);
  border-radius: 3px;
  z-index: -1;
}
._linkIcon_v25xf_1:hover ._tooltip_v25xf_46, ._linkIcon_v25xf_1._active_v25xf_29 ._tooltip_v25xf_46 {
  opacity: 1;
  transform: translate(-50%, 0);
  transition: opacity 0.33s ease-in, transform 0.33s ease-in;
}
._linkIcon_v25xf_1._active_v25xf_29 ._tooltip_v25xf_46 {
  animation-name: _bounce_v25xf_1;
  animation-duration: 0.25s;
}
[data-dark-mode=true] ._tooltip_v25xf_46 {
  --tooltip-background: var(--color-bg-secondary);
  color: var(--color-fg-primary);
  box-shadow: 0 -4px 16px 0 rgba(0, 0, 0, 0.4);
}·
@keyframes _bounce_v25xf_1 {
  0% {
    transform: translate(-50%, 0);
  }
  50% {
    transform: translate(-50%, -4px);
  }
  100% {
    transform: translate(-50%, 0);
  }
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/code/Code.module.scss\">._clipboardButtonOuter_8cpmg_1 {
  --clipboard-button-bg: var(--color-code-background);
  --clipboard-button-fg: var(--color-fg-tertiary);
  display: flex;
  align-items: center;
  position: absolute;
  top: 4px;
  right: 4px;
  opacity: 0;
  z-index: 2;
  transition: opacity 0.33s ease-in-out;
}
pre:hover ._clipboardButtonOuter_8cpmg_1, ._clipboardButtonOuter_8cpmg_1._hasCopied_8cpmg_13 {
  opacity: 1;
}
._clipboardButtonOuter_8cpmg_1:hover {
  --clipboard-button-fg: var(--color-util-brand-400);
}
[data-dark-mode=true] ._clipboardButtonOuter_8cpmg_1:hover {
  --clipboard-button-fg: var(--color-link-hover);
}
._clipboardButtonOuter_8cpmg_1._hasCopied_8cpmg_13 {
  --clipboard-button-bg: var(--color-util-gray-700);
  --clipboard-button-fg: var(--color-fg-white);
}
[data-dark-mode=true] ._clipboardButtonOuter_8cpmg_1._hasCopied_8cpmg_13 {
  --clipboard-button-fg: var(--color-bg-primary);
}
.example-runner-outer ._clipboardButtonOuter_8cpmg_1 {
  right: 20px;
}·
._clipboardButton_8cpmg_1,
._clipboardButtonCopied_8cpmg_34 {
  display: flex;
  align-items: center;
  height: 32px;
  background-color: var(--clipboard-button-bg);
  border-top: 1px solid var(--color-border-primary);
  border-bottom: 1px solid var(--color-border-primary);
}·
._clipboardButton_8cpmg_1 {
  width: calc(32px - var(--radius-sm));
  border-top-right-radius: var(--radius-sm);
  border-bottom-right-radius: var(--radius-sm);
  border-right: 1px solid var(--color-border-primary);
  cursor: pointer;
  transition: background-color 0.25s ease-in-out;
}
._clipboardButton_8cpmg_1 svg {
  --icon-size: 22px;
  --icon-color: var(--clipboard-button-fg);
  transition: fill 0.25s ease-in-out;
}·
._clipboardButtonCopiedOuter_8cpmg_57 {
  overflow: hidden;
}·
._clipboardButtonCopied_8cpmg_34 {
  font-size: var(--text-fs-sm);
  font-weight: var(--text-semibold);
  padding-left: 8px;
  padding-right: 8px;
  border-top-left-radius: var(--radius-sm);
  border-bottom-left-radius: var(--radius-sm);
  border-left: 1px solid var(--color-border-primary);
  font-weight: var(--text-regular);
  color: var(--clipboard-button-fg);
  transition: background-color 0.25s ease-in-out, color 0.25s ease-in-out;
  cursor: pointer;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/code/CodeHighlight.module.scss\">._shikiPre_6fujz_1 {
  overflow: auto !important;
}
._shikiPre_6fujz_1 .line {
  -webkit-font-smoothing: subpixel-antialiased;
}·
._shikiPre_6fujz_1.language-bash ._shikiCode_6fujz_8 span,
._shikiPre_6fujz_1.language-shell ._shikiCode_6fujz_8 span {
  color: var(--color-fg-primary) !important;
}·
._lineNumbers_6fujz_13 ._shikiCode_6fujz_8 {
  height: 100%;
  overflow: auto;
  padding-left: 3.8em;
  padding-top: 1.5em;
  padding-bottom: 1.5em;
  position: relative;
}
._lineNumbers_6fujz_13 ._shikiCode_6fujz_8 .line {
  display: block;
  counter-increment: shiki-line;
  line-height: 0.1em;
}
._lineNumbers_6fujz_13 ._shikiCode_6fujz_8 .line::before {
  content: counter(shiki-line);
  display: inline-block;
  width: 2em;
  margin-left: -3.5em;
  margin-right: 1em;
  text-align: right;
  color: var(--color-code-line-number, var(--color-util-brand-500));
  opacity: var(--color-code-line-number-opacity, 0.33);
}
[data-dark-mode=true] ._lineNumbers_6fujz_13 ._shikiCode_6fujz_8 .line::before {
  color: var(--color-code-line-number, var(--color-fg-primary));
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/example-runner/components/CodeOptions.module.scss\">._outer_18dhc_1 {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 8px;
  border-top: 1px solid var(--example-border-color);
}
._outer_18dhc_1 label {
  display: block;
}
._outer_18dhc_1 > div:where(:not(:last-child)) {
  margin-bottom: 8px;
}·
._simpleSelect_18dhc_16 {
  margin-left: 0;
  padding: 0 24px 0 0;
  border: none;
}·
._importInfoIcon_18dhc_22 svg {
  --icon-size: 1.25em;
  --icon-color: var(--color-fg-secondary);
  position: relative;
  bottom: 0.125em;
}
._importInfoIcon_18dhc_22 svg:hover {
  --icon-color: var(--color-link);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/example-runner/components/CodeViewer.module.scss\">._codeViewer_1tyw5_1 {
  --files-min-width: 10em;
  --mobile-header-height: 32px;
  height: 100%;
  container-type: inline-size;
  border-radius: var(--radius-md);
  overflow: hidden;
}
._codeViewer_1tyw5_1._codeViewerBorder_1tyw5_9 {
  border: 1px solid var(--color-border-primary);
}·
._inner_1tyw5_13 {
  display: flex;
  min-width: 100%;
  height: 100%;
  transition: transform 0.33s ease-in-out, min-width 0.33s ease-in-out;
}
@container (width < 640px) {
  ._inner_1tyw5_13 {
    height: calc(100% - var(--mobile-header-height));
  }
  ._hideFiles_1tyw5_23 ._inner_1tyw5_13 {
    transform: translateX(calc(var(--files-min-width) * -1));
    min-width: calc(100% + var(--files-min-width));
  }
}·
._mobileHeader_1tyw5_29 {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0 16px;
  height: var(--mobile-header-height);
  padding: 0 16px;
  border-bottom: 1px solid var(--color-border-secondary);
  overflow-x: auto;
  overflow-y: hidden;
}
@container (width > 640px) {
  ._mobileHeader_1tyw5_29 {
    display: none;
  }
}
._mobileHeader_1tyw5_29 button:not([class^=ag-]),
._mobileHeader_1tyw5_29 span {
  flex-shrink: 0;
}
._mobileHeader_1tyw5_29 svg {
  --icon-size: 1.125em;
  position: relative;
  margin-left: 4px;
  bottom: 0.125em;
}·
._hidden_1tyw5_56 {
  display: none;
}·
._files_1tyw5_60 {
  position: relative;
  flex-shrink: 0;
  min-width: var(--files-min-width);
  overflow-y: auto;
  overflow-x: hidden;
  padding: 8px 0 8px 8px;
  color: var(--color-fg-secondary);
  box-shadow: inset -1px 0 0 0 var(--example-border-color);
}
@container (width < 640px) {
  ._files_1tyw5_60 {
    width: var(--files-min-width);
  }
}
._files_1tyw5_60 ul {
  margin: 0;
}
._files_1tyw5_60 h4 {
  margin-top: 0;
  margin-bottom: 0;
  padding-left: 6px;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-regular);
}
._files_1tyw5_60 h4:not(:first-child) {
  margin-top: 40px;
}·
._file_1tyw5_60 {
  --file-border-color: transparent;
  width: 100%;
  padding: 0 16px 2px 4px;
  margin-bottom: 2px;
  font-size: var(--text-fs-sm);
  font-weight: var(--text-bold);
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--color-fg-primary);
  border-top: 1px solid var(--file-border-color);
  border-left: 1px solid var(--file-border-color);
  border-bottom: 1px solid var(--file-border-color);
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: var(--radius-sm);
  border-top-left-radius: var(--radius-sm);
  transition: color 0.25s ease-in-out, background-color 0.25s ease-in-out, border-color 0.25s ease-in-out;
}
._file_1tyw5_60:hover {
  --file-border-color: var(--color-border-primary);
  color: var(--color-fg-primary);
  background-color: var(--color-bg-primary);
  border-top: 1px solid var(--file-border-color);
  border-left: 1px solid var(--file-border-color);
  border-bottom: 1px solid var(--file-border-color);
}
._file_1tyw5_60:focus-visible {
  border-color: var(--color-util-brand-500);
}
[data-dark-mode=true] ._file_1tyw5_60:focus-visible {
  background-color: var(--color-bg-primary);
}
._file_1tyw5_60._isActive_1tyw5_122 {
  --file-border-color: var(--color-border-primary);
  background-color: color-mix(in srgb, var(--color-bg-secondary), var(--color-bg-primary) 70%);
}
[data-dark-mode=true] ._file_1tyw5_60._isActive_1tyw5_122 {
  background-color: color-mix(in srgb, var(--color-bg-secondary), var(--color-bg-primary) 70%);
}·
._code_1tyw5_1 {
  flex-grow: 1;
  overflow: hidden;
}
._code_1tyw5_1 > div {
  height: 100%;
}
._code_1tyw5_1 pre.code {
  height: 100%;
  margin-top: 0;
  margin-bottom: 0;
  border-radius: 0;
  border: none;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/example-runner/components/ExampleIFrame.module.scss\">._container_tgh14_1 {
  width: 100%;
  height: 100%;
}
._container_tgh14_1._hidden_tgh14_5 {
  display: none;
}·
._iframe_tgh14_9 {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/example-runner/components/ExampleRunner.module.scss\">._exampleOuter_17dd7_1 {
  --example-border-color: color-mix(in srgb, var(--color-border-secondary), var(--color-border-primary));
}
[data-dark-mode=true] ._exampleOuter_17dd7_1 {
  --example-border-color: color-mix(in srgb, var(--color-bg-primary), var(--color-white) 10%);
}
@media screen and (min-width: 1475px) {
  .largeExamples ._exampleOuter_17dd7_1 > div > div {
    height: 640px !important;
  }
}·
iframe {
  background-color: transparent;
  color-scheme: none;
}·
._tabsContainer_17dd7_18 {
  container-type: inline-size;
}·
._footer_17dd7_22 {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-top: 16px;
}·
._previewCodeToggle_17dd7_29 {
  padding: 4px 12px 6px;
  font-weight: 500;
  border-radius: 8px;
}
._previewCodeToggle_17dd7_29 .icon {
  --icon-size: 24px;
  --icon-color: var(--color-fg-primary);
}·
._externalLinks_17dd7_39 {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  margin-left: 16px;
  margin-right: -10px;
  margin-bottom: 2px;
}·
._importInfoIcon_17dd7_48 {
  margin-right: -4px;
}
._importInfoIcon_17dd7_48:hover svg {
  opacity: 1;
}
._importInfoIcon_17dd7_48 svg {
  --icon-color: var(--color-fg-secondary);
  opacity: 0.5;
  transition: opacity 0.25s ease-in-out;
}·
._content_17dd7_60._hasExampleConsoleLog_17dd7_60 {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}·
.tabs-content._content_17dd7_60 {
  overflow: auto;
  padding: 0;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/example-runner/components/ExampleRunnerContainer.astro?astro&amp;type=style&amp;index=0&amp;lang.css\">.container[data-astro-cid-thekqwrs] {
  position: relative;
}·
.container[data-astro-cid-thekqwrs] .logomark {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -100%) scale(2);
}·
.container[data-astro-cid-thekqwrs].hasExampleConsoleLog .logomark {
  transform: translate(-50%, calc(-100% - 50px)) scale(2);
}·
.isInline[data-astro-cid-thekqwrs] {
  margin-bottom: 16px;
}·
.tabs-content .example-runner-outer[data-astro-cid-thekqwrs] {
  margin-bottom: 0;
}·
@media screen and (width >= 1475px) {
  .largeExamples .example-runner-outer[data-astro-cid-thekqwrs] {
    width: calc(139% - 40px);
  }
}
</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/alert/Alert.module.scss\">._alert_1p97w_1 {
  --icon-size: 1.5rem;
  display: flex;
  gap: 8px;
  align-items: center;
  padding: 8px 8px 8px 12px;
  background-color: var(--color-util-brand-50);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-util-brand-100);
  color: var(--color-util-brand-700);
  margin-top: 20px;
  margin-bottom: 32px;
}
[data-dark-mode=true] ._alert_1p97w_1 {
  background-color: color-mix(in srgb, var(--color-util-brand-50), var(--color-bg-primary) 60%);
}
._alert_1p97w_1 .icon {
  align-self: flex-start;
  position: relative;
  flex-shrink: 0;
  fill: var(--color-util-brand-700);
}
._alert_1p97w_1 p :last-child {
  margin-bottom: 0;
}
._alert_1p97w_1 a {
  font-weight: var(--text-semibold);
  text-decoration: underline;
}
._alert_1p97w_1 kbd {
  margin: 0;
  padding-top: 0.075em;
  padding-bottom: 0.25em;
}·
._alert_1p97w_1._idea_1p97w_36 .icon {
  fill: orange;
}·
._alert_1p97w_1._warning_1p97w_40 {
  color: var(--color-util-warning-700);
  background-color: var(--color-util-warning-50);
  border-color: color-mix(in srgb, var(--color-util-warning-600) 20%, var(--color-bg-primary));
}
[data-dark-mode=true] ._alert_1p97w_1._warning_1p97w_40 {
  border-color: color-mix(in srgb, var(--color-util-warning-600) 30%, var(--color-bg-primary));
}
._alert_1p97w_1._warning_1p97w_40 .icon {
  fill: var(--color-util-warning-700);
}·
._alert_1p97w_1._success_1p97w_52 {
  color: var(--color-success);
  background-color: color-mix(in srgb, var(--color-success) 6%, var(--color-bg-primary));
  border-color: color-mix(in srgb, var(--color-success) 20%, var(--color-bg-primary));
}
[data-dark-mode=true] ._alert_1p97w_1._success_1p97w_52 {
  background-color: color-mix(in srgb, var(--color-success) 10%, var(--color-bg-primary));
  border-color: color-mix(in srgb, var(--color-success) 28%, var(--color-bg-primary));
}
._alert_1p97w_1._success_1p97w_52 .icon {
  fill: var(--color-success);
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/tabs/Tabs.module.scss\">._tabsOuter_vwduy_1 {
  margin-top: 16px;
  margin-bottom: 16px;
  display: flex;
  flex-direction: column;
}
._tabsOuter_vwduy_1 .tabs-content {
  flex: 1;
  min-height: 0;
}·
._snippetTabs_vwduy_12 {
  padding: 0;
}
._snippetTabs_vwduy_12 .code {
  margin: 0;
  border: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
  border-top-left-radius: 0;
}·
._hasHeading_vwduy_24 {
  padding-top: 8px;
}·
._heading_vwduy_28 {
  margin-top: 0;
}·
._externalLinks_vwduy_32 {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-shrink: 0;
  margin-left: auto;
  padding-right: 16px;
}
._externalLinks_vwduy_32 li {
  margin-bottom: 0.125em;
}</style><style data-vite-dev-id=\"/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/components/ApiReferenceFallback.module.scss\">/*
    With JavaScript, the React app replaces the fallback on mount and looks different enough that showing
    the fallback first is a visible flash. So the fallback's content is hidden, leaving the nav
    placeholder's borders and a viewport-high block so the page does not jump on hydration. Without
    JavaScript the query does not match and the content stays visible.
*/
@media (scripting: enabled) {
  ._fallback_hou8s_8 {
    max-height: 100vh;
    overflow: hidden;
  }
  ._fallback_hou8s_8 ._referenceNav_hou8s_12,
  ._fallback_hou8s_8 ._referenceContent_hou8s_13 {
    visibility: hidden;
  }
}·
/*
    Mirrors the two-column geometry the hydrated <ApiReferencePage> produces, so the swap to the
    React app does not shift the page horizontally.
*/
._navPlaceholder_hou8s_22 {
  width: calc(100% + var(--layout-horizontal-margins) * 2);
  margin-left: calc(var(--layout-horizontal-margins) * -1);
}
@media screen and (max-width: 820px) {
  ._navPlaceholder_hou8s_22 {
    /* Reserves the stacked search box's height (nav top padding + text line-box + padding +
        borders) so the content does not drop on hydration. */
    min-height: calc(20px + var(--text-fs-base) * var(--text-lh-body-base) + 12px + 2px);
  }
}
@media screen and (min-width: 820px) {
  ._navPlaceholder_hou8s_22 {
    width: calc(var(--layout-width-4-12) + var(--layout-horizontal-margins));
    box-shadow: -1px 0 0 0 var(--color-border-primary);
    border-right: 1px solid var(--color-border-primary);
  }
}
@media screen and (min-width: 1200px) {
  ._navPlaceholder_hou8s_22 {
    width: calc(var(--layout-width-3-12) + var(--layout-horizontal-margins));
  }
}·
/*
    Links between reference pages, in the column the hydrated navigation tree occupies. Like the tree,
    it is hidden below the medium breakpoint, and above it scrolls independently of the page.
*/
._referenceNav_hou8s_12 {
  --total-header-height: calc(var(--header-nav-height) + var(--tab-bar-height));
  display: none;
}
@media screen and (min-width: 820px) {
  ._referenceNav_hou8s_12 {
    position: sticky;
    top: var(--total-header-height);
    display: block;
    max-height: calc(100vh - var(--total-header-height));
    padding: 16px 16px 16px var(--layout-horizontal-margins);
    overflow-y: auto;
    font-size: var(--text-fs-sm);
  }
}
@media screen and (min-width: 1800px) {
  ._referenceNav_hou8s_12 {
    padding: 16px;
  }
}
._referenceNav_hou8s_12 ul {
  margin: 0;
  padding-left: 16px;
  list-style: none;
}
._referenceNav_hou8s_12 > ul {
  padding-left: 0;
}
._referenceNav_hou8s_12 li {
  margin: 4px 0;
}
._referenceNav_hou8s_12 a[aria-current=page] {
  font-weight: var(--text-bold);
}·
._referenceContent_hou8s_13 {
  width: calc(100% + var(--layout-gap) * 2);
  margin-left: calc(var(--layout-gap) * -1);
}
@media screen and (max-width: 820px) {
  ._referenceContent_hou8s_13 {
    /* Full width with no negative bleed, matching the hydrated `.referenceOuter`. */
    margin-left: 0;
  }
}
@media screen and (min-width: 820px) {
  ._referenceContent_hou8s_13 {
    width: var(--layout-width-8-12);
    margin-left: 0;
  }
}
@media screen and (min-width: 1200px) {
  ._referenceContent_hou8s_13 {
    width: var(--layout-width-9-12);
  }
}
._referenceContent_hou8s_13 header {
  padding-top: 32px;
  padding-bottom: 24px;
  margin-bottom: 16px;
  border-bottom: 1px solid var(--color-border-secondary);
}·
._referenceList_hou8s_113 {
  margin: 0;
}·
._referenceRow_hou8s_117 {
  padding: 16px 0;
  border-top: 1px solid var(--color-border-secondary);
  /* Keeps an anchor's row clear of the sticky header when the page jumps to it. */
  scroll-margin-top: calc(var(--header-nav-height) + var(--tab-bar-height));
}
._referenceRow_hou8s_117 dt {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 8px;
}
._referenceRow_hou8s_117 dd {
  margin: 8px 0 0;
}
._referenceRow_hou8s_117 dd:empty {
  margin: 0;
}·
._referenceNestedList_hou8s_136 {
  margin: 0 0 0 16px;
}·
._propertyName_hou8s_140 {
  font-weight: var(--text-bold);
}·
._propertyType_hou8s_144 {
  color: var(--color-fg-code);
}·
._propertyDefault_hou8s_148 {
  color: var(--color-fg-secondary);
  font-size: var(--text-fs-sm);
}·
._required_hou8s_153 {
  /* stylelint-disable-next-line color-named -- bespoke pure red required-marker, no matching token */
  color: red;
  font-size: var(--text-fs-sm);
}·
._recordAlias_hou8s_159,
._unionDiscriminator_hou8s_160 {
  color: var(--color-fg-code);
}</style></head> <body data-is-homepage=\"false\" style=\"--lightModeCSSUrl: url(&quot;/images/sun.svg&quot;);--darkModeCSSUrl: url(&quot;/images/moon.svg&quot;);\" data-astro-cid-ju4pidww>  <script>
    const htmlEl = document.querySelector('html');
    const localDarkmode = localStorage['documentation:darkmode'];
    const isOSDarkmode = (
        window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
    ).toString();·
    if (localDarkmode === undefined) {
        localStorage.setItem('documentation:darkmode', isOSDarkmode);
    }·
    htmlEl.classList.add('no-transitions');
    htmlEl.dataset.darkMode = localDarkmode !== undefined ? localDarkmode : isOSDarkmode;·
    const getDarkmode = () => htmlEl.dataset.darkMode === 'true';
    htmlEl.dataset.agThemeMode = getDarkmode() ? 'dark-blue' : 'light';
    htmlEl.offsetHeight; // Trigger a reflow, flushing the CSS changes
    htmlEl.classList.remove('no-transitions');·
    // Set up dark mode on change listeners
    const darkModeListeners = [];
    globalThis.addDarkmodeOnChange = (onChange) => {
        darkModeListeners.push(onChange);·
        // Run once on initialisation
        onChange(getDarkmode());
    };·
    // Listen to changes to html[data-dark-mode] attribute and notify listeners
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'data-dark-mode') {
                const newDarkmode = getDarkmode();
                darkModeListeners.forEach((listener) => {
                    listener(newDarkmode);
                });
            }
        });
    });
    observer.observe(htmlEl, { attributes: true });·
    // Show the announcement banner only when it has not been dismissed AND the current date
    // falls within its scheduled window. Dismissal is tracked per-banner: the storage key is
    // suffixed with the banner id (derived from its title + dates) so dismissing one banner
    // does not hide future ones. Evaluated here (at request time) rather than in the Astro
    // build so the window applies to a static deployment without a redeploy. Dates are read
    // from <html> data attributes (YYYY-MM-DD); absent bounds are open-ended.
    const applyAnnouncementVisibility = () => {
        const announcementId = htmlEl.dataset.announcementId || '';
        if (localStorage.getItem('documentation:announcement-banner-dismissed:' + announcementId) === 'true') {
            return;
        }·
        const today = new Date().toISOString().slice(0, 10);
        const showDate = htmlEl.dataset.announcementShowDate;
        const untilDate = htmlEl.dataset.announcementUntilDate;
        const withinWindow = (!showDate || today >= showDate) && (!untilDate || today <= untilDate);·
        if (withinWindow) {
            htmlEl.dataset.showAnnouncement = 'true';
        }
    };·
    applyAnnouncementVisibility();·
    // A client-side navigation restores <html> to its server-rendered attributes and never
    // re-executes a <body> script, so the flag has to be re-derived after every swap.
    document.addEventListener('astro:after-swap', applyAnnouncementVisibility);
</script><script>
    const platform = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '';
    if (/(mac|iphone|ipod|ipad)/i.test(platform)) {
        const applyMacPlatform = () => {
            document.documentElement.dataset.os = 'mac';
        };·
        applyMacPlatform();·
        // A client-side navigation restores <html> to its server-rendered attributes and never
        // re-executes a <body> script, so the flag has to be re-applied after every swap.
        document.addEventListener('astro:after-swap', applyMacPlatform);
    }
</script><div class=\"_banner_1o6uq_1\" data-announcement-banner> <a class=\"_link_1o6uq_21\" href=\"https://www.ag-grid.com/studio/campaigns/launch-week/\"> <span class=\"_inner_1o6uq_43\"> <span class=\"_text_1o6uq_106\"> <span class=\"_title_1o6uq_115\">We just wrapped up AG Studio Launch Week</span>  </span> <span class=\"_cta_1o6uq_32\"> <span class=\"_ctaLabel_1o6uq_32\">See what we shipped</span> <svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg> </span> </span> </a> <button type=\"button\" class=\"_close_1o6uq_60\" data-announcement-dismiss aria-label=\"Dismiss announcement\"> <svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 24 24\" size=\"32\" class=\"_icon_1jqgc_1 icon\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 9.525 8.237 5.763 5.763 8.237 9.525 12l-3.762 3.763 2.474 2.474L12 14.475l3.763 3.762 2.474-2.474L14.475 12l3.762-3.763-2.474-2.474L12 9.525Z\"></path></svg> </button> </div> <script defer src=\"/scripts/announcement-banner.js\"></script> <div class=\"mainContainer\" style=\"--lightModeCSSUrl: url(&quot;/images/sun.svg&quot;);--darkModeCSSUrl: url(&quot;/images/moon.svg&quot;);\" data-astro-cid-ju4pidww> <header class=\"_header_1bxi9_1 site-header\"> <div class=\"_headerInner_1bxi9_26 layout-page-max-width\"> <style>astro-island,astro-slot,astro-static-slot{display:contents}</style><script>(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).load=e;window.dispatchEvent(new Event(\"astro:load\"));})();</script><script>(()=>{var g=Object.defineProperty;var w=(c,s,d)=>s in c?g(c,s,{enumerable:!0,configurable:!0,writable:!0,value:d}):c[s]=d;var l=(c,s,d)=>w(c,typeof s!=\"symbol\"?s+\"\":s,d);var E=new Set([\"__proto__\",\"constructor\",\"prototype\"]);{let c={0:t=>y(t),1:t=>d(t),2:t=>new RegExp(t),3:t=>new Date(t),4:t=>new Map(d(t)),5:t=>new Set(d(t)),6:t=>BigInt(t),7:t=>new URL(t),8:t=>new Uint8Array(t),9:t=>new Uint16Array(t),10:t=>new Uint32Array(t),11:t=>Number.POSITIVE_INFINITY*t},s=t=>{let[p,e]=t;return p in c?c[p](e):void 0},d=t=>t.map(s),y=t=>typeof t!=\"object\"||t===null?t:Object.fromEntries(Object.entries(t).map(([p,e])=>[p,s(e)]));class f extends HTMLElement{constructor(){super(...arguments);l(this,\"Component\");l(this,\"hydrator\");l(this,\"hydrate\",async()=>{var b;if(!this.hydrator||!this.isConnected)return;let e=(b=this.parentElement)==null?void 0:b.closest(\"astro-island[ssr]\");if(e){e.addEventListener(\"astro:hydrate\",this.hydrate,{once:!0});return}let r=this.querySelectorAll(\"astro-slot\"),n={},h=this.querySelectorAll(\"template[data-astro-template]\");for(let o of h){let a=o.closest(this.tagName);a!=null&&a.isSameNode(this)&&(n[o.getAttribute(\"data-astro-template\")||\"default\"]=o.innerHTML,o.remove())}for(let o of r){let a=o.closest(this.tagName);a!=null&&a.isSameNode(this)&&(n[o.getAttribute(\"name\")||\"default\"]=o.innerHTML)}let m;try{m=this.hasAttribute(\"props\")?y(JSON.parse(this.getAttribute(\"props\"))):{}}catch(o){let a=this.getAttribute(\"component-url\")||\"<unknown>\",v=this.getAttribute(\"component-export\");throw v&&(a+=` (export ${v})`),console.error(`[hydrate] Error parsing props for component ${a}`,this.getAttribute(\"props\"),o),o}let i,u=this.hydrator(this);i=performance.now(),await u(this.Component,m,n,{client:this.getAttribute(\"client\")}),i&&this.setAttribute(\"client-render-time\",(performance.now()-i).toString()),this.removeAttribute(\"ssr\"),this.dispatchEvent(new CustomEvent(\"astro:hydrate\"))});l(this,\"unmount\",()=>{this.isConnected||this.dispatchEvent(new CustomEvent(\"astro:unmount\"))})}disconnectedCallback(){document.removeEventListener(\"astro:after-swap\",this.unmount),document.addEventListener(\"astro:after-swap\",this.unmount,{once:!0})}connectedCallback(){if(!this.hasAttribute(\"await-children\")||document.readyState===\"interactive\"||document.readyState===\"complete\")this.childrenConnectedCallback();else{let e=()=>{document.removeEventListener(\"DOMContentLoaded\",e),r.disconnect(),this.childrenConnectedCallback()},r=new MutationObserver(()=>{var n;((n=this.lastChild)==null?void 0:n.nodeType)===Node.COMMENT_NODE&&this.lastChild.nodeValue===\"astro:end\"&&(this.lastChild.remove(),e())});r.observe(this,{childList:!0}),document.addEventListener(\"DOMContentLoaded\",e)}}async childrenConnectedCallback(){let e=this.getAttribute(\"before-hydration-url\");e&&await import(e),this.start()}getRetryImportUrl(e){let r=new URL(e,document.baseURI);return r.searchParams.set(\"astro-retry\",Date.now().toString()),r.toString()}async importWithRetry(e){try{return await import(e)}catch(r){return await new Promise(n=>setTimeout(n,1e3)),import(this.getRetryImportUrl(e))}}handleHydrationError(e){let r=this.getAttribute(\"component-url\"),n=new CustomEvent(\"astro:hydration-error\",{cancelable:!0,bubbles:!0,composed:!0,detail:{error:e,componentUrl:r}});this.dispatchEvent(n)&&console.error(`[astro-island] Error hydrating ${r}`,e)}async start(){let e=JSON.parse(this.getAttribute(\"opts\")),r=this.getAttribute(\"client\");if(Astro[r]===void 0){window.addEventListener(`astro:${r}`,()=>this.start(),{once:!0});return}try{await Astro[r](async()=>{let n=this.getAttribute(\"renderer-url\");try{let[h,{default:m}]=await Promise.all([this.importWithRetry(this.getAttribute(\"component-url\")),n?this.importWithRetry(n):Promise.resolve({default:()=>()=>{}})]),i=this.getAttribute(\"component-export\")||\"default\";if(i.includes(\".\")){this.Component=h;for(let u of i.split(\".\")){if(E.has(u)||!this.Component||typeof this.Component!=\"object\"&&typeof this.Component!=\"function\"||!Object.hasOwn(this.Component,u))throw new Error(`Invalid component export path: ${i}`);this.Component=this.Component[u]}}else{if(E.has(i))throw new Error(`Invalid component export path: ${i}`);this.Component=h[i]}return this.hydrator=m,this.hydrate}catch(h){return this.handleHydrationError(h),()=>{}}},e,this)}catch(n){this.handleHydrationError(n)}}attributeChangedCallback(){this.hydrate()}}l(f,\"observedAttributes\",[\"props\"]),customElements.get(\"astro-island\")||customElements.define(\"astro-island\",f)}})();</script><astro-island uid=\"Z1U1jk2\" prefix=\"r23\" component-url=\"/src/components/SiteLogo.tsx\" component-export=\"SiteLogo\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;SiteLogo&quot;,&quot;value&quot;:true}\" server-render-time=\"16.591387000167742\" await-children><a href=\"/\" aria-label=\"Home\" tabindex=\"0\" class=\"_headerLogo_1bxi9_47\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"logotype\" width=\"198\" height=\"40\" viewBox=\"0 0 198 40\"><style>
    .logotype path {
      fill: #fff;
    }·
    .logotype.dark-type&gt;path {
      fill: #003264;
    }
  </style><path d=\"M25.779 28.657h-12.42l-2.186 5.355h-5.5L17.182 7.06h4.771l11.509 26.952h-5.5l-2.186-5.355h.003Zm-1.711-4.26-4.48-10.963-4.481 10.963h8.961ZM62.092 18.823H49.817v4.263h6.958c-.22 2.136-1.02 3.841-2.403 5.116-1.383 1.274-3.206 1.913-5.463 1.913-1.287 0-2.459-.23-3.516-.692a7.776 7.776 0 0 1-2.713-1.947c-.753-.837-1.336-1.845-1.749-3.023-.412-1.178-.62-2.483-.62-3.916 0-1.432.205-2.737.62-3.916.413-1.178.996-2.185 1.749-3.023a7.763 7.763 0 0 1 2.731-1.947c1.067-.462 2.245-.691 3.535-.691 2.666 0 4.691.642 6.074 1.925l3.28-3.28C55.817 7.67 52.676 6.7 48.872 6.7c-2.112 0-4.019.335-5.718 1.001-1.699.667-3.156 1.603-4.371 2.803-1.216 1.203-2.149 2.654-2.806 4.353-.658 1.699-.983 3.594-.983 5.683 0 2.09.335 3.954 1.001 5.665.667 1.711 1.61 3.169 2.822 4.372 1.215 1.203 2.669 2.136 4.371 2.806 1.7.666 3.594 1.001 5.684 1.001 2.089 0 3.878-.335 5.518-1.001 1.641-.667 3.036-1.603 4.189-2.806 1.154-1.203 2.04-2.661 2.66-4.372.621-1.711.931-3.6.931-5.665a19.88 19.88 0 0 0-.075-1.711l-.003-.006ZM151.81 16.981c1.6-2.372 5.609-2.623 7.212-2.623v4.552c-2.065 0-4.037.086-5.265.982-1.228.9-1.838 2.09-1.838 3.572V33.99h-4.955V14.358h4.772l.074 2.623ZM143.011 14.361v19.67h-4.771l-.109-2.986a7.269 7.269 0 0 1-2.66 2.459c-1.095.595-2.403.892-3.935.892-1.336 0-2.573-.244-3.714-.728a8.714 8.714 0 0 1-2.967-2.059c-.837-.887-1.501-1.947-1.984-3.187-.487-1.237-.729-2.611-.729-4.118 0-1.506.242-2.926.729-4.188.486-1.262 1.147-2.344 1.984-3.243a8.79 8.79 0 0 1 2.967-2.093c1.141-.499 2.381-.747 3.714-.747 1.507 0 2.794.285 3.861.855a7.529 7.529 0 0 1 2.66 2.388v-2.915h4.954Zm-10.38 15.772c1.625 0 2.936-.539 3.934-1.621.996-1.082 1.495-2.521 1.495-4.316s-.499-3.206-1.495-4.297c-.995-1.092-2.306-1.641-3.934-1.641-1.628 0-2.902.546-3.897 1.641-.996 1.094-1.495 2.539-1.495 4.334 0 1.795.496 3.2 1.495 4.282.995 1.079 2.294 1.621 3.897 1.621v-.003ZM93.698 27.876a7.077 7.077 0 0 1-.369.366c-1.382 1.274-3.206 1.913-5.463 1.913-1.286 0-2.458-.229-3.516-.691a7.785 7.785 0 0 1-2.713-1.947c-.753-.838-1.336-1.845-1.748-3.023-.413-1.179-.62-2.484-.62-3.916 0-1.433.204-2.738.62-3.916.412-1.178.995-2.186 1.748-3.023a7.766 7.766 0 0 1 2.732-1.947c1.067-.462 2.245-.692 3.534-.692 2.667 0 4.692.642 6.074 1.926l3.281-3.281c-2.484-1.934-5.625-2.905-9.429-2.905-2.111 0-4.018.335-5.717 1.002-1.699.666-3.156 1.603-4.372 2.803-1.215 1.202-2.148 2.654-2.806 4.353-.657 1.699-.983 3.593-.983 5.683 0 2.089.335 3.953 1.002 5.664.666 1.712 1.609 3.169 2.821 4.372 1.216 1.203 2.67 2.136 4.372 2.806 1.699.667 3.593 1.001 5.683 1.001s3.879-.334 5.519-1.001c1.37-.558 2.57-1.302 3.6-2.232.201-.183.4-.376.589-.571l-3.836-2.735-.003-.009ZM110.802 14.015c-1.603 0-3.966.456-5.191 2.143l-.074-10.142h-4.772v27.923h4.955V22.641a4.463 4.463 0 0 1 4.638-4.267c3.039 0 3.91 2.785 3.91 4.267v11.298h4.955v-12.88s-.081-7.044-8.421-7.044ZM173.763 14.358h-3.764V8.715h-4.951v5.643h-3.764v4.558h3.764v15.087h4.951V18.916h3.764v-4.558ZM190.787 25.262a6.672 6.672 0 0 0-2.403-1.761c-.896-.384-2.053-.769-3.436-1.137a36.605 36.605 0 0 1-2.325-.738 3.609 3.609 0 0 1-1.24-.751 1.377 1.377 0 0 1-.456-1.057c0-.546.229-.974.698-1.308.496-.354 1.237-.534 2.201-.534s1.761.233 2.322.692c.558.456.859 1.057.924 1.832l.022.282h4.539l-.016-.322c-.096-1.975-.846-3.56-2.232-4.71-1.373-1.138-3.2-1.717-5.423-1.717-1.485 0-2.821.254-3.968.753-1.163.505-2.068 1.209-2.698 2.096a5.047 5.047 0 0 0-.955 2.967c0 1.318.357 2.4 1.058 3.215a6.424 6.424 0 0 0 2.443 1.78c.902.372 2.086.763 3.519 1.156 1.445.41 2.511.785 3.169 1.123.57.291.849.722.849 1.321 0 .598-.257 1.023-.784 1.395-.552.387-1.358.586-2.394.586-1.035 0-1.807-.251-2.452-.751-.636-.493-.977-1.085-1.039-1.81l-.025-.282h-4.672l.012.319a5.86 5.86 0 0 0 1.163 3.305c.719.974 1.705 1.752 2.93 2.313 1.218.558 2.614.843 4.148.843 1.535 0 2.843-.254 3.972-.753 1.138-.505 2.034-1.215 2.663-2.115.633-.902.952-1.94.952-3.091-.025-1.293-.387-2.35-1.076-3.141h.01Z\"></path></svg><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"logo-mark\" width=\"64\" height=\"48\" viewBox=\"0 0 64 48\"><style>
    .logomark .aqua { fill: #55b4c8; }
    .logomark .orange { fill: #ff8c00; }
    .logomark .red { fill: #f00; }
    .logomark .grey { fill: #b4bebe; }
  </style><rect class=\"aqua right-1\" x=\"51\" y=\"10\" width=\"7\" height=\"8\"></rect><path class=\"aqua right-1\" d=\"M58,10l-17,0l-8,8l25,0l0,-8Z\"></path><rect class=\"orange right-2\" x=\"36\" y=\"22\" width=\"7\" height=\"8\"></rect><path class=\"orange right-2\" d=\"M43,30l0,-7.995l-14,-0l-8.008,7.995l22.008,0Z\"></path><rect class=\"red right-3\" x=\"24\" y=\"34\" width=\"7\" height=\"8\"></rect><path class=\"red right-3\" d=\"M13,38.01l4,-4.01l14,0l0,8l-18,0l0,-3.99Z\"></path><rect class=\"grey left-1\" x=\"11\" y=\"6\" width=\"7\" height=\"8\"></rect><path class=\"grey left-1\" d=\"M41,10l-4,4l-26,0l0,-8l30,0l0,4Z\"></path><rect class=\"grey left-2\" x=\"16\" y=\"18\" width=\"7\" height=\"8\"></rect><path class=\"grey left-2\" d=\"M16,26l9,0l8,-8l-17,-0l0,8Z\"></path><rect class=\"grey left-3\" x=\"6\" y=\"30\" width=\"7\" height=\"8\"></rect><path class=\"grey left-3\" d=\"M6,37.988l7,0.012l7.992,-8l-14.992,-0.047l-0,8.035Z\"></path></svg></a><!--astro:end--></astro-island> <astro-island uid=\"1BglNN\" prefix=\"r24\" component-url=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/product-dropdown/ProductDropdown.tsx\" component-export=\"ProductDropdown\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{&quot;items&quot;:[1,[[0,{&quot;label&quot;:[0,&quot;&quot;],&quot;items&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;AG Grid&quot;],&quot;description&quot;:[0,&quot;Best JavaScript Grid in the World&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/&quot;]}],[0,{&quot;title&quot;:[0,&quot;AG Charts&quot;],&quot;description&quot;:[0,&quot;Best JavaScript Charts in the World&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/charts/&quot;]}],[0,{&quot;title&quot;:[0,&quot;AG Studio&quot;],&quot;description&quot;:[0,&quot;Best JavaScript Dashboard in the World&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/studio/&quot;]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Gantt&quot;],&quot;description&quot;:[0,&quot;Speed-tuned Gantt chart for project planning&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-gantt/&quot;]}]]]}],[0,{&quot;label&quot;:[0,&quot;&quot;],&quot;items&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Bryntum Scheduler&quot;],&quot;description&quot;:[0,&quot;Resource scheduling timeline component&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-scheduler/&quot;]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Calendar&quot;],&quot;description&quot;:[0,&quot;Flexible JavaScript event calendar&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-calendar/&quot;]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Task Board&quot;],&quot;description&quot;:[0,&quot;Kanban-style task board component&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-task-board/&quot;]}]]]}]]],&quot;children&quot;:[0,null]}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;ProductDropdown&quot;,&quot;value&quot;:true}\" server-render-time=\"17.149762999964878\" await-children><div class=\"_customMenu_p7rjh_1 \"><button class=\"_customTrigger_p7rjh_18 \" tabindex=\"0\">Products<span class=\"_arrow_p7rjh_51\"></span></button><div class=\"_customContent_p7rjh_72\"><div class=\"_column_p7rjh_104\"><a tabindex=\"0\" href=\"https://www.ag-grid.com/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconLight_p7rjh_172\"><g clip-path=\"url(#clip0_200_11127)\"><path d=\"M21 8V6C21 5.20435 20.6839 4.44129 20.1213 3.87868C19.5587 3.31607 18.7956 3 18 3H6C5.20435 3 4.44129 3.31607 3.87868 3.87868C3.31607 4.44129 3 5.20435 3 6V8H21Z\" fill=\"url(#paint0_linear_200_11127)\"></path><path d=\"M3 10V18C3 18.7956 3.31607 19.5587 3.87868 20.1213C4.44129 20.6839 5.20435 21 6 21H11V10H3Z\" fill=\"url(#paint1_linear_200_11127)\"></path><path d=\"M13 10V21H18C18.7956 21 19.5587 20.6839 20.1213 20.1213C20.6839 19.5587 21 18.7956 21 18V10H13Z\" fill=\"url(#paint2_linear_200_11127)\"></path></g><defs><linearGradient id=\"paint0_linear_200_11127\" x1=\"1.5\" y1=\"2\" x2=\"12\" y2=\"8\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient><linearGradient id=\"paint1_linear_200_11127\" x1=\"7\" y1=\"10\" x2=\"7\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient><linearGradient id=\"paint2_linear_200_11127\" x1=\"17\" y1=\"10\" x2=\"17\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\"></stop></linearGradient><clipPath id=\"clip0_200_11127\"><rect width=\"24\" height=\"24\" fill=\"white\"></rect></clipPath></defs></svg> <svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconDark_p7rjh_178\"><path d=\"M21 8V6C21 5.20435 20.6839 4.44129 20.1213 3.87868C19.5587 3.31607 18.7956 3 18 3H6C5.20435 3 4.44129 3.31607 3.87868 3.87868C3.31607 4.44129 3 5.20435 3 6V8H21Z\" fill=\"url(#paint0_linear_205_11152)\"></path><path d=\"M3 10V18C3 18.7956 3.31607 19.5587 3.87868 20.1213C4.44129 20.6839 5.20435 21 6 21H11V10H3Z\" fill=\"url(#paint1_linear_205_11152)\"></path><path d=\"M13 10V21H18C18.7956 21 19.5587 20.6839 20.1213 20.1213C20.6839 19.5587 21 18.7956 21 18V10H13Z\" fill=\"url(#paint2_linear_205_11152)\"></path><defs><linearGradient id=\"paint0_linear_205_11152\" x1=\"12\" y1=\"3\" x2=\"12\" y2=\"8\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"paint1_linear_205_11152\" x1=\"7\" y1=\"10\" x2=\"7\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"paint2_linear_205_11152\" x1=\"17\" y1=\"10\" x2=\"17\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.05\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient></defs></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">AG Grid</div><div class=\"_productDescription_p7rjh_137\">Best JavaScript Grid in the World</div></div></a><a tabindex=\"0\" href=\"https://www.ag-grid.com/charts/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconLight_p7rjh_172\"><path d=\"M14.5 10.33H21.17C21.3901 10.33 21.6012 10.2426 21.7569 10.0869C21.9125 9.93124 22 9.72013 22 9.5C22 7.51088 21.2098 5.60322 19.8033 4.1967C18.3968 2.79018 16.4891 2 14.5 2C14.2799 2 14.0687 2.08745 13.9131 2.2431C13.7574 2.39876 13.67 2.60987 13.67 2.83V9.5C13.67 9.72013 13.7574 9.93124 13.9131 10.0869C14.0687 10.2426 14.2799 10.33 14.5 10.33Z\" fill=\"url(#paint0_linear_200_11123)\"></path><path d=\"M21.08 12.0001H12.93C12.8105 12.0001 12.6922 11.9765 12.5818 11.9308C12.4714 11.8851 12.371 11.8181 12.2865 11.7335C12.202 11.649 12.135 11.5487 12.0893 11.4383C12.0435 11.3279 12.02 11.2096 12.02 11.0901V2.92008C12.0208 2.79037 11.9941 2.66196 11.9417 2.54329C11.8894 2.42461 11.8125 2.31834 11.7162 2.23146C11.6199 2.14459 11.5063 2.07906 11.3829 2.03918C11.2594 1.99931 11.129 1.98598 11 2.00008C9.12276 2.19942 7.34027 2.92605 5.85868 4.09597C4.3771 5.26588 3.25693 6.83128 2.62771 8.61114C1.9985 10.391 1.88595 12.3126 2.30308 14.1538C2.7202 15.9949 3.64996 17.6804 4.98484 19.0152C6.31972 20.3501 8.00519 21.2799 9.84633 21.697C11.6875 22.1141 13.6091 22.0016 15.3889 21.3724C17.1688 20.7432 18.7342 19.623 19.9041 18.1414C21.074 16.6598 21.8007 14.8773 22 13.0001C22.0111 12.8727 21.9956 12.7444 21.9543 12.6234C21.9131 12.5024 21.8471 12.3913 21.7605 12.2972C21.674 12.2031 21.5688 12.1281 21.4516 12.0769C21.3344 12.0258 21.2079 11.9996 21.08 12.0001Z\" fill=\"url(#paint1_linear_200_11123)\"></path><defs><linearGradient id=\"paint0_linear_200_11123\" x1=\"17.835\" y1=\"2\" x2=\"17.835\" y2=\"10.33\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\"></stop></linearGradient><linearGradient id=\"paint1_linear_200_11123\" x1=\"12.0297\" y1=\"1.99463\" x2=\"12.0297\" y2=\"21.9442\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient></defs></svg><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconDark_p7rjh_178\"><g clip-path=\"url(#clip0_205_11140)\"><path d=\"M14.5 10.33H21.17C21.3901 10.33 21.6012 10.2426 21.7569 10.0869C21.9125 9.93124 22 9.72013 22 9.5C22 7.51088 21.2098 5.60322 19.8033 4.1967C18.3968 2.79018 16.4891 2 14.5 2C14.2799 2 14.0687 2.08745 13.9131 2.2431C13.7574 2.39876 13.67 2.60987 13.67 2.83V9.5C13.67 9.72013 13.7574 9.93124 13.9131 10.0869C14.0687 10.2426 14.2799 10.33 14.5 10.33Z\" fill=\"url(#paint0_linear_205_11140)\"></path><path d=\"M21.08 12.0001H12.93C12.8105 12.0001 12.6922 11.9765 12.5818 11.9308C12.4714 11.8851 12.371 11.8181 12.2865 11.7335C12.202 11.649 12.135 11.5487 12.0893 11.4383C12.0435 11.3279 12.02 11.2096 12.02 11.0901V2.92008C12.0208 2.79037 11.9941 2.66196 11.9417 2.54329C11.8894 2.42461 11.8125 2.31834 11.7162 2.23146C11.6199 2.14459 11.5063 2.07906 11.3829 2.03918C11.2594 1.99931 11.129 1.98598 11 2.00008C9.12276 2.19942 7.34027 2.92605 5.85868 4.09597C4.3771 5.26588 3.25693 6.83128 2.62771 8.61114C1.9985 10.391 1.88595 12.3126 2.30308 14.1538C2.7202 15.9949 3.64996 17.6804 4.98484 19.0152C6.31972 20.3501 8.00519 21.2799 9.84633 21.697C11.6875 22.1141 13.6091 22.0016 15.3889 21.3724C17.1688 20.7432 18.7342 19.623 19.9041 18.1414C21.074 16.6598 21.8007 14.8773 22 13.0001C22.0111 12.8727 21.9956 12.7444 21.9543 12.6234C21.9131 12.5024 21.8471 12.3913 21.7605 12.2972C21.674 12.2031 21.5688 12.1281 21.4516 12.0769C21.3344 12.0258 21.2079 11.9996 21.08 12.0001Z\" fill=\"url(#paint1_linear_205_11140)\"></path></g><defs><linearGradient id=\"paint0_linear_205_11140\" x1=\"17.835\" y1=\"2\" x2=\"17.835\" y2=\"10.33\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.05\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"paint1_linear_205_11140\" x1=\"12.0297\" y1=\"1.99463\" x2=\"12.0297\" y2=\"21.9442\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><clipPath id=\"clip0_205_11140\"><rect width=\"24\" height=\"24\" fill=\"white\"></rect></clipPath></defs></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">AG Charts</div><div class=\"_productDescription_p7rjh_137\">Best JavaScript Charts in the World</div></div></a><a tabindex=\"0\" href=\"https://www.ag-grid.com/studio/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconLight_p7rjh_172\"><path d=\"M4 13h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1z\" fill=\"url(#studio_light_g1)\"></path><path d=\"M3 20a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1z\" fill=\"url(#studio_light_g2)\"></path><path d=\"M14 10h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1z\" fill=\"url(#studio_light_g3)\"></path><path d=\"M13 20a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1z\" fill=\"url(#studio_light_g4)\"></path><defs><linearGradient id=\"studio_light_g1\" x1=\"3\" y1=\"3\" x2=\"11\" y2=\"13\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient><linearGradient id=\"studio_light_g2\" x1=\"7\" y1=\"15\" x2=\"7\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient><linearGradient id=\"studio_light_g3\" x1=\"13\" y1=\"3\" x2=\"21\" y2=\"10\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient><linearGradient id=\"studio_light_g4\" x1=\"17\" y1=\"12\" x2=\"17\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop><stop offset=\"1\" stop-color=\"#044B93\"></stop></linearGradient></defs></svg><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"_iconDark_p7rjh_178\"><path d=\"M4 13h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1z\" fill=\"url(#studio_dark_g1)\"></path><path d=\"M3 20a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1z\" fill=\"url(#studio_dark_g2)\"></path><path d=\"M14 10h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1z\" fill=\"url(#studio_dark_g3)\"></path><path d=\"M13 20a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1z\" fill=\"url(#studio_dark_g4)\"></path><defs><linearGradient id=\"studio_dark_g1\" x1=\"3\" y1=\"3\" x2=\"11\" y2=\"13\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"studio_dark_g2\" x1=\"7\" y1=\"15\" x2=\"7\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"studio_dark_g3\" x1=\"13\" y1=\"3\" x2=\"21\" y2=\"10\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"studio_dark_g4\" x1=\"17\" y1=\"12\" x2=\"17\" y2=\"21\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.05\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient></defs></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">AG Studio</div><div class=\"_productDescription_p7rjh_137\">Best JavaScript Dashboard in the World</div></div></a><a tabindex=\"0\" href=\"https://www.ag-grid.com/campaigns/bryntum-gantt/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158 undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" class=\"_iconLight_p7rjh_172\"><defs><linearGradient id=\"bryntum-gantt-grad-feature\" x1=\"6\" y1=\"2\" x2=\"6\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\"></stop></linearGradient><linearGradient id=\"bryntum-gantt-grad\" x1=\"18\" y1=\"5\" x2=\"18\" y2=\"18\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient></defs><path fill=\"url(#bryntum-gantt-grad-feature)\" d=\"M2 5h8V2h2v20h-2v-4H6v-3h4v-2H4v-3h6V8H2z\"></path><path fill=\"url(#bryntum-gantt-grad)\" d=\"M14 5h3v3h-3zm0 5h5v3h-5zm0 5h8v3h-8z\"></path></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" class=\"_iconDark_p7rjh_178\"><defs><linearGradient id=\"bryntum-gantt-dark-grad-feature\" x1=\"6\" y1=\"2\" x2=\"6\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.05\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"bryntum-gantt-dark-grad\" x1=\"18\" y1=\"5\" x2=\"18\" y2=\"18\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.9\"></stop><stop offset=\"1\" stop-color=\"white\" stop-opacity=\"0.5\"></stop></linearGradient></defs><path fill=\"url(#bryntum-gantt-dark-grad-feature)\" d=\"M2 5h8V2h2v20h-2v-4H6v-3h4v-2H4v-3h6V8H2z\"></path><path fill=\"url(#bryntum-gantt-dark-grad)\" d=\"M14 5h3v3h-3zm0 5h5v3h-5zm0 5h8v3h-8z\"></path></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">Bryntum Gantt</div><div class=\"_productDescription_p7rjh_137\">Speed-tuned Gantt chart for project planning</div></div></a></div><div class=\"_column_p7rjh_104\"><a tabindex=\"0\" href=\"https://www.ag-grid.com/campaigns/bryntum-scheduler/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158 undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" class=\"_iconLight_p7rjh_172\"><defs><linearGradient id=\"bryntum-scheduler-grad\" x1=\"12\" y1=\"2\" x2=\"12\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient></defs><path fill=\"url(#bryntum-scheduler-grad)\" d=\"M13 11.6V8q0-.425-.288-.712T12 7t-.712.288T11 8v3.975q0 .2.075.388t.225.337l3.3 3.3q.275.275.7.275T16 16t.275-.7t-.275-.7zM12 22q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22\"></path></svg><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" class=\"_iconDark_p7rjh_178\"><defs><linearGradient id=\"bryntum-scheduler-dark-grad\" x1=\"12\" y1=\"2\" x2=\"12\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.9\"></stop><stop offset=\"1\" stop-color=\"white\" stop-opacity=\"0.5\"></stop></linearGradient></defs><path fill=\"url(#bryntum-scheduler-dark-grad)\" d=\"M13 11.6V8q0-.425-.288-.712T12 7t-.712.288T11 8v3.975q0 .2.075.388t.225.337l3.3 3.3q.275.275.7.275T16 16t.275-.7t-.275-.7zM12 22q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22\"></path></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">Bryntum Scheduler</div><div class=\"_productDescription_p7rjh_137\">Resource scheduling timeline component</div></div></a><a tabindex=\"0\" href=\"https://www.ag-grid.com/campaigns/bryntum-calendar/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158 undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" class=\"_iconLight_p7rjh_172\"><defs><linearGradient id=\"bryntum-calendar-grad-feature\" x1=\"12\" y1=\"2\" x2=\"12\" y2=\"8\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\"></stop></linearGradient><linearGradient id=\"bryntum-calendar-grad\" x1=\"12\" y1=\"10\" x2=\"12\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient></defs><path fill=\"url(#bryntum-calendar-grad)\" d=\"M22 14v-2c0-.839 0-1.585-.013-2.25H2.013C2 10.415 2 11.161 2 12v2c0 3.771 0 5.657 1.172 6.828S6.229 22 10 22h4c3.771 0 5.657 0 6.828-1.172S22 17.771 22 14Z\"></path><path fill=\"url(#bryntum-calendar-grad-feature)\" d=\"M7.75 2.5a.75.75 0 0 0-1.5 0v1.58c-1.44.115-2.384.397-3.078 1.092c-.695.694-.977 1.639-1.093 3.078h19.842c-.116-1.44-.398-2.384-1.093-3.078c-.694-.695-1.639-.977-3.078-1.093V2.5a.75.75 0 0 0-1.5 0v1.513C15.585 4 14.839 4 14 4h-4c-.839 0-1.585 0-2.25.013z\"></path></svg><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" class=\"_iconDark_p7rjh_178\"><defs><linearGradient id=\"bryntum-calendar-dark-grad-feature\" x1=\"12\" y1=\"2\" x2=\"12\" y2=\"8\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.05\"></stop><stop offset=\"1\" stop-color=\"white\"></stop></linearGradient><linearGradient id=\"bryntum-calendar-dark-grad\" x1=\"12\" y1=\"10\" x2=\"12\" y2=\"22\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.9\"></stop><stop offset=\"1\" stop-color=\"white\" stop-opacity=\"0.5\"></stop></linearGradient></defs><path fill=\"url(#bryntum-calendar-dark-grad)\" d=\"M22 14v-2c0-.839 0-1.585-.013-2.25H2.013C2 10.415 2 11.161 2 12v2c0 3.771 0 5.657 1.172 6.828S6.229 22 10 22h4c3.771 0 5.657 0 6.828-1.172S22 17.771 22 14Z\"></path><path fill=\"url(#bryntum-calendar-dark-grad-feature)\" d=\"M7.75 2.5a.75.75 0 0 0-1.5 0v1.58c-1.44.115-2.384.397-3.078 1.092c-.695.694-.977 1.639-1.093 3.078h19.842c-.116-1.44-.398-2.384-1.093-3.078c-.694-.695-1.639-.977-3.078-1.093V2.5a.75.75 0 0 0-1.5 0v1.513C15.585 4 14.839 4 14 4h-4c-.839 0-1.585 0-2.25.013z\"></path></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">Bryntum Calendar</div><div class=\"_productDescription_p7rjh_137\">Flexible JavaScript event calendar</div></div></a><a tabindex=\"0\" href=\"https://www.ag-grid.com/campaigns/bryntum-task-board/\" class=\"_itemsWrapper_p7rjh_144\"><div class=\"_placeholderIcon_p7rjh_158 undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"-2 -2 24 24\" class=\"_iconLight_p7rjh_172\"><defs><linearGradient id=\"bryntum-task-board-grad\" x1=\"10\" y1=\"0\" x2=\"10\" y2=\"20\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#044B93\" stop-opacity=\"0.69\"></stop><stop offset=\"1\" stop-color=\"#044B93\" stop-opacity=\"0.24\"></stop></linearGradient></defs><path fill=\"url(#bryntum-task-board-grad)\" d=\"M6 0h8a6 6 0 0 1 6 6v8a6 6 0 0 1-6 6H6a6 6 0 0 1-6-6V6a6 6 0 0 1 6-6m6 9a1 1 0 0 0 0 2h3a1 1 0 1 0 0-2zm-2 4a1 1 0 0 0 0 2h5a1 1 0 1 0 0-2zm0-8a1 1 0 1 0 0 2h5a1 1 0 0 0 0-2zm-4.172 5.243l-.707-.707a1 1 0 1 0-1.414 1.414l1.414 1.414a1 1 0 0 0 1.415 0l2.828-2.828A1 1 0 0 0 7.95 8.12l-2.122 2.122z\"></path></svg><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"-2 -2 24 24\" class=\"_iconDark_p7rjh_178\"><defs><linearGradient id=\"bryntum-task-board-dark-grad\" x1=\"10\" y1=\"0\" x2=\"10\" y2=\"20\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"white\" stop-opacity=\"0.9\"></stop><stop offset=\"1\" stop-color=\"white\" stop-opacity=\"0.5\"></stop></linearGradient></defs><path fill=\"url(#bryntum-task-board-dark-grad)\" d=\"M6 0h8a6 6 0 0 1 6 6v8a6 6 0 0 1-6 6H6a6 6 0 0 1-6-6V6a6 6 0 0 1 6-6m6 9a1 1 0 0 0 0 2h3a1 1 0 1 0 0-2zm-2 4a1 1 0 0 0 0 2h5a1 1 0 1 0 0-2zm0-8a1 1 0 1 0 0 2h5a1 1 0 0 0 0-2zm-4.172 5.243l-.707-.707a1 1 0 1 0-1.414 1.414l1.414 1.414a1 1 0 0 0 1.415 0l2.828-2.828A1 1 0 0 0 7.95 8.12l-2.122 2.122z\"></path></svg></div><div class=\"_productsWrapper_p7rjh_152\"><div class=\"_productTitle_p7rjh_130\">Bryntum Task Board</div><div class=\"_productDescription_p7rjh_137\">Kanban-style task board component</div></div></a></div></div></div><!--astro:end--></astro-island> <div class=\"_docsNavBtnSearchContainer_1bxi9_65\"> <button id=\"top-bar-docs-button\" class=\"_mobileNavButton_1bxi9_90 button-secondary\" type=\"button\" tabindex=\"0\" aria-controls=\"side-nav\" aria-expanded=\"false\" aria-label=\"Toggle docs page navigation\"> <span>Docs</span> <svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M14 25H28V27H14z\"></path><path d=\"M7.17 26 4.59 28.58 6 30 10 26 6 22 4.58 23.41 7.17 26z\"></path><path d=\"M14 15H28V17H14z\"></path><path d=\"M7.17 16 4.59 18.58 6 20 10 16 6 12 4.58 13.41 7.17 16z\"></path><path d=\"M14 5H28V7H14z\"></path><path d=\"M7.17 6 4.59 8.58 6 10 10 6 6 2 4.58 3.41 7.17 6z\"></path></svg> </button> <astro-island uid=\"Zd7N4u\" prefix=\"r26\" component-url=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/search/Search.tsx\" component-export=\"default\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;Search&quot;,&quot;value&quot;:true}\" server-render-time=\"17.419644000008702\" await-children><div role=\"button\" tabindex=\"0\" class=\"_headerSearchBox_14kty_1\" aria-label=\"Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M29,27.5859l-7.5521-7.5521a11.0177,11.0177,0,1,0-1.4141,1.4141L27.5859,29ZM4,13a9,9,0,1,1,9,9A9.01,9.01,0,0,1,4,13Z\"></path></svg><span class=\"_placeholder_14kty_36\">Search</span><span class=\"_kbdShortcut_14kty_39\"><span class=\"_kbdShortcutMac_14kty_68\">⌘ K</span><span class=\"_kbdShortcutDefault_14kty_71\">Ctrl K</span></span></div><!--astro:end--></astro-island> </div> <astro-island uid=\"wB08a\" prefix=\"r27\" component-url=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/site-header/HeaderNav.tsx\" component-export=\"HeaderNav\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{&quot;currentPath&quot;:[0,&quot;/javascript/map-lines/&quot;],&quot;items&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;AG Grid&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;AG Studio&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/studio/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Gantt&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-gantt/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Scheduler&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-scheduler/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Calendar&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-calendar/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Task Board&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-task-board/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Examples&quot;],&quot;path&quot;:[0,&quot;/examples&quot;]}],[0,{&quot;title&quot;:[0,&quot;Gallery&quot;],&quot;path&quot;:[0,&quot;/gallery&quot;]}],[0,{&quot;title&quot;:[0,&quot;Theme Builder&quot;],&quot;path&quot;:[0,&quot;/theme-builder&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;./quick-start&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/options&quot;]}],[0,{&quot;title&quot;:[0,&quot;Community&quot;],&quot;path&quot;:[0,&quot;/community&quot;]}],[0,{&quot;title&quot;:[0,&quot;Pricing&quot;],&quot;path&quot;:[0,&quot;/license-pricing&quot;]}],[0,{&quot;title&quot;:[0,&quot;Contact Us&quot;],&quot;path&quot;:[0,&quot;/contact&quot;]}],[0,{&quot;title&quot;:[0,&quot;GitHub&quot;],&quot;url&quot;:[0,&quot;https://github.com/ag-grid/ag-charts&quot;],&quot;icon&quot;:[0,&quot;github&quot;]}]]],&quot;allPaths&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;AG Grid&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;AG Studio&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/studio/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Gantt&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-gantt/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Scheduler&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-scheduler/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Calendar&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-calendar/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Task Board&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-task-board/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Examples&quot;],&quot;path&quot;:[0,&quot;/examples&quot;]}],[0,{&quot;title&quot;:[0,&quot;Gallery&quot;],&quot;path&quot;:[0,&quot;/gallery&quot;]}],[0,{&quot;title&quot;:[0,&quot;Theme Builder&quot;],&quot;path&quot;:[0,&quot;/theme-builder&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;/quick-start&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/options&quot;]}],[0,{&quot;title&quot;:[0,&quot;Community&quot;],&quot;path&quot;:[0,&quot;/community&quot;]}],[0,{&quot;title&quot;:[0,&quot;Pricing&quot;],&quot;path&quot;:[0,&quot;/license-pricing&quot;]}],[0,{&quot;title&quot;:[0,&quot;Contact Us&quot;],&quot;path&quot;:[0,&quot;/contact&quot;]}],[0,{&quot;title&quot;:[0,&quot;GitHub&quot;],&quot;url&quot;:[0,&quot;https://github.com/ag-grid/ag-charts&quot;],&quot;icon&quot;:[0,&quot;github&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/options&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/themes-api&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/theme-parameters-api&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;/react&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;/angular&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;/vue&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;/javascript&quot;]}]]],&quot;apiPaths&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/options&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/themes-api&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/theme-parameters-api&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-create-update&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/events&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-download&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/api-state&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/context&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/react/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/angular/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/vue/ts-generics&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/javascript/ts-generics&quot;]}]]]}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;HeaderNav&quot;,&quot;value&quot;:true}\" server-render-time=\"18.064947000006214\" await-children><div class=\"_mainNav_1bxi9_205 _mainNavLargeContainer_1bxi9_214\"><nav class=\"_mainNavLarge_1bxi9_205\"><ul class=\"_navItemList_1bxi9_244 list-style-none\"><li class=\"_navItem_1bxi9_244\"><a id=\"examples-nav\" class=\"_navLink_1bxi9_262\" href=\"/examples/\" tabindex=\"0\" aria-label=\"AG Charts Examples\"><span>Examples</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"gallery-nav\" class=\"_navLink_1bxi9_262\" href=\"/gallery/\" tabindex=\"0\" aria-label=\"AG Charts Gallery\"><span>Gallery</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"theme-builder-nav\" class=\"_navLink_1bxi9_262\" href=\"/theme-builder/\" tabindex=\"0\" aria-label=\"AG Charts Theme Builder\"><span>Theme Builder</span></a></li><li class=\"_navItem_1bxi9_244 _navItemActive_1bxi9_262\"><a id=\"docs-nav\" class=\"_navLink_1bxi9_262\" href=\"/react/quick-start/\" tabindex=\"0\" aria-label=\"AG Charts Docs\"><span>Docs</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"api-nav\" class=\"_navLink_1bxi9_262\" href=\"/options/\" tabindex=\"0\" aria-label=\"AG Charts API\"><span>API</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"community-nav\" class=\"_navLink_1bxi9_262\" href=\"/community/\" tabindex=\"0\" aria-label=\"AG Charts Community\"><span>Community</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"pricing-nav\" class=\"_navLink_1bxi9_262\" href=\"/license-pricing/\" tabindex=\"0\" aria-label=\"AG Charts Pricing\"><span>Pricing</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"contact-us-nav\" class=\"_navLink_1bxi9_262\" href=\"/contact/\" tabindex=\"0\" aria-label=\"AG Charts Contact Us\"><span>Contact Us</span></a></li><li class=\"_navItem_1bxi9_244 _buttonItem_1bxi9_339 _githubItem_1bxi9_335\"><a id=\"github-nav\" class=\"_navLink_1bxi9_262\" href=\"https://github.com/ag-grid/ag-charts\" tabindex=\"0\" aria-label=\"AG Charts GitHub\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon\" xmlns=\"http://www.w3.org/2000/svg\"><path fill-rule=\"evenodd\" d=\"M16,2a14,14,0,0,0-4.43,27.28c.7.13,1-.3,1-.67s0-1.21,0-2.38c-3.89.84-4.71-1.88-4.71-1.88A3.71,3.71,0,0,0,6.24,22.3c-1.27-.86.1-.85.1-.85A2.94,2.94,0,0,1,8.48,22.9a3,3,0,0,0,4.08,1.16,2.93,2.93,0,0,1,.88-1.87c-3.1-.36-6.37-1.56-6.37-6.92a5.4,5.4,0,0,1,1.44-3.76,5,5,0,0,1,.14-3.7s1.17-.38,3.85,1.43a13.3,13.3,0,0,1,7,0c2.67-1.81,3.84-1.43,3.84-1.43a5,5,0,0,1,.14,3.7,5.4,5.4,0,0,1,1.44,3.76c0,5.38-3.27,6.56-6.39,6.91a3.33,3.33,0,0,1,.95,2.59c0,1.87,0,3.38,0,3.84s.25.81,1,.67A14,14,0,0,0,16,2Z\"></path></svg><span>GitHub</span></a></li><li class=\"_navItem_1bxi9_244 _buttonItem_1bxi9_339\"><button class=\"_navLink_1bxi9_262 button-style-none\" aria-label=\"Dark mode selector\" tabindex=\"0\"><div class=\"_icon_1bxi9_102 _pseudoIcon_1bxi9_343\"></div><span>Dark Mode</span></button></li></ul></nav></div><button class=\"_mobileMenuButton_1bxi9_17\" type=\"button\" aria-controls=\"_mainNavSmall_1bxi9_1\" aria-expanded=\"false\" aria-label=\"Toggle navigation\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"_menuIcon_1bxi9_167\" width=\"36\" height=\"36\" viewBox=\"0 0 36 36\"><style>
    .menu-icon rect { fill: #fff; }
  </style><g class=\"top\"><rect x=\"2\" y=\"7\" width=\"32\" height=\"2\"></rect></g><g class=\"middle\"><rect x=\"2\" y=\"17\" width=\"32\" height=\"2\"></rect></g><g class=\"bottom\"><rect x=\"2\" y=\"27\" width=\"32\" height=\"2\"></rect></g></svg></button><div id=\"_mainNavSmall_1bxi9_1\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><nav class=\"_mainNav_1bxi9_205\"><ul class=\"_navItemList_1bxi9_244 list-style-none\"><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-ag-grid-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/\" tabindex=\"0\" aria-label=\"AG Charts AG Grid\"><span>AG Grid</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-ag-studio-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/studio/\" tabindex=\"0\" aria-label=\"AG Charts AG Studio\"><span>AG Studio</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-bryntum-gantt-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/campaigns/bryntum-gantt/\" tabindex=\"0\" aria-label=\"AG Charts Bryntum Gantt\"><span>Bryntum Gantt</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-bryntum-scheduler-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/campaigns/bryntum-scheduler/\" tabindex=\"0\" aria-label=\"AG Charts Bryntum Scheduler\"><span>Bryntum Scheduler</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-bryntum-calendar-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/campaigns/bryntum-calendar/\" tabindex=\"0\" aria-label=\"AG Charts Bryntum Calendar\"><span>Bryntum Calendar</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-bryntum-task-board-nav\" class=\"_navLink_1bxi9_262\" href=\"https://www.ag-grid.com/campaigns/bryntum-task-board/\" tabindex=\"0\" aria-label=\"AG Charts Bryntum Task Board\"><span>Bryntum Task Board</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-examples-nav\" class=\"_navLink_1bxi9_262\" href=\"/examples/\" tabindex=\"0\" aria-label=\"AG Charts Examples\"><span>Examples</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-gallery-nav\" class=\"_navLink_1bxi9_262\" href=\"/gallery/\" tabindex=\"0\" aria-label=\"AG Charts Gallery\"><span>Gallery</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-theme-builder-nav\" class=\"_navLink_1bxi9_262\" href=\"/theme-builder/\" tabindex=\"0\" aria-label=\"AG Charts Theme Builder\"><span>Theme Builder</span></a></li><li class=\"_navItem_1bxi9_244 _navItemActive_1bxi9_262\"><a id=\"mobile-docs-nav\" class=\"_navLink_1bxi9_262\" href=\"/react/quick-start/\" tabindex=\"0\" aria-label=\"AG Charts Docs\"><span>Docs</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-api-nav\" class=\"_navLink_1bxi9_262\" href=\"/options/\" tabindex=\"0\" aria-label=\"AG Charts API\"><span>API</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-community-nav\" class=\"_navLink_1bxi9_262\" href=\"/community/\" tabindex=\"0\" aria-label=\"AG Charts Community\"><span>Community</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-pricing-nav\" class=\"_navLink_1bxi9_262\" href=\"/license-pricing/\" tabindex=\"0\" aria-label=\"AG Charts Pricing\"><span>Pricing</span></a></li><li class=\"_navItem_1bxi9_244\"><a id=\"mobile-contact-us-nav\" class=\"_navLink_1bxi9_262\" href=\"/contact/\" tabindex=\"0\" aria-label=\"AG Charts Contact Us\"><span>Contact Us</span></a></li><li class=\"_navItem_1bxi9_244 _buttonItem_1bxi9_339 _githubItem_1bxi9_335\"><a id=\"mobile-github-nav\" class=\"_navLink_1bxi9_262\" href=\"https://github.com/ag-grid/ag-charts\" tabindex=\"0\" aria-label=\"AG Charts GitHub\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon\" xmlns=\"http://www.w3.org/2000/svg\"><path fill-rule=\"evenodd\" d=\"M16,2a14,14,0,0,0-4.43,27.28c.7.13,1-.3,1-.67s0-1.21,0-2.38c-3.89.84-4.71-1.88-4.71-1.88A3.71,3.71,0,0,0,6.24,22.3c-1.27-.86.1-.85.1-.85A2.94,2.94,0,0,1,8.48,22.9a3,3,0,0,0,4.08,1.16,2.93,2.93,0,0,1,.88-1.87c-3.1-.36-6.37-1.56-6.37-6.92a5.4,5.4,0,0,1,1.44-3.76,5,5,0,0,1,.14-3.7s1.17-.38,3.85,1.43a13.3,13.3,0,0,1,7,0c2.67-1.81,3.84-1.43,3.84-1.43a5,5,0,0,1,.14,3.7,5.4,5.4,0,0,1,1.44,3.76c0,5.38-3.27,6.56-6.39,6.91a3.33,3.33,0,0,1,.95,2.59c0,1.87,0,3.38,0,3.84s.25.81,1,.67A14,14,0,0,0,16,2Z\"></path></svg><span>GitHub</span></a></li><li class=\"_navItem_1bxi9_244 _buttonItem_1bxi9_339\"><button class=\"_navLink_1bxi9_262 button-style-none\" aria-label=\"Dark mode selector\" tabindex=\"0\"><div class=\"_icon_1bxi9_102 _pseudoIcon_1bxi9_343\"></div><span>Dark Mode</span></button></li></ul></nav></div></div><!--astro:end--></astro-island> </div> </header>  <main style=\"--lightModeCSSUrl: url(&quot;/images/sun.svg&quot;);--darkModeCSSUrl: url(&quot;/images/moon.svg&quot;);\" data-astro-cid-ju4pidww>  <div class=\"_contentViewport_1wzld_1 layout-grid\"> <astro-island uid=\"1nvQNb\" prefix=\"r19\" component-url=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/docs-navigation/DocsNav.tsx\" component-export=\"DocsNav\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{&quot;menuData&quot;:[0,{&quot;sections&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Getting started&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Quick Start&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;quick-start&quot;]}],[0,{&quot;title&quot;:[0,&quot;Key Features&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;key-features&quot;]}],[0,{&quot;title&quot;:[0,&quot;Community vs. Enterprise&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;community-vs-enterprise&quot;]}],[0,{&quot;title&quot;:[0,&quot;Setup&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Installation&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;installation&quot;]}],[0,{&quot;title&quot;:[0,&quot;Module Registry&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;module-registry&quot;]}],[0,{&quot;title&quot;:[0,&quot;Enterprise Licence Key&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;license-install&quot;]}],[0,{&quot;title&quot;:[0,&quot;Development Validation&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;dev-validation&quot;]}],[0,{&quot;title&quot;:[0,&quot;Migration&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;migration&quot;]}],[0,{&quot;title&quot;:[0,&quot;Server-Side Rendering&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;server-side-rendering&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Tutorials&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Creating a Basic Chart&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;create-a-basic-chart&quot;]}]]]}],[0,{&quot;title&quot;:[0,&quot;Security &amp; Compatibility&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Security&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;security&quot;]}],[0,{&quot;title&quot;:[0,&quot;Supported Browsers&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;supported-browsers&quot;]}],[0,{&quot;title&quot;:[0,&quot;Supported Frameworks&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;supported-frameworks&quot;]}]]]}]]]}],[0,{&quot;title&quot;:[0,&quot;AI Features&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Skills&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;skills&quot;]}]]]}],[0,{&quot;title&quot;:[0,&quot;Core features&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Data&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Data Configuration&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;data-configuration&quot;]}],[0,{&quot;title&quot;:[0,&quot;Large Datasets&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;large-dataset-interactivity&quot;]}],[0,{&quot;title&quot;:[0,&quot;High-Frequency Update&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;high-frequency-data&quot;]}],[0,{&quot;title&quot;:[0,&quot;Transactions&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;transactions&quot;]}],[0,{&quot;title&quot;:[0,&quot;Asynchronous Data&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;async-data&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Axes&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Axis Configuration&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-configuration&quot;]}],[0,{&quot;title&quot;:[0,&quot;Axis Types&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-types&quot;]}],[0,{&quot;title&quot;:[0,&quot;Axis Intervals&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-intervals&quot;]}],[0,{&quot;title&quot;:[0,&quot;Axis Domain&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-domain&quot;]}],[0,{&quot;title&quot;:[0,&quot;Axis Position&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-position&quot;]}],[0,{&quot;title&quot;:[0,&quot;Axis Labels&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-labels&quot;]}],[0,{&quot;title&quot;:[0,&quot;Time Axes&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-time&quot;]}],[0,{&quot;title&quot;:[0,&quot;Grid Lines &amp; Band Shading&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-grid-lines&quot;]}],[0,{&quot;title&quot;:[0,&quot;Secondary Axes&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-secondary&quot;]}]]]}],[0,{&quot;title&quot;:[0,&quot;Data Elements&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Cross Lines&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-cross-lines&quot;]}],[0,{&quot;title&quot;:[0,&quot;Legend&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;legend&quot;]}],[0,{&quot;title&quot;:[0,&quot;Formatters&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;formatters&quot;]}],[0,{&quot;title&quot;:[0,&quot;Stylers&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;stylers&quot;]}],[0,{&quot;title&quot;:[0,&quot;Series Bars&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;bars&quot;]}],[0,{&quot;title&quot;:[0,&quot;Series Fills&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;fills&quot;]}],[0,{&quot;title&quot;:[0,&quot;Series Labels&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;series-labels&quot;]}],[0,{&quot;title&quot;:[0,&quot;Series Markers&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;markers&quot;]}],[0,{&quot;title&quot;:[0,&quot;Style Segments&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;style-segments&quot;]}],[0,{&quot;title&quot;:[0,&quot;Annotations&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;annotations&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Background Regions&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;background-regions&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Colour Scale&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;colour-scale&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Error Bars&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;error-bars&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Interactivity&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Accessibility&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;accessibility&quot;]}],[0,{&quot;title&quot;:[0,&quot;Localisation&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;localisation&quot;]}],[0,{&quot;title&quot;:[0,&quot;Series Highlighting&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;series-highlighting&quot;]}],[0,{&quot;title&quot;:[0,&quot;Tooltips&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;tooltips&quot;]}],[0,{&quot;title&quot;:[0,&quot;Touch&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;touch&quot;]}],[0,{&quot;title&quot;:[0,&quot;Animation&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;animation&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Context Menu&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;context-menu&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Crosshairs &amp; Band Highlight&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;axes-crosshairs&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Data Selection&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;selection&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Flash On Update&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;flash-on-update&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Navigator&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;navigator&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Range Controls&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;range-controls&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Scrollbar&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;scrollbar&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Synchronization&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;sync&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Zoom&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;zoom&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Layout &amp; Styling&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Background&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;background&quot;]}],[0,{&quot;title&quot;:[0,&quot;Colours&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;colours&quot;]}],[0,{&quot;title&quot;:[0,&quot;Fills &amp; Borders&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;fills-borders&quot;]}],[0,{&quot;title&quot;:[0,&quot;Layout&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;layout&quot;]}],[0,{&quot;title&quot;:[0,&quot;Overlays&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;overlays&quot;]}],[0,{&quot;title&quot;:[0,&quot;RTL Text &amp; Layout&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;rtl&quot;]}],[0,{&quot;title&quot;:[0,&quot;Text&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;text&quot;]}],[0,{&quot;title&quot;:[0,&quot;Themes&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;themes&quot;]}],[0,{&quot;title&quot;:[0,&quot;Background Image&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;background-image&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}]]]}],[0,{&quot;title&quot;:[0,&quot;Specialised Charts&quot;],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Financial Charts&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;isEnterprise&quot;:[0,true],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Overview&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;financial-charts&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Configuration&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;financial-charts-configuration&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Toolbar&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;financial-charts-toolbar&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Range Buttons&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;range-buttons&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Volume Profile&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;financial-charts-volume-profile&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Maps&quot;],&quot;type&quot;:[0,&quot;group&quot;],&quot;isEnterprise&quot;:[0,true],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Overview&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;maps&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Geographic Areas&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;map-shapes&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Routes and Connections&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;map-lines&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Markers &amp; Points of Interest&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;map-markers&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Map Topology&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;map-topology&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Org Chart&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;org-chart&quot;],&quot;icon&quot;:[0,&quot;chartsOrg&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Quadrant Chart&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;quadrant-chart&quot;],&quot;icon&quot;:[0,&quot;chartsQuadrant&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Series&quot;],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Bar&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;bar-series&quot;],&quot;icon&quot;:[0,&quot;chartsColumn&quot;]}],[0,{&quot;title&quot;:[0,&quot;Line&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;line-series&quot;],&quot;icon&quot;:[0,&quot;chartsLine&quot;]}],[0,{&quot;title&quot;:[0,&quot;Area&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;area-series&quot;],&quot;icon&quot;:[0,&quot;chartsArea&quot;]}],[0,{&quot;title&quot;:[0,&quot;Scatter&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;scatter-series&quot;],&quot;icon&quot;:[0,&quot;chartsScatter&quot;]}],[0,{&quot;title&quot;:[0,&quot;Bubble&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;bubble-series&quot;],&quot;icon&quot;:[0,&quot;chartsBubble&quot;]}],[0,{&quot;title&quot;:[0,&quot;Pie&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;pie-series&quot;],&quot;icon&quot;:[0,&quot;chartsPie&quot;]}],[0,{&quot;title&quot;:[0,&quot;Donut&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;donut-series&quot;],&quot;icon&quot;:[0,&quot;chartsDonut&quot;]}],[0,{&quot;title&quot;:[0,&quot;Combination&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;combination-series&quot;],&quot;icon&quot;:[0,&quot;chartsCombination&quot;]}],[0,{&quot;title&quot;:[0,&quot;Box Plot&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;box-plot-series&quot;],&quot;icon&quot;:[0,&quot;chartsBoxPlot&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Candlestick&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;candlestick-series&quot;],&quot;icon&quot;:[0,&quot;chartsCandlestick&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;HLC&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;hlc-series&quot;],&quot;icon&quot;:[0,&quot;chartsHLC&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;OHLC&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;ohlc-series&quot;],&quot;icon&quot;:[0,&quot;chartsOHLC&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Heatmap&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;heatmap-series&quot;],&quot;icon&quot;:[0,&quot;chartsHeatmap&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Histogram&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;histogram-series&quot;],&quot;icon&quot;:[0,&quot;chartsHistogram&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Nightingale&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;nightingale-series&quot;],&quot;icon&quot;:[0,&quot;chartsNightingale&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Radar Area&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;radar-area-series&quot;],&quot;icon&quot;:[0,&quot;chartsRadarArea&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Radar Line&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;radar-line-series&quot;],&quot;icon&quot;:[0,&quot;chartsRadar&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Radial Bar&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;radial-bar-series&quot;],&quot;icon&quot;:[0,&quot;chartsRadialBar&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Radial Column&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;radial-column-series&quot;],&quot;icon&quot;:[0,&quot;chartsRadialColumn&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Range Area&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;range-area-series&quot;],&quot;icon&quot;:[0,&quot;chartsRangeArea&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Range Bar&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;range-bar-series&quot;],&quot;icon&quot;:[0,&quot;chartsRangeBar&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Waterfall&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;waterfall-series&quot;],&quot;icon&quot;:[0,&quot;chartsWaterfall&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Sunburst&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;sunburst-series&quot;],&quot;icon&quot;:[0,&quot;chartsSunburst&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Treemap&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;treemap-series&quot;],&quot;icon&quot;:[0,&quot;chartsTreemap&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Sankey&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;sankey-series&quot;],&quot;icon&quot;:[0,&quot;chartsSankey&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Chord&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;chord-series&quot;],&quot;icon&quot;:[0,&quot;chartsChord&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Funnel&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;funnel-series&quot;],&quot;icon&quot;:[0,&quot;chartsFunnel&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Cone Funnel&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;cone-funnel-series&quot;],&quot;icon&quot;:[0,&quot;chartsConeFunnel&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Pyramid&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;pyramid-series&quot;],&quot;icon&quot;:[0,&quot;chartsPyramid&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}],[0,{&quot;title&quot;:[0,&quot;Gauges&quot;],&quot;isPricingFeature&quot;:[0,true],&quot;children&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;Radial Gauge&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;radial-gauge&quot;],&quot;icon&quot;:[0,&quot;chartsRadialGauge&quot;],&quot;isEnterprise&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Linear Gauge&quot;],&quot;type&quot;:[0,&quot;item&quot;],&quot;path&quot;:[0,&quot;linear-gauge&quot;],&quot;icon&quot;:[0,&quot;chartsLinearGauge&quot;],&quot;isEnterprise&quot;:[0,true]}]]]}]]]}],&quot;framework&quot;:[0,&quot;javascript&quot;],&quot;pageName&quot;:[0,&quot;map-lines&quot;]}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;DocsNav&quot;,&quot;value&quot;:true}\" server-render-time=\"13.002871999982744\" await-children><div id=\"docs-mobile-nav-collapser\" aria-hidden=\"false\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div id=\"docs-nav-scroll\" class=\"_docsNavOuter_m2pa9_23\"><div class=\"_docsNavInner_m2pa9_68\"><div class=\"_whatsNewLink_m2pa9_83\"><a tabindex=\"0\" href=\"/whats-new/\">What&#x27;s New</a></div><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">Getting started</h5><a href=\"/javascript/quick-start/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Quick <span class=\"_titleTail_m2pa9_214\">Start</span></span></a><a href=\"/javascript/key-features/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Key <span class=\"_titleTail_m2pa9_214\">Features</span></span></a><a href=\"/javascript/community-vs-enterprise/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Community vs. <span class=\"_titleTail_m2pa9_214\">Enterprise</span></span></a><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Setup</span></button><div id=\"Setup\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/installation/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Installation</span></span></a><a href=\"/javascript/module-registry/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Module <span class=\"_titleTail_m2pa9_214\">Registry</span></span></a><a href=\"/javascript/license-install/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Enterprise Licence <span class=\"_titleTail_m2pa9_214\">Key</span></span></a><a href=\"/javascript/dev-validation/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Development <span class=\"_titleTail_m2pa9_214\">Validation</span></span></a><a href=\"/javascript/migration/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Migration</span></span></a><a href=\"/javascript/server-side-rendering/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Server-Side <span class=\"_titleTail_m2pa9_214\">Rendering<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Tutorials</span></button><div id=\"Tutorials\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/create-a-basic-chart/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Creating a Basic <span class=\"_titleTail_m2pa9_214\">Chart</span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Security &amp; Compatibility</span></button><div id=\"Security &amp; Compatibility\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/security/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Security</span></span></a><a href=\"/javascript/supported-browsers/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Supported <span class=\"_titleTail_m2pa9_214\">Browsers</span></span></a><a href=\"/javascript/supported-frameworks/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Supported <span class=\"_titleTail_m2pa9_214\">Frameworks</span></span></a></div></div></div></div></div><hr class=\"_divider_m2pa9_133\"/><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">AI Features</h5><a href=\"/javascript/skills/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Skills</span></span></a></div><hr class=\"_divider_m2pa9_133\"/><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">Core features</h5><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Data</span></button><div id=\"Data\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/data-configuration/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Data <span class=\"_titleTail_m2pa9_214\">Configuration</span></span></a><a href=\"/javascript/large-dataset-interactivity/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Large <span class=\"_titleTail_m2pa9_214\">Datasets</span></span></a><a href=\"/javascript/high-frequency-data/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>High-Frequency <span class=\"_titleTail_m2pa9_214\">Update</span></span></a><a href=\"/javascript/transactions/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Transactions</span></span></a><a href=\"/javascript/async-data/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Asynchronous <span class=\"_titleTail_m2pa9_214\">Data<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Axes</span></button><div id=\"Axes\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/axes-configuration/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Configuration</span></span></a><a href=\"/javascript/axes-types/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Types</span></span></a><a href=\"/javascript/axes-intervals/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Intervals</span></span></a><a href=\"/javascript/axes-domain/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Domain</span></span></a><a href=\"/javascript/axes-position/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Position</span></span></a><a href=\"/javascript/axes-labels/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Axis <span class=\"_titleTail_m2pa9_214\">Labels</span></span></a><a href=\"/javascript/axes-time/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Time <span class=\"_titleTail_m2pa9_214\">Axes</span></span></a><a href=\"/javascript/axes-grid-lines/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Grid Lines &amp; Band <span class=\"_titleTail_m2pa9_214\">Shading</span></span></a><a href=\"/javascript/axes-secondary/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Secondary <span class=\"_titleTail_m2pa9_214\">Axes</span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Data Elements</span></button><div id=\"Data Elements\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/axes-cross-lines/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Cross <span class=\"_titleTail_m2pa9_214\">Lines</span></span></a><a href=\"/javascript/legend/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Legend</span></span></a><a href=\"/javascript/formatters/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Formatters</span></span></a><a href=\"/javascript/stylers/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Stylers</span></span></a><a href=\"/javascript/bars/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Series <span class=\"_titleTail_m2pa9_214\">Bars</span></span></a><a href=\"/javascript/fills/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Series <span class=\"_titleTail_m2pa9_214\">Fills</span></span></a><a href=\"/javascript/series-labels/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Series <span class=\"_titleTail_m2pa9_214\">Labels</span></span></a><a href=\"/javascript/markers/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Series <span class=\"_titleTail_m2pa9_214\">Markers</span></span></a><a href=\"/javascript/style-segments/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Style <span class=\"_titleTail_m2pa9_214\">Segments</span></span></a><a href=\"/javascript/annotations/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Annotations<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/background-regions/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Background <span class=\"_titleTail_m2pa9_214\">Regions<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/colour-scale/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Colour <span class=\"_titleTail_m2pa9_214\">Scale<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/error-bars/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Error <span class=\"_titleTail_m2pa9_214\">Bars<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Interactivity</span></button><div id=\"Interactivity\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/accessibility/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Accessibility</span></span></a><a href=\"/javascript/localisation/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Localisation</span></span></a><a href=\"/javascript/series-highlighting/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Series <span class=\"_titleTail_m2pa9_214\">Highlighting</span></span></a><a href=\"/javascript/tooltips/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Tooltips</span></span></a><a href=\"/javascript/touch/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Touch</span></span></a><a href=\"/javascript/animation/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Animation<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/context-menu/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Context <span class=\"_titleTail_m2pa9_214\">Menu<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/axes-crosshairs/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Crosshairs &amp; Band <span class=\"_titleTail_m2pa9_214\">Highlight<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/selection/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Data <span class=\"_titleTail_m2pa9_214\">Selection<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/flash-on-update/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Flash On <span class=\"_titleTail_m2pa9_214\">Update<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/navigator/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Navigator<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/range-controls/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Range <span class=\"_titleTail_m2pa9_214\">Controls<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/scrollbar/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Scrollbar<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/sync/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Synchronization<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/zoom/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Zoom<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Layout &amp; Styling</span></button><div id=\"Layout &amp; Styling\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/background/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Background</span></span></a><a href=\"/javascript/colours/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Colours</span></span></a><a href=\"/javascript/fills-borders/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Fills &amp; <span class=\"_titleTail_m2pa9_214\">Borders</span></span></a><a href=\"/javascript/layout/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Layout</span></span></a><a href=\"/javascript/overlays/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Overlays</span></span></a><a href=\"/javascript/rtl/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>RTL Text &amp; <span class=\"_titleTail_m2pa9_214\">Layout</span></span></a><a href=\"/javascript/text/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Text</span></span></a><a href=\"/javascript/themes/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Themes</span></span></a><a href=\"/javascript/background-image/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Background <span class=\"_titleTail_m2pa9_214\">Image<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div></div><hr class=\"_divider_m2pa9_133\"/><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">Specialised Charts</h5><div class=\"_group_m2pa9_116\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Financial Charts</span></button><div id=\"Financial Charts\" aria-hidden=\"true\" class=\"rah-static rah-static--height-zero \" style=\"height:0;overflow:hidden\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/financial-charts/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Overview<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/financial-charts-configuration/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Configuration<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/financial-charts-toolbar/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Toolbar<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/range-buttons/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Range <span class=\"_titleTail_m2pa9_214\">Buttons<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/financial-charts-volume-profile/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Volume <span class=\"_titleTail_m2pa9_214\">Profile<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><div class=\"_group_m2pa9_116 _isOpen_m2pa9_169\"><button tabindex=\"0\" class=\"button-style-none _groupTitle_m2pa9_116\"><svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _groupChevron_m2pa9_155\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9.763 8.237 17.525 16l-7.762 7.763 2.474 2.474L22.475 16 12.237 5.763 9.763 8.237Z\"></path></svg><span>Maps</span></button><div id=\"Maps\" aria-hidden=\"false\" class=\"rah-static rah-static--height-auto \" style=\"height:auto;overflow:visible\"><div><div class=\"_groupChildren_m2pa9_174\"><a href=\"/javascript/maps/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span><span class=\"_titleTail_m2pa9_214\">Overview<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/map-shapes/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Geographic <span class=\"_titleTail_m2pa9_214\">Areas<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/map-lines/\" tabindex=\"0\" class=\"_item_m2pa9_117 _isActive_m2pa9_190\"><span>Routes and <span class=\"_titleTail_m2pa9_214\">Connections<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/map-markers/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Markers &amp; Points of <span class=\"_titleTail_m2pa9_214\">Interest<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/map-topology/\" tabindex=\"0\" class=\"_item_m2pa9_117\"><span>Map <span class=\"_titleTail_m2pa9_214\">Topology<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div><a href=\"/javascript/org-chart/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M27,22V17a2.0023,2.0023,0,0,0-2-2H17V10h3a2.0023,2.0023,0,0,0,2-2V4a2.0023,2.0023,0,0,0-2-2H12a2.0023,2.0023,0,0,0-2,2V8a2.0023,2.0023,0,0,0,2,2h3v5H7a2.0023,2.0023,0,0,0-2,2v5H2v8h8V22H7V17h8v5H12v8h8V22H17V17h8v5H22v8h8V22ZM12,4h8V8H12ZM8,28H4V24H8Zm10,0H14V24h4Zm10,0H24V24h4Z\"></path></svg><span>Org <span class=\"_titleTail_m2pa9_214\">Chart<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/quadrant-chart/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M30 15 17 15 17 2 15 2 15 15 2 15 2 17 15 17 15 30 17 30 17 17 30 17 30 15z\"></path><path d=\"M5,30a3,3,0,1,1,3-3A3.0033,3.0033,0,0,1,5,30Zm0-4a1,1,0,1,0,1,1A1.001,1.001,0,0,0,5,26Z\"></path><path d=\"M8,8a3,3,0,1,1,3-3A3.0033,3.0033,0,0,1,8,8ZM8,4A1,1,0,1,0,9,5,1.001,1.001,0,0,0,8,4Z\"></path><path d=\"M22,13a3,3,0,1,1,3-3A3.0033,3.0033,0,0,1,22,13Zm0-4a1,1,0,1,0,1,1A1.001,1.001,0,0,0,22,9Z\"></path><circle cx=\"11\" cy=\"11\" r=\"2\"></circle><circle cx=\"11\" cy=\"21\" r=\"2\"></circle><circle cx=\"21\" cy=\"21\" r=\"2\"></circle><circle cx=\"22\" cy=\"28\" r=\"2\"></circle><circle cx=\"28\" cy=\"24\" r=\"2\"></circle><circle cx=\"4\" cy=\"11\" r=\"2\"></circle><circle cx=\"28\" cy=\"4\" r=\"2\"></circle></svg><span>Quadrant <span class=\"_titleTail_m2pa9_214\">Chart<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div><hr class=\"_divider_m2pa9_133\"/><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">Series</h5><a href=\"/javascript/bar-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M27,28V6H19V28H15V14H7V28H4V2H2V28a2,2,0,0,0,2,2H30V28ZM13,28H9V16h4Zm12,0H21V8h4Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Bar</span></span></a><a href=\"/javascript/line-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M4.67,28l6.39-12,7.3,6.49a2,2,0,0,0,1.7.47,2,2,0,0,0,1.42-1.07L27,10.9,25.18,10,19.69,21l-7.3-6.49A2,2,0,0,0,10.71,14a2,2,0,0,0-1.42,1L4,25V2H2V28a2,2,0,0,0,2,2H30V28Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Line</span></span></a><a href=\"/javascript/area-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M20.4761,8.0151,13.4473,4.2109a2.0076,2.0076,0,0,0-2.1158.2051L4,10.001V2H2V28a2,2,0,0,0,2,2H30V5.7354ZM28,20.209l-7.62,1.8022-7.0288-2.8838a1.99,1.99,0,0,0-2.022.37L4,25.8359v-4.455l8.375-9.4,7.0186,5.62a2.0155,2.0155,0,0,0,2.0459.2119L28,14.6025ZM12.5239,5.9849l7.03,3.8042a2.012,2.012,0,0,0,1.3408.16L28,8.2646v4.1138L20.6187,16.02,13.6,10.4a1.99,1.99,0,0,0-2.6885.2642L4,18.3838v-5.87ZM4.5513,28,12.62,20.9888l7.0288,2.8838a1.9977,1.9977,0,0,0,1.147.0771L28,22.2612V28Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Area</span></span></a><a href=\"/javascript/scatter-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path><circle cx=\"10\" cy=\"22\" r=\"2\"></circle><circle cx=\"14\" cy=\"15\" r=\"2\"></circle><circle cx=\"22\" cy=\"15\" r=\"2\"></circle><circle cx=\"26\" cy=\"6\" r=\"2\"></circle><circle cx=\"14\" cy=\"8\" r=\"2\"></circle></svg><span><span class=\"_titleTail_m2pa9_214\">Scatter</span></span></a><a href=\"/javascript/bubble-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path><path d=\"M10,16a2,2,0,1,1-2,2,2,2,0,0,1,2-2m0-2a4,4,0,1,0,4,4,4,4,0,0,0-4-4Z\"></path><path d=\"M21,6a4,4,0,1,1-4,4,4,4,0,0,1,4-4m0-2a6,6,0,1,0,6,6,6,6,0,0,0-6-6Z\"></path><path d=\"M24.5,21A1.5,1.5,0,1,1,23,22.5,1.5,1.5,0,0,1,24.5,21m0-2A3.5,3.5,0,1,0,28,22.5,3.5,3.5,0,0,0,24.5,19Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Bubble</span></span></a><a href=\"/javascript/pie-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16,4A12,12,0,1,0,28,16,12,12,0,0,0,16,4ZM26,15H17V6.05A10,10,0,0,1,26,15ZM15.42,26A10,10,0,0,1,15,6.05v9a2,2,0,0,0,2,2h9A10,10,0,0,1,15.42,26Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Pie</span></span></a><a href=\"/javascript/donut-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16,2A14,14,0,1,0,30,16,14.0158,14.0158,0,0,0,16,2ZM27.9493,15.001H21.91a5.9825,5.9825,0,0,0-9.3806-3.8853l-4.27-4.27a11.9783,11.9783,0,0,1,19.69,8.1548ZM16,20a4,4,0,1,1,4-4A4.0045,4.0045,0,0,1,16,20ZM4,16A11.937,11.937,0,0,1,6.8455,8.26l4.27,4.2695A5.9836,5.9836,0,0,0,15,21.9106v6.04A12.0105,12.0105,0,0,1,4,16ZM17,27.95v-6.04A6.0069,6.0069,0,0,0,21.91,17h6.04A12.0082,12.0082,0,0,1,17,27.95Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Donut</span></span></a><a href=\"/javascript/combination-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M27,28V16H19V28H15V12H7V28H4V2H2V28a2,2,0,0,0,2,2H30V28ZM13,28H9V14h4Zm12,0H21V18h4Z\"></path><path d=\"M22.7856,14a1.9877,1.9877,0,0,1-1.1787-.3865L11.2041,5.987,8.2419,10,6.6374,8.8065l2.9812-4a1.9978,1.9978,0,0,1,2.749-.446l10.4214,7.64,3.6045-4.8613L28,8.3306l-3.6045,4.8611A2.0014,2.0014,0,0,1,22.7856,14Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Combination</span></span></a><a href=\"/javascript/box-plot-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M22,6V4H12V6h4V8H12V20h4v2H12v2H22V22H18V20h4V8H18V6ZM14,18V15h6v3Zm6-5H14V10h6Z\"></path><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path></svg><span>Box <span class=\"_titleTail_m2pa9_214\">Plot<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/candlestick-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M26,10H24V6H22v4H20V22h2v4h2V22h2ZM24,20H22V12h2Z\"></path><path d=\"M14,8H12V4H10V8H8V18h2v4h2V18h2Zm-2,8H10V10h2Z\"></path><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Candlestick<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/hlc-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path><path d=\"M5,16.3L13.85,6.52L18.29,9.98L25.31,2L27.98,2L18.55,12.71L14.08,9.24L5,19.28Z\"></path><path d=\"M5,23.01L14.38,12.64L18.87,16.13L30,3.49L30,6.51L19.13,18.87L14.62,15.36L5,25.99Z\"></path><path d=\"M7.46,27L14.92,18.76L19.45,22.29L30,10.3L30,13.33L19.71,25.02L15.15,21.48L10.16,27Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">HLC<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/ohlc-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M15 8 12 8 12 6 10 6 10 20 7 20 7 22 10 22 10 24 12 24 12 10 15 10 15 8z\"></path><path d=\"M27 10 24 10 24 6 22 6 22 18 19 18 19 20 22 20 22 24 24 24 24 12 27 12 27 10z\"></path><path d=\"M30,30H4a2,2,0,0,1-2-2V2H4V28H30Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">OHLC<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/heatmap-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M27,3H5A2.0023,2.0023,0,0,0,3,5V27a2.0023,2.0023,0,0,0,2,2H27a2.0023,2.0023,0,0,0,2-2V5A2.0023,2.0023,0,0,0,27,3ZM19,9H13V5h6Zm0,2v4H13V11Zm-8,0v4H5V11Zm0,6v4H5V17Zm2,0h6v4H13Zm8-2V11h6l0,4ZM5,23h6v4H5Zm16,4V23h6v4Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Heatmap<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/histogram-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M26,26V4H18v6H12v6H6V26H2v2H30V26ZM8,26V18h4v8Zm6,0V12h4V26Zm6,0V6h4V26Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Histogram<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/nightingale-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M30,17A15.017,15.017,0,0,0,15,2H14V8.0591A9.0122,9.0122,0,0,0,6.0591,16H4v1A11.0109,11.0109,0,0,0,14,27.9492V30h1A13.0084,13.0084,0,0,0,27.9492,18H30ZM16,4.0381A13.0217,13.0217,0,0,1,27.9619,16H16ZM14,10.08V16H8.08A7.0037,7.0037,0,0,1,14,10.08ZM6.0552,18H14v7.939A9.0134,9.0134,0,0,1,6.0552,18ZM16,27.9551V18h9.9551A11.0191,11.0191,0,0,1,16,27.9551Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Nightingale<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/radar-area-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M28.9625 12.4094L16.5875 3.40937C16.4171 3.28451 16.2113 3.21719 16 3.21719C15.7887 3.21719 15.5829 3.28451 15.4125 3.40937L3.03751 12.4094C2.86661 12.5336 2.73948 12.7088 2.67435 12.9098C2.60922 13.1108 2.60945 13.3273 2.67501 13.5281L7.40313 28.0906C7.46839 28.2912 7.59543 28.4661 7.76606 28.5901C7.93669 28.7141 8.14218 28.7811 8.35313 28.7813H23.65C24.0844 28.7813 24.4656 28.5031 24.6 28.0906L29.3281 13.5281C29.4594 13.1156 29.3125 12.6656 28.9625 12.4094ZM26.2063 13.0313L23.1281 14.0313L16.8781 9.50938V6.24688L26.2063 13.0313ZM14.5625 17.725L11.7781 21.5469L10.0531 16.2594L14.5625 17.725ZM10.9281 14.7L15.125 11.6656V16.0656L10.9281 14.7ZM16 18.725L18.9344 22.7531H13.0656L16 18.725ZM16.8781 11.6656L21.0719 14.7L16.8781 16.0625V11.6656ZM17.4375 17.725L21.9469 16.2594L20.2219 21.5469L17.4375 17.725ZM15.125 6.24688V9.50938L8.87188 14.0313L5.79376 13.0313L15.125 6.24688ZM5.29063 14.7125L7.99376 15.5906L10.5063 23.2906L8.82501 25.6L5.29063 14.7125ZM10.2219 26.6563L11.7938 24.5H20.2094L21.7813 26.6563H10.2219ZM23.175 25.6L21.4938 23.2906L24.0063 15.5906L26.7094 14.7125L23.175 25.6Z\"></path><path d=\"M8.5 15L15.5 11L16 17L20 23H11.5L8.5 15Z\"></path></svg><span>Radar <span class=\"_titleTail_m2pa9_214\">Area<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/radar-line-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16,2,2,13,8,30H24l6-17Zm2.5818,19.2651-5.9861,1.3306-1.4226-7.8252,4.91-4.209,5.4416,4.0816Zm.1977,2.0054L21.3264,28H10.6736l1.7912-3.3267ZM9.59,13.4937,5.74,12.605,15,5.3291V8.8569ZM17,8.75V5.3291l9.26,7.2759-3.15.727ZM4.6143,14.3979l4.6535,1.0738,1.4844,8.164-1.738,3.2281ZM22.9858,26.8638l-2.5766-4.7852,3.0063-6.7646,3.97-.9161Z\"></path></svg><span>Radar <span class=\"_titleTail_m2pa9_214\">Line<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/radial-bar-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16,30A14.0158,14.0158,0,0,1,2,16H4A12,12,0,1,0,16,4V2a14,14,0,0,1,0,28Z\"></path><path d=\"M16,26A10.0115,10.0115,0,0,1,6,16H8a8,8,0,1,0,8-8V6a10,10,0,0,1,0,20Z\"></path><path d=\"M16,22a6.0069,6.0069,0,0,1-6-6h2a4,4,0,1,0,4-4V10a6,6,0,0,1,0,12Z\"></path></svg><span>Radial <span class=\"_titleTail_m2pa9_214\">Bar<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/radial-column-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M8.76427 12.7481L3.41401 6.86283L7.29827 2.97857L12.7481 8.9734V1.5H18.2519V9.01015L23.9597 2.52603L27.8465 6.41282L22.2697 12.7481H30V18.2519H22.1329L27.9337 24.0526L24.0526 27.9337L18.2519 22.1329V30H12.7481V22.1329L6.5 28.3811L2.60835 24.4894L8.93004 18.2614L12.8763 21.7707H17.9798L21.7707 17.9798V13.0202L18.0219 9.27139L18.0589 9.22933H12.9808L12.9995 9.24995L9.22932 13.0202V18.2519H1V12.7481H8.76427ZM9.18421 10.2368L10.2368 9.18421L7.22932 5.87594L6.17669 6.92857L9.18421 10.2368ZM3 16.2519H7.22932V14.7481H3V16.2519ZM24.0526 5.44737L20.7632 9.18421L21.8158 10.2368L25.1053 6.5L24.0526 5.44737ZM16.2519 7.22933V3.5H14.7481V7.22933H16.2519ZM23.7707 16.2519V14.7481H28V16.2519H23.7707ZM20.7632 21.8158L24.0526 25.1053L25.1053 24.0526L21.8158 20.7632L20.7632 21.8158ZM16.2519 28H14.7481V23.7707H16.2519V28ZM6.5 25.5526L5.4474 24.5L9 21L10.0865 21.9662L6.5 25.5526Z\"></path></svg><span>Radial <span class=\"_titleTail_m2pa9_214\">Column<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/range-area-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M12.4326,20.0171l8.0376,4.68a1.958,1.958,0,0,0,1.0508.3012,2.2412,2.2412,0,0,0,.4888-.0556l7.2532-1.9769A1,1,0,0,0,30,22.0007V7.996A1,1,0,0,0,28.74,7.0305L21.5034,8.9829l-8.0371-4.68a1.9917,1.9917,0,0,0-1.8652-.1352L4,7.4727V2H2V28a2,2,0,0,0,2,2H30V28H4V23.6577ZM28,21.2344l-6.4966,1.75-8.0371-4.68a1.9931,1.9931,0,0,0-1.8652-.1353L4,21.4746V16.6572l8.4326-3.6416L20.47,17.6968a1.962,1.962,0,0,0,1.0508.3008,2.2112,2.2112,0,0,0,.4888-.0557L28,16.31ZM12.4326,6.0156l8.0376,4.68a2.0091,2.0091,0,0,0,1.54.2451L28,9.3081v4.9258l-6.4966,1.7505-8.0371-4.6812a1.9917,1.9917,0,0,0-1.8652-.1352L4,14.4736V9.6562Z\"></path></svg><span>Range <span class=\"_titleTail_m2pa9_214\">Area<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/range-bar-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M28,24H14V16H28ZM16,22H26V18H16Z\"></path><path d=\"M26,12H8V4H26ZM10,10H24V6H10Z\"></path><path d=\"M30,30H4a2.0023,2.0023,0,0,1-2-2V2H4V28H30Z\"></path></svg><span>Range <span class=\"_titleTail_m2pa9_214\">Bar<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/waterfall-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M28,28V18H26V28H22V4H20V28H10V14H8V28H4V2H2V28a2.0023,2.0023,0,0,0,2,2H30V28Z\"></path><path d=\"M14 4H16V18H14z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Waterfall<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/sunburst-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M16,2a1,1,0,0,0-1,1v7.09a5.9618,5.9618,0,0,0-2.46,1.043L7.8384,6.4311a1.4554,1.4554,0,0,0-2.087.0244A14.05,14.05,0,0,0,9.8047,28.5972a10.8482,10.8482,0,0,0,1.8989.7676,14.0982,14.0982,0,0,0,13.8443-3.1319,1.4336,1.4336,0,0,0,.0278-2.0639L20.877,19.47A5.963,5.963,0,0,0,21.91,17H29a1,1,0,0,0,1-1A14.0158,14.0158,0,0,0,16,2Zm0,10a4,4,0,1,1-4,4A4.0045,4.0045,0,0,1,16,12ZM6.83,8.251l4.2959,4.2959a5.91,5.91,0,0,0-.0113,6.9243L6.8381,23.7481A12.0168,12.0168,0,0,1,6.83,8.251Zm1.4228,16.91,4.2759-4.2759A5.9589,5.9589,0,0,0,15,21.91v6.042A11.8783,11.8783,0,0,1,8.2529,25.1612ZM17,27.9561V21.9092a5.9631,5.9631,0,0,0,2.4609-1.0273l4.2818,4.2817A11.8905,11.8905,0,0,1,17,27.9561ZM21.91,15A6.0063,6.0063,0,0,0,17,10.09V4.041A12.0208,12.0208,0,0,1,27.9585,15Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Sunburst<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/treemap-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M28,2H4A2.0023,2.0023,0,0,0,2,4V28a2.0023,2.0023,0,0,0,2,2H28a2.0023,2.0023,0,0,0,2-2V4A2.0023,2.0023,0,0,0,28,2Zm0,12H23V4h5ZM16,4h5V14H16ZM14,4V20H4V4ZM4,22H14v6H4Zm12,6V16H28V28Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Treemap<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/sankey-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M29 2H2V15.5H7.89304C8.94066 15.5014 9.97371 15.7454 10.9113 16.2129L15.2721 18.3929L10.9116 20.5728C9.97398 21.0403 8.94079 21.2844 7.89304 21.2857H2V29H8.96513C10.3122 28.9985 11.6407 28.6849 12.8463 28.0839L21.1604 23.9272C22.0979 23.4597 23.131 23.2157 24.1786 23.2143H29V13.5714H24.1786C23.131 13.57 22.0979 13.326 21.1604 12.8585L14.8714 9.71429H29V2ZM7.78571 3.92857H23.2143V7.78571H7.78571V3.92857ZM3.92857 3.92857H5.85714V13.5714H3.92857V3.92857ZM3.92857 23.2143H5.85714V27.0714H3.92857V23.2143ZM20.2974 22.2018L11.9837 26.3583C11.0461 26.8259 10.0129 27.07 8.96513 27.0714H7.78571V23.2143H7.89304C9.24014 23.2128 10.5686 22.8992 11.7742 22.2982L17.4286 19.4711L19.2258 20.3695C20.4314 20.9704 21.7599 21.284 23.107 21.2855H23.2143V21.342C22.1992 21.4557 21.2119 21.7467 20.2974 22.2018ZM27.0714 21.2857H25.1429V15.5H27.0714V21.2857ZM11.9837 10.4272L20.2974 14.5833C21.2119 15.0385 22.1991 15.3296 23.2143 15.4435V19.3571H23.107C22.0593 19.3557 21.0263 19.1117 20.0887 18.6442L11.7746 14.4882C10.5689 13.8869 9.24033 13.5731 7.89304 13.5714H7.78571V9.71429H8.96513C10.0129 9.71565 11.0461 9.95966 11.9837 10.4272ZM27.0714 7.78571H25.1429V3.92857H27.0714V7.78571Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Sankey<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/chord-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M6.91635 8.84487L7.03439 8.6924L7.04006 8.69732L7.30207 8.39561C7.88472 7.72468 8.53957 7.12166 9.25476 6.59965C9.69383 7.59167 10.2589 9.19746 10.4019 11.1511C10.4235 11.447 10.4355 11.7513 10.4357 12.0629C9.45092 11.4128 8.45842 10.9644 7.57187 10.6556C6.99531 10.4548 6.45933 10.3116 5.99341 10.2098C6.27084 9.73523 6.57977 9.27961 6.91635 8.84487ZM5.57975 10.1263C5.88352 9.59363 6.22533 9.08402 6.60006 8.6L5.60006 7.73333L5.60002 7.73338L6.59996 8.6C6.22524 9.08401 5.88343 9.59362 5.57967 10.1263C5.5797 10.1263 5.57972 10.1263 5.57975 10.1263ZM3.67313 9.96667C4.11722 9.07914 4.65981 8.24584 5.29128 7.47905L5.55205 7.16241L5.5581 7.16765L5.69635 7.00635C8.16897 4.12163 11.8782 2.26667 16.0001 2.26667C19.0214 2.26667 21.7727 3.22898 24.0416 4.94783L24.2312 5.09146L24.2739 5.03884L24.5841 5.28831C27.7408 7.8274 29.7334 11.6734 29.7334 16C29.7334 19.2301 28.5652 22.2525 26.6422 24.5876L26.4672 24.8L26.5038 24.8317L26.2303 25.1347C23.6931 27.9462 20.0542 29.7333 16.0001 29.7333C12.5638 29.7333 9.40399 28.4273 7.00151 26.2994L6.80634 26.1266L6.75431 26.1866L6.45055 25.8828C3.91653 23.3488 2.26672 19.8498 2.26672 16C2.26672 13.9179 2.72446 11.9481 3.56665 10.1845V9.96667H3.67313ZM4.68083 12.0782C4.24288 13.3047 3.99996 14.62 3.99996 16C3.99996 18.1547 4.58493 20.1979 5.59282 21.9677L5.59289 21.9677C4.58506 20.1978 4.00006 18.1547 4.00006 16C4.00006 14.62 4.24297 13.3047 4.68092 12.0782C4.68089 12.0782 4.68086 12.0782 4.68083 12.0782ZM5.08363 12.1406C4.64385 13.347 4.40006 14.6416 4.40006 16C4.40006 18.0498 4.94817 19.9969 5.89595 21.6909C8.52095 19.2421 9.74403 16.7175 10.2047 14.4188C9.11823 13.5301 7.93885 12.9671 6.90576 12.612C6.1877 12.3651 5.55151 12.2225 5.08363 12.1406ZM10.3349 13.6307C8.51854 12.2588 6.53736 11.7006 5.34882 11.4773C5.34882 11.4773 5.34883 11.4773 5.34883 11.4773C6.53734 11.7005 8.51853 12.2588 10.3349 13.6307C10.3349 13.6307 10.3349 13.6307 10.3349 13.6307ZM10.8044 14.9538C10.7141 15.3388 10.6032 15.7288 10.4693 16.1227C10.6032 15.7288 10.7141 15.3388 10.8044 14.9538C10.8044 14.9538 10.8044 14.9538 10.8044 14.9538ZM10.9657 14.1478C10.9657 14.1478 10.9657 14.1478 10.9657 14.1478C10.9657 14.1477 10.9657 14.1477 10.9657 14.1477L10.9657 14.1477C10.9657 14.1477 10.9657 14.1478 10.9657 14.1478ZM11.8691 16.1939C11.1419 18.5542 9.68494 21.0388 7.06888 23.416C7.3253 23.7305 7.5971 24.0314 7.8829 24.3172L8.00393 24.4382L8.01552 24.4237L8.33012 24.699C8.43829 24.7936 8.54822 24.8863 8.65985 24.977C10.007 22.4718 11.6227 20.648 13.3453 19.3354C13.0119 18.1501 12.5177 17.1025 11.8691 16.1939ZM13.9476 18.8998C13.5551 17.6068 12.9726 16.46 12.2 15.4667L12.1842 15.4464L12.1812 15.4425C12.1549 15.4089 12.1285 15.3755 12.1019 15.3424C12.1019 15.3423 12.1019 15.3423 12.1019 15.3423C12.1349 15.3833 12.1676 15.4248 12.2001 15.4667C12.9726 16.46 13.5552 17.6068 13.9477 18.8998C13.9477 18.8998 13.9477 18.8998 13.9476 18.8998ZM13.7689 21.606C12.533 22.7325 11.3734 24.2093 10.3711 26.1342C11.3419 26.6734 12.3948 27.0786 13.5002 27.3248C13.8577 25.2049 13.9429 23.2978 13.7689 21.606ZM14.1879 27.4562C14.588 25.0899 14.6617 22.9519 14.4091 21.0585C14.4091 21.0585 14.4091 21.0585 14.4091 21.0585C14.6618 22.9519 14.5881 25.0899 14.188 27.4562C14.1879 27.4562 14.1879 27.4562 14.1879 27.4562ZM4.94286 11.4085C4.94286 11.4085 4.94286 11.4085 4.94286 11.4085L4.94295 11.4085C4.94295 11.4085 4.94295 11.4085 4.94295 11.4085C4.94292 11.4085 4.94289 11.4085 4.94286 11.4085ZM15.5565 27.5914C15.7038 27.5971 15.8517 27.6 16.0001 27.6C17.5897 27.6 19.1094 27.279 20.4943 26.6955C19.1804 23.9394 18.5839 21.2957 18.7217 18.7973C17.6922 19.1058 16.6454 19.5562 15.6216 20.1969C16.0188 22.3894 15.99 24.8692 15.5565 27.5914ZM15.1085 18.1809C16.4067 17.4582 17.733 16.9782 19.0241 16.6745C19.0931 16.3782 19.1734 16.0842 19.2648 15.7926C19.6814 14.4351 20.2962 13.2701 20.982 12.2867C19.1117 11.391 17.63 10.1567 16.4937 8.92456C15.4121 7.75174 14.6385 6.57676 14.1305 5.68648C13.8999 5.28231 13.7168 4.92156 13.5884 4.65431C12.6865 4.84781 11.8247 5.14781 11.0151 5.54083C11.1249 5.77665 11.2436 6.04879 11.3644 6.35374C11.8136 7.48819 12.2955 9.0892 12.4396 10.9716C12.5051 11.8266 12.5004 12.7364 12.393 13.6834C12.6774 13.9771 12.9536 14.294 13.2184 14.6359C14.0391 15.679 14.6671 16.8649 15.1085 18.1809ZM11.1265 12.555C11.2313 9.76492 10.4086 7.44734 9.84225 6.19786L9.84224 6.19787C10.4086 7.44735 11.2313 9.76492 11.1265 12.555C11.1265 12.555 11.1265 12.555 11.1265 12.555ZM6.77008 23.6826C7.03177 24.0026 7.30886 24.3089 7.59996 24.6L6.73334 25.5999L6.73339 25.6L7.60006 24.6C7.30895 24.3089 7.03184 24.0026 6.77014 23.6825L6.77008 23.6826ZM20.5432 16.3918C20.5615 16.3277 20.5805 16.2638 20.6 16.2L20.5988 16.2041L20.5975 16.2084C20.5789 16.2694 20.5608 16.3305 20.5432 16.3918L20.5432 16.3918ZM21.302 16.3034C21.7125 15.0467 22.3414 13.9686 23.0311 13.0708C24.2441 13.4251 25.5867 13.6333 27.0666 13.6333H27.0852H27.0852C27.1725 13.6333 27.2595 13.6333 27.3471 13.6325C27.5126 14.3995 27.6001 15.1918 27.6001 16C27.6001 16.2522 27.5917 16.5032 27.5751 16.7527C27.2214 16.6682 26.7932 16.5778 26.3039 16.496C24.9997 16.2782 23.2479 16.1196 21.302 16.3034ZM9.03744 25.7661L9.03746 25.7661L9.03748 25.766L9.03747 25.766L9.03744 25.7661ZM8.47011 25.3379C8.43732 25.3116 8.40467 25.2851 8.37216 25.2585C8.2689 25.174 8.16708 25.0878 8.06672 25L8.06668 25C8.19863 25.1155 8.33314 25.2282 8.47008 25.3379L8.47011 25.3379ZM20.1591 18.4507C19.945 20.8247 20.4785 23.3596 21.782 26.0555L21.782 26.0555C20.4785 23.3596 19.945 20.8247 20.1591 18.4507L20.1591 18.4507ZM20.8739 18.3369C20.632 20.5937 21.1115 23.0373 22.3806 25.6852C23.2131 25.1344 23.971 24.478 24.6349 23.7338L24.8075 23.5402L24.7749 23.512L25.0261 23.2106C26.0731 21.9542 26.8486 20.4226 27.2618 18.7591C26.0767 18.445 23.6515 17.9669 20.8841 18.3355L20.8739 18.3369ZM9.22354 25.4074L9.22355 25.4074C9.38438 25.1045 9.54916 24.8119 9.71761 24.5293C9.54916 24.8119 9.38437 25.1045 9.22354 25.4074ZM29.2253 17.6709L29.2255 17.6704C28.9194 20.0298 27.9767 22.2187 26.5831 24.0205C26.5014 24.1261 26.4182 24.2304 26.3334 24.3333L26.3333 24.3333C27.8638 22.4749 28.9012 20.1684 29.2253 17.6709ZM29.2631 17.3489L29.263 17.3489C29.3095 16.9044 29.3333 16.4543 29.3333 16C29.3333 14.7822 29.1707 13.6036 28.8652 12.4838L28.8651 12.4832C29.1708 13.6032 29.3334 14.782 29.3334 16C29.3334 16.4543 29.3096 16.9044 29.2631 17.3489ZM23.1782 27.2123L23.1782 27.2123C24.196 26.5559 25.1223 25.7653 25.9333 24.8667L24.9333 24L24.9334 24L25.9334 24.8666C25.844 24.9657 25.7532 25.0635 25.661 25.1599C24.917 25.938 24.0839 26.6283 23.1782 27.2123ZM24.6763 11.3036C25.3052 11.4262 25.9705 11.5038 26.6737 11.5271C26.4839 11.0851 26.2672 10.6563 26.0259 10.2432C25.6634 10.4899 25.19 10.8436 24.6763 11.3036ZM24.8236 8.54547C24.3377 7.97285 23.7988 7.44744 23.2159 6.97827L22.998 6.80287L22.9956 6.8056L22.6988 6.59064C20.8288 5.23655 18.51 4.4 16.0001 4.4C15.9278 4.4 15.8557 4.40067 15.7837 4.402C15.8382 4.50084 15.897 4.60496 15.9603 4.71369C16.441 5.5403 17.1735 6.62727 18.196 7.68956C19.2592 8.79415 20.6329 9.87045 22.3685 10.602C22.5902 10.3715 22.8109 10.1574 23.0267 9.95927C23.7038 9.33793 24.3388 8.86996 24.8236 8.54547ZM28.5443 11.4706L28.5442 11.4706C27.7056 9.15291 26.2381 7.13215 24.3333 5.60005L24.3334 5.6C24.3684 5.6282 24.4034 5.65656 24.4381 5.68509C24.5065 5.74117 24.5742 5.7979 24.6414 5.85525C26.3965 7.35362 27.7515 9.27941 28.5443 11.4706ZM14.3037 4.52463C14.5849 5.09186 15.0678 5.97201 15.782 6.95307C15.0678 5.97201 14.5849 5.09185 14.3038 4.52462L14.3037 4.52463Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Chord<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/funnel-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M3 5H21V11H19V15.5H16V20H8V15.5H5V11H3V5ZM19.5 6.5H4.5V9.5H5H19H19.5V6.5ZM17.5 11H6.5V14H8H16H17.5V11ZM14.5 15.5H9.5V18.5H14.5V15.5Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Funnel<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/cone-funnel-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M3 5H21L19.5 9.5L18.2143 14.6429L17.5 20H6.5L5.95313 15.3125L4.5 9.5L3 5ZM5.08114 6.5L6.08114 9.5H17.9189L18.9189 6.5H5.08114ZM6.42116 11L7.17116 14H16.8288L17.5788 11H6.42116ZM7.48517 15.5L7.83517 18.5H16.1867L16.5867 15.5H7.48517Z\"></path></svg><span>Cone <span class=\"_titleTail_m2pa9_214\">Funnel<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/pyramid-series/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.0203 1.82281L21.1971 20.75H2.26996L12.0203 1.82281ZM4.73003 19.25H18.8029L17.1025 15.743C17.069 15.7476 17.0348 15.75 17 15.75H6.53306L4.73003 19.25ZM7.30579 14.25H16.3786L14.9241 11.25H9C8.9515 11.25 8.90408 11.2454 8.85814 11.2366L7.30579 14.25ZM9.62397 9.74998H14.1968L11.9797 5.17716L9.62397 9.74998Z\"></path></svg><span><span class=\"_titleTail_m2pa9_214\">Pyramid<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div><hr class=\"_divider_m2pa9_133\"/><div class=\"_section_m2pa9_110\"><h5 class=\"_sectionTitle_m2pa9_115\">Gauges</h5><a href=\"/javascript/radial-gauge/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" size=\"32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M15.9895 5.00023C17.686 4.99245 19.3674 5.31904 20.9376 5.96134C22.5079 6.60364 23.9361 7.54906 25.1409 8.74357C26.3456 9.93808 27.3031 11.3583 27.9587 12.923C28.6143 14.4877 28.9552 16.1663 28.9618 17.8628C28.9659 20.813 27.9449 23.673 26.0735 25.9536L25.136 27.06L23.4469 25.6327L24.1057 24.8979L24.1732 24.8304C25.7071 23.0668 26.6156 20.8461 26.7576 18.5131H24.0972V16.351H26.69C26.4156 14.4258 25.6148 12.6138 24.3759 11.1148L22.7966 12.6941L21.268 11.1655L22.8473 9.58616C21.1956 8.24659 19.1869 7.42141 17.0705 7.21296V10.4054H14.9085V7.21296C12.7917 7.41994 10.7826 8.24529 9.1317 9.58616L10.711 11.1655L9.18237 12.6941L7.60306 11.1148C6.36414 12.6138 5.56333 14.4258 5.28898 16.351H7.88176V18.5131H5.19608C5.31553 20.7221 6.13822 22.835 7.54394 24.5432L8.49829 25.6327L6.88519 27.06L6.17576 26.2154C4.11303 23.9077 2.9813 20.9158 3.00023 17.8206C3.02479 14.3987 4.40657 11.1265 6.84205 8.72264C9.27754 6.31883 12.5676 4.98 15.9895 5.00023Z\"></path><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M17.4337 24.5128L22.208 13L14.0637 22.6083C14.0016 22.6723 13.9437 22.7406 13.8905 22.8125L13.7316 23L13.7587 23.0155C13.594 23.3061 13.5 23.6421 13.5 24C13.5 25.1046 14.3954 26 15.5 26C16.4273 26 17.2072 25.3689 17.4337 24.5128Z\"></path></svg><span>Radial <span class=\"_titleTail_m2pa9_214\">Gauge<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a><a href=\"/javascript/linear-gauge/\" tabindex=\"0\" class=\"_item_m2pa9_117 _hasIcon_m2pa9_199\"><svg focusable=\"false\" preserveAspectRatio=\"xMidYMid meet\" fill=\"currentColor\" aria-hidden=\"true\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" class=\"_icon_1jqgc_1 icon _itemIcon_m2pa9_218\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M30,22H16V21H14v1H2v6H14v1h2V28H30ZM4,26V24H14v2Zm24,0H16V24H28Z\"></path><path d=\"M30,13H24V12H22v1H2v6H22v1h2V19h6ZM4,17V15H22v2Zm24,0H24V15h4Z\"></path><path d=\"M30,4H10V3H8V4H2v6H8v1h2V10H30ZM4,8V6H8V8ZM28,8H10V6H28Z\"></path></svg><span>Linear <span class=\"_titleTail_m2pa9_214\">Gauge<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon _enterpriseIcon_m2pa9_233\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></span></span></a></div></div></div></div></div><!--astro:end--></astro-island> <div id=\"doc-content\" class=\"_docPage_1wzld_11\"> <astro-island uid=\"piHe8\" prefix=\"r20\" component-url=\"/src/components/docs/components/Header.tsx\" component-export=\"Header\" renderer-url=\"/@fs/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/react/dist/client.js\" props=\"{&quot;title&quot;:[0,&quot;Maps - Routes and Connections&quot;],&quot;framework&quot;:[0,&quot;javascript&quot;],&quot;isEnterprise&quot;:[0,true],&quot;path&quot;:[0,&quot;/javascript/map-lines/&quot;],&quot;menuItems&quot;:[1,[[0,{&quot;items&quot;:[1,[[0,{&quot;title&quot;:[0,&quot;AG Grid&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;AG Studio&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/studio/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Gantt&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-gantt/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Scheduler&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-scheduler/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Calendar&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-calendar/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Bryntum Task Board&quot;],&quot;url&quot;:[0,&quot;https://www.ag-grid.com/campaigns/bryntum-task-board/&quot;],&quot;isCollapsed&quot;:[0,true]}],[0,{&quot;title&quot;:[0,&quot;Examples&quot;],&quot;path&quot;:[0,&quot;/examples&quot;]}],[0,{&quot;title&quot;:[0,&quot;Gallery&quot;],&quot;path&quot;:[0,&quot;/gallery&quot;]}],[0,{&quot;title&quot;:[0,&quot;Theme Builder&quot;],&quot;path&quot;:[0,&quot;/theme-builder&quot;]}],[0,{&quot;title&quot;:[0,&quot;Docs&quot;],&quot;path&quot;:[0,&quot;./quick-start&quot;]}],[0,{&quot;title&quot;:[0,&quot;API&quot;],&quot;path&quot;:[0,&quot;/options&quot;]}],[0,{&quot;title&quot;:[0,&quot;Community&quot;],&quot;path&quot;:[0,&quot;/community&quot;]}],[0,{&quot;title&quot;:[0,&quot;Pricing&quot;],&quot;path&quot;:[0,&quot;/license-pricing&quot;]}],[0,{&quot;title&quot;:[0,&quot;Contact Us&quot;],&quot;path&quot;:[0,&quot;/contact&quot;]}],[0,{&quot;title&quot;:[0,&quot;GitHub&quot;],&quot;url&quot;:[0,&quot;https://github.com/ag-grid/ag-charts&quot;],&quot;icon&quot;:[0,&quot;github&quot;]}]]]}]]],&quot;version&quot;:[0,&quot;15.0.0&quot;],&quot;markdownHref&quot;:[0,&quot;/javascript/map-lines.md&quot;]}\" ssr client=\"load\" before-hydration-url=\"/@id/astro:scripts/before-hydration.js\" opts=\"{&quot;name&quot;:&quot;Header&quot;,&quot;value&quot;:true}\" server-render-time=\"15.320510999998078\" await-children><header class=\"_docsPageHeader_xp6zp_1\"><div id=\"top\" class=\"_pageTitleContainer_xp6zp_26\"><h1 class=\"_docsPageTitle_xp6zp_10\"><span class=\"_headerFramework_xp6zp_52\">JavaScript Charts</span><span class=\"_titleText_xp6zp_20\" data-page-title=\"true\">Maps - Routes and Connections</span></h1><span class=\"_version_xp6zp_69\">Version 15.0.0</span><div class=\"_headerActions_xp6zp_79\"><div class=\"_markdownActions_qgpvn_1\"><button type=\"button\" id=\"radix-:r20R2t:\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-state=\"closed\" tabindex=\"0\" class=\"_trigger_qgpvn_6\" aria-label=\"AI Options\"><span class=\"_triggerLabel_qgpvn_33\" aria-hidden=\"true\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"none\" viewBox=\"0 0 16 16\" class=\"_triggerIcon_qgpvn_39\"><g clip-path=\"url(#ai-sparkle-clip)\"><path fill=\"url(#ai-sparkle-gradient)\" d=\"M7.345 1.876a.667.667 0 0 1 1.31 0l.701 3.705a1.33 1.33 0 0 0 1.063 1.063l3.705.7a.666.666 0 0 1 0 1.311l-3.705.7a1.33 1.33 0 0 0-1.063 1.063l-.7 3.706a.667.667 0 0 1-1.311 0l-.7-3.706a1.33 1.33 0 0 0-1.063-1.062l-3.706-.7a.667.667 0 0 1 0-1.312l3.706-.7A1.33 1.33 0 0 0 6.644 5.58z\"></path><path fill=\"#ff9267\" d=\"M13.5.438c.31 0 .563.251.563.562v.938H15a.563.563 0 0 1 0 1.125h-.937V4a.562.562 0 1 1-1.126 0v-.937H12a.562.562 0 1 1 0-1.126h.938V1c0-.31.251-.562.562-.562\"></path><path fill=\"#54a7ff\" d=\"M3.5 13.333a.834.834 0 1 0-1.668.002.834.834 0 0 0 1.668-.002m1 0a1.834 1.834 0 1 1-3.669 0 1.834 1.834 0 0 1 3.669 0\"></path></g><defs><linearGradient id=\"ai-sparkle-gradient\" x1=\"12.067\" x2=\"7.434\" y1=\"4.22\" y2=\"14.448\" gradientUnits=\"userSpaceOnUse\"><stop stop-color=\"#ffacac\"></stop><stop offset=\"1\" stop-color=\"#a565ff\"></stop></linearGradient><clipPath id=\"ai-sparkle-clip\"><path fill=\"#fff\" d=\"M0 0h16v16H0z\"></path></clipPath></defs></svg><span class=\"_labelStack_qgpvn_45\"><span class=\"_labelSizer_qgpvn_52\">AI Options</span><span class=\"_labelSizer_qgpvn_52\">Copied</span><span class=\"_labelSizer_qgpvn_52\">Copy failed</span><span>AI Options</span></span></span><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"lucide lucide-chevron-down _chevron_qgpvn_56\" aria-hidden=\"true\"><path d=\"m6 9 6 6 6-6\"></path></svg></button><span class=\"_srOnly_qgpvn_145\" aria-live=\"polite\"></span></div><div class=\"_frameworkSelectorSlot_xp6zp_95\"><div><button type=\"button\" role=\"combobox\" aria-expanded=\"false\" aria-autocomplete=\"none\" dir=\"ltr\" data-state=\"closed\" tabindex=\"0\" aria-label=\"Framework selector\" class=\"_trigger_64ihr_1 _large_64ihr_1 _select_tqwu3_13\"><span style=\"pointer-events:none\"><span class=\"_frameworkItem_tqwu3_7\"><img src=\"/@fs/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/images/fw-logos/javascript.svg?origWidth=256&amp;origHeight=256&amp;origFormat=svg\" alt=\"javascript logo\" class=\"_frameworkLogo_tqwu3_1\"/>JavaScript</span></span><span aria-hidden=\"true\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"lucide lucide-chevron-down _chevronDown_64ihr_109\" aria-hidden=\"true\"><path d=\"m6 9 6 6 6-6\"></path></svg></span></button><select aria-hidden=\"true\" tabindex=\"-1\" style=\"position:absolute;border:0;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0, 0, 0, 0);white-space:nowrap;word-wrap:normal\"></select><nav class=\"_frameworkVersionLinks_tqwu3_17\" aria-label=\"Other framework versions of this page\"><ul><li><a href=\"/react/map-lines/\" tabindex=\"-1\">React Charts</a></li><li><a href=\"/angular/map-lines/\" tabindex=\"-1\">Angular Charts</a></li><li><a href=\"/vue/map-lines/\" tabindex=\"-1\">Vue Charts</a></li></ul></nav></div></div></div></div><a class=\"_enterpriseLabel_xp6zp_104\" href=\"/javascript/community-vs-enterprise/\">Enterprise<svg xmlns=\"http://www.w3.org/2000/svg\" xml:space=\"preserve\" style=\"fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2\" viewBox=\"0 0 32 32\" size=\"32\" class=\"_icon_1jqgc_1 icon\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 2c7.727 0 14 6.273 14 14s-6.273 14-14 14S2 23.727 2 16 8.273 2 16 2Zm.005 3c6.071 0 11 4.929 11 11s-4.929 11-11 11-11-4.929-11-11 4.929-11 11-11Z\"></path><path d=\"M12.226 16.507c0 .549.12 1.05.36 1.502.24.452.554.839.945 1.158.39.32.842.568 1.357.745a4.862 4.862 0 0 0 1.596.267c.746 0 1.393-.174 1.944-.52a6.25 6.25 0 0 0 1.516-1.37l1.81 1.384c-1.33 1.721-3.193 2.58-5.588 2.58-.994 0-1.895-.168-2.702-.504a5.878 5.878 0 0 1-2.049-1.397 6.196 6.196 0 0 1-1.291-2.103 7.422 7.422 0 0 1-.452-2.62c0-.94.164-1.815.492-2.623a6.511 6.511 0 0 1 1.357-2.102 6.189 6.189 0 0 1 2.062-1.397A6.64 6.64 0 0 1 16.192 9c1.117 0 2.062.197 2.834.586.771.391 1.406.901 1.903 1.532a6.04 6.04 0 0 1 1.078 2.128c.221.79.332 1.592.332 2.407v.853H12.226Zm7.559-1.917a5.041 5.041 0 0 0-.254-1.464 3.22 3.22 0 0 0-.678-1.157 3.13 3.13 0 0 0-1.13-.772c-.453-.187-.98-.28-1.585-.28a3.93 3.93 0 0 0-3.633 2.381 3.26 3.26 0 0 0-.279 1.292h7.559Z\"></path></svg></a></header><!--astro:end--></astro-island>  <div class=\"_pageSections_1wzld_29\"> <script type=\"module\" src=\"/@vite/client\"></script>"
```

# Test source

```ts
  1  | import { expect, test } from './fixture';
  2  | import { gotoUrl, toPageUrl } from './util';
  3  | 
  4  | // Docs pages embed a hidden, build-time copy of each example's source so crawlers can index it.
  5  | // The example runner island then removes that copy and shows the same files behind its Code button.
  6  | // Both halves matter: the raw HTML has to carry the code, and the page a user sees must not carry
  7  | // it twice or show anything a crawler could not.
  8  | 
  9  | // The HTML embeds the TypeScript variant, matching the markdown twin page. A first visit shows the
  10 | // JavaScript variant in the code viewer (the docs default), so the two main files differ.
  11 | const PAGES = [
  12 |     {
  13 |         path: 'react/quick-start/',
  14 |         exampleName: 'basic-example',
  15 |         embeddedMainFile: 'index.tsx',
  16 |         viewerMainFile: 'index.jsx',
  17 |     },
  18 |     {
  19 |         path: 'javascript/quick-start/',
  20 |         exampleName: 'basic-example',
  21 |         embeddedMainFile: 'main.ts',
  22 |         viewerMainFile: 'main.js',
  23 |     },
  24 | ];
  25 | 
  26 | test.describe('Example source embedded for crawlers', () => {
  27 |     for (const { path, exampleName, embeddedMainFile, viewerMainFile } of PAGES) {
  28 |         test(`${path} serves the ${exampleName} source in its HTML`, async ({ request }) => {
  29 |             const response = await request.get(toPageUrl(path));
  30 |             expect(response.ok()).toBe(true);
  31 |             const html = await response.text();
  32 | 
  33 |             const panel = html.match(
  34 |                 new RegExp(
  35 |                     `<div id="example-${exampleName}"[\\s\\S]*?<div class="example-runner-source-code"[^>]*>([\\s\\S]*?)</div>`
  36 |                 )
  37 |             );
  38 |             expect(panel, 'hidden source panel inside the example container').not.toBeNull();
  39 | 
  40 |             const panelHtml = panel![0];
  41 |             expect(panelHtml).toContain(' hidden');
  42 |             expect(panelHtml).toContain(`<figcaption>${embeddedMainFile}</figcaption>`);
  43 |             expect(panelHtml).toContain(`<code data-file-name="${embeddedMainFile}">`);
  44 |             // Only the main file is embedded; the Code button fetches the rest at runtime
  45 |             expect(panelHtml.match(/<figure>/g)).toHaveLength(1);
  46 |             // The quick start example charts ice cream sales, whichever framework renders it
  47 |             expect(panelHtml).toContain('iceCreamSales');
  48 |             // The generator's harness is not part of what the Code button shows
  49 |             expect(panelHtml).not.toContain('DARK MODE');
  50 |         });
  51 | 
  52 |         test(`${path} shows the same ${exampleName} source behind the Code button`, async ({ page }) => {
  53 |             await gotoUrl(page, toPageUrl(path));
  54 | 
  55 |             const container = page.locator(`#example-${exampleName}`);
  56 |             // The runner hydrates when scrolled into view, and only then owns the code viewer
  57 |             await container.scrollIntoViewIfNeeded();
  58 |             // `exact`, so the CodeSandbox button in the same footer cannot match
  59 |             const codeButton = container.getByRole('button', { name: 'Code', exact: true });
  60 |             await expect(codeButton).toBeVisible();
  61 |             // The island owns the code viewer once mounted, so the build-time copy is gone
  62 |             await expect(container.locator('[data-example-source-code]')).toHaveCount(0);
  63 | 
  64 |             await codeButton.click();
  65 |             await expect(container.getByRole('button', { name: viewerMainFile })).toBeVisible();
  66 |             await expect(container.locator('pre.code')).toContainText('iceCreamSales');
  67 |         });
  68 |     }
  69 | 
  70 |     // Each Map Lines example has a topology.ts of up to ~680KB, which took the page past the 2MB
  71 |     // Googlebot reads when every file was embedded
  72 |     test('leaves data files out of the embedded source', async ({ request }) => {
  73 |         const response = await request.get(toPageUrl('javascript/map-lines/'));
  74 |         expect(response.ok()).toBe(true);
  75 |         const body = await response.body();
  76 |         const html = body.toString();
  77 | 
> 78 |         expect(html).toContain('<code data-file-name="main.ts">');
     |                      ^ Error: expect(received).toContain(expected) // indexOf
  79 |         expect(html).not.toContain('data-file-name="topology.ts"');
  80 |         expect(body.byteLength).toBeLessThan(2 * 1024 * 1024);
  81 |     });
  82 | });
  83 | 
```