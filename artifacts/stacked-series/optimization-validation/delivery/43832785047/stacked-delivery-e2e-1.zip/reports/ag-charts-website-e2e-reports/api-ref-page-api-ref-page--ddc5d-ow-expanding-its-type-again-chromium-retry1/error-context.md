# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> stops a nested contextMenu items row expanding its type again
- Location: e2e/api-ref-page.spec.ts:366:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#reference-AgChartOptions-contextMenu-items-axis-items')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('#reference-AgChartOptions-contextMenu-items-axis-items')

```

```yaml
- banner:
  - link "Home":
    - /url: /
    - img
    - img
  - button "Products"
  - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.": Search Ctrl K
  - navigation:
    - list:
      - listitem:
        - link "AG Charts Examples":
          - /url: /examples/
          - text: Examples
      - listitem:
        - link "AG Charts Gallery":
          - /url: /gallery/
          - text: Gallery
      - listitem:
        - link "AG Charts Theme Builder":
          - /url: /theme-builder/
          - text: Theme Builder
      - listitem:
        - link "AG Charts Docs":
          - /url: /react/quick-start/
          - text: Docs
      - listitem:
        - link "AG Charts API":
          - /url: /options/
          - text: API
      - listitem:
        - link "AG Charts Community":
          - /url: /community/
          - text: Community
      - listitem:
        - link "AG Charts Pricing":
          - /url: /license-pricing/
          - text: Pricing
      - listitem:
        - link "AG Charts Contact Us":
          - /url: /contact/
          - text: Contact Us
      - listitem:
        - link "AG Charts GitHub":
          - /url: https://github.com/ag-grid/ag-charts
      - listitem:
        - button "Dark mode selector"
- navigation:
  - list:
    - listitem:
      - link "Options API":
        - /url: /options/
    - listitem:
      - link "Themes API":
        - /url: /themes-api/
    - listitem:
      - link "Theme Parameters":
        - /url: /theme-parameters-api/
    - listitem:
      - link "Chart API":
        - /url: /react/api-create-update/
    - listitem:
      - link "Events API":
        - /url: /react/events/
    - listitem:
      - link "Download API":
        - /url: /react/api-download/
    - listitem:
      - link "State API":
        - /url: /react/api-state/
    - listitem:
      - link "Context API":
        - /url: /react/context/
    - listitem:
      - link "TypeScript Generics":
        - /url: /react/ts-generics/
- main
- checkbox "Use dark theme"
- text: Use dark theme
- banner:
  - heading "Error" [level=2]
  - heading "An error occurred." [level=1]
- text: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
- heading "server/getInterfacesReference.ts:12:26" [level=2]
- button "Open in editor"
- code: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types'; import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages'; import { pathJoin } from '@utils/pathJoin'; import { readFileSync } from 'node:fs'; import { entries } from 'ag-charts-core'; type DevFileKey = keyof typeof DEV_FILE_PATH_MAP; function getJsonFromDevFile(devFileKey: DevFileKey) { const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]); const fileContents = readFileSync(file).toString(); ^ return fileContents === '' ? null : JSON.parse(fileContents); } /** * Get interfaces reference from the file system * * For static site generation */ export function getInterfacesReference() { const jsonContent = getJsonFromDevFile('resolved-interfaces.json'); return new Map(entries(jsonContent)) as ApiReferenceType; }"
- heading "Stack Trace" [level=2]
- text: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/components/ApiReferenceFallback.astro:32:1) at AstroComponentInstance.ApiReferenceFallback (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:83:23 at Array.map (<anonymous>) at renderSlots (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:82:21) at renderFrameworkComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:66:3) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:358:5) at Object.default (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options.astro:17:5) at new AstroComponentInstance (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:14:30) at createAstroComponentInstance (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:71:16) at renderAstroComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:340:7) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:344:7) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options.astro:16:1) at options (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at callComponentAsTemplateResultOrResponse (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render.js:216:11) at renderToAsyncIterable (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render.js:248:22) at renderPage (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/page.js:31:5) at handlePages (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/pages/handler.js:24:8) at async eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/middleware/index.ts:103:28) at async callMiddleware (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/middleware/callMiddleware.js:6:5) at async handleMiddleware (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/middleware/astro-middleware.js:26:15) at async render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/routing/handler.js:61:18) at async DevFacadeApp.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/app/base.js:244:7) at async run (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:95:11) at async runWithErrorHandling (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-astro-server/controller.js:63:3) at async handleDevRequest (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:39:3)"
```

# Test source

```ts
  271 |             .evaluate((element, dropdownSelector) => {
  272 |                 const container = element.closest(dropdownSelector)!;
  273 |                 const optionRect = element.getBoundingClientRect();
  274 |                 const containerRect = container.getBoundingClientRect();
  275 |                 // The visible area excludes the container's borders and scrollbar gutter. A pixel of
  276 |                 // slack absorbs the sub-pixel rounding of a fractional scroll offset.
  277 |                 const visibleTop = containerRect.top + container.clientTop;
  278 |                 const visibleBottom = visibleTop + container.clientHeight;
  279 |                 return optionRect.top >= visibleTop - 1 && optionRect.bottom <= visibleBottom + 1;
  280 |             }, SEARCH_DROPDOWN_SELECTOR);
  281 |         expect(selectedIsVisible).toBe(true);
  282 |     });
  283 | 
  284 |     test('direct bar series hash loads and highlights typed union entry', async ({ page }) => {
  285 |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-type'));
  286 | 
  287 |         await expect(getNavigationHighlight(page, /type\s*= 'bar'/)).toBeVisible();
  288 |         await expect(page.locator('header h1')).toContainText("type = 'bar'");
  289 |     });
  290 | 
  291 |     // TODO: AG-16140 disable this test temporarily while converting axis docs to use dictionary
  292 |     test.skip('deep link to number axis property auto expands navigation', async ({ page }) => {
  293 |         await gotoUrl(page, toPageUrl('options/axes/number/#reference-AgNumberAxisOptions-gridLine'));
  294 | 
  295 |         await expect(getNavigationHighlight(page, /gridLine/)).toBeVisible();
  296 |         await expect(getNavigationProperty(page, /^axes/).locator(PROPERTY_EXPANDER_SELECTOR)).toHaveClass(/active/);
  297 |     });
  298 | 
  299 |     test('series navigation expander toggles typed union list', async ({ page }) => {
  300 |         await gotoUrl(page, toPageUrl('options/'));
  301 |         await waitForApiReady(page);
  302 | 
  303 |         const seriesProperty = getNavigationProperty(page, /^series\b/);
  304 |         await expect(seriesProperty).toBeVisible();
  305 |         await seriesProperty.locator(PROPERTY_EXPANDER_SELECTOR).click();
  306 | 
  307 |         const barEntry = getNavigationText(page, "type = 'bar'");
  308 |         await expect(barEntry).toBeVisible();
  309 | 
  310 |         await seriesProperty.locator(PROPERTY_EXPANDER_SELECTOR).click();
  311 |         await expect(barEntry).toHaveCount(0);
  312 |     });
  313 | 
  314 |     test('expands typed union entry to reveal nested properties', async ({ page }) => {
  315 |         await gotoUrl(page, toPageUrl('options/'));
  316 |         await waitForApiReady(page);
  317 | 
  318 |         const seriesProperty = getNavigationProperty(page, /^series\b/);
  319 |         await expect(seriesProperty).toBeVisible();
  320 |         await seriesProperty.locator(PROPERTY_EXPANDER_SELECTOR).click();
  321 | 
  322 |         const barEntry = getNavigationProperty(page, /type\s*= 'bar'/);
  323 |         await barEntry.locator(PROPERTY_EXPANDER_SELECTOR).click();
  324 | 
  325 |         await expect(getNavigationProperty(page, /^xKey$/)).toBeVisible();
  326 |     });
  327 | 
  328 |     // The top-level `axes` node is the union of every axis type; expanding it renders all axis
  329 |     // variants at once, guarding the whole axis surface against a nameless type-literal pageerror.
  330 |     test('expands the axes node into its axis-type variants', async ({ page }) => {
  331 |         await gotoUrl(page, toPageUrl('options/'));
  332 |         await waitForApiReady(page);
  333 | 
  334 |         await expandNavNode(page, /^axes/);
  335 | 
  336 |         await expect(getNavigationProperty(page, /type\s*= 'number'/)).toBeVisible();
  337 |         await expect(getNavigationProperty(page, /type\s*= 'category'/)).toBeVisible();
  338 |     });
  339 | 
  340 |     // `contextMenu.items` variants inherit `type?: AgContextMenuItemType` from a mixin, so the member
  341 |     // named `type` is a type reference; `showOn` is the literal that tells the branches apart.
  342 |     test('expands contextMenu items into showOn-discriminated variants', async ({ page }) => {
  343 |         await gotoUrl(page, toPageUrl('options/'));
  344 |         await waitForApiReady(page);
  345 | 
  346 |         await expandNavNode(page, /^contextMenu/);
  347 |         await expandNavNode(page, /^items/);
  348 | 
  349 |         await expect(getNavigationProperty(page, /showOn\s*= 'axis'/)).toBeVisible();
  350 |         await expect(getNavigationProperty(page, /showOn\s*= 'series-node'/)).toBeVisible();
  351 |         await expect(getNavigationTree(page).getByText('AgContextMenuItemType')).toHaveCount(0);
  352 |     });
  353 | 
  354 |     test('gives each contextMenu items variant its own anchor', async ({ page }) => {
  355 |         await gotoUrl(page, toPageUrl('options/#reference-AgChartOptions-contextMenu-items-axis'));
  356 | 
  357 |         const axisVariant = page.locator('#reference-AgChartOptions-contextMenu-items-axis');
  358 |         await expect(axisVariant).toBeVisible();
  359 |         await expect(axisVariant).toContainText("[showOn='axis']");
  360 |         await expect(page.locator('#reference-AgChartOptions-contextMenu-items-series-node')).toBeVisible();
  361 |     });
  362 | 
  363 |     // A submenu's `items` repeats its ancestor's `AgContextMenuItem[]` type, so it must not expand again.
  364 |     const NESTED_ITEMS_ID = 'reference-AgChartOptions-contextMenu-items-axis-items';
  365 | 
  366 |     test('stops a nested contextMenu items row expanding its type again', async ({ page }) => {
  367 |         // A deep link below the row expands it whenever it can expand.
  368 |         await gotoUrl(page, toPageUrl(`options/#${NESTED_ITEMS_ID}-axis`));
  369 | 
  370 |         const nestedItems = page.locator(`#${NESTED_ITEMS_ID}`);
> 371 |         await expect(nestedItems).toBeVisible();
      |                                   ^ Error: expect(locator).toBeVisible() failed
  372 |         await expect(nestedItems.getByRole('button', { name: /child properties|available interfaces/ })).toHaveCount(0);
  373 |         await expect(page.locator(`[id^="${NESTED_ITEMS_ID}-"]`)).toHaveCount(0);
  374 | 
  375 |         await nestedItems.getByRole('button', { name: 'See more details about items' }).click();
  376 |         await expect(page.locator(`#${NESTED_ITEMS_ID}-details`)).toBeVisible();
  377 |     });
  378 | 
  379 |     test('links a nested contextMenu items row back to its ancestor', async ({ page }) => {
  380 |         await gotoUrl(page, toPageUrl(`options/#${NESTED_ITEMS_ID}`));
  381 | 
  382 |         await page
  383 |             .locator(`#${NESTED_ITEMS_ID}`)
  384 |             .getByRole('link', { name: 'Recursive, see contextMenu.items' })
  385 |             .click();
  386 | 
  387 |         await expect(page).toHaveURL(/#reference-AgChartOptions-contextMenu-items$/);
  388 |         await expect(page.locator('#reference-AgChartOptions-contextMenu-items')).toBeInViewport();
  389 |     });
  390 | 
  391 |     test('marks a nested contextMenu items nav entry recursive instead of expanding it', async ({ page }) => {
  392 |         await gotoUrl(page, toPageUrl('options/'));
  393 |         await waitForApiReady(page);
  394 | 
  395 |         await expandNavNode(page, /^contextMenu/);
  396 |         await expandNavNode(page, /^items/);
  397 |         await expandNavNode(page, /showOn\s*= 'series-node'/);
  398 | 
  399 |         const nestedItems = getNavigationProperty(page, /^items.*recursive/);
  400 |         await expect(nestedItems).toBeVisible();
  401 |         await expect(nestedItems.locator(PROPERTY_EXPANDER_SELECTOR)).toHaveCount(0);
  402 | 
  403 |         await getNavigationTree(page).getByRole('link', { name: 'items (recursive)', exact: true }).click();
  404 | 
  405 |         await expect(page).toHaveURL(/#reference-AgChartOptions-contextMenu-items-series-node-items$/);
  406 |         await expect(page.locator('#reference-AgChartOptions-contextMenu-items-series-node-items')).toBeInViewport();
  407 |     });
  408 | 
  409 |     // `crossLines` sits under the `{ type = 'number' ... }` nav node, collapsed by default.
  410 |     // Deep-linking to a sibling axis property auto-expands that node without expanding `crossLines`.
  411 |     const NUMBER_AXIS_URL = 'options/axes/number/#reference-AgNumberAxisOptions-nice';
  412 | 
  413 |     test('expands an axis cross-line member into its discriminated variants', async ({ page }) => {
  414 |         await gotoUrl(page, toPageUrl(NUMBER_AXIS_URL));
  415 | 
  416 |         const crossLines = getNavigationProperty(page, /^crossLines/);
  417 |         await expect(crossLines).toBeVisible();
  418 |         await crossLines.locator(PROPERTY_EXPANDER_SELECTOR).click();
  419 | 
  420 |         await expect(getNavigationProperty(page, /type\s*= 'line'/)).toBeVisible();
  421 |         await expect(getNavigationProperty(page, /type\s*= 'range'/)).toBeVisible();
  422 |     });
  423 | 
  424 |     test('expands a cross-line variant to its own properties, not the axis properties', async ({ page }) => {
  425 |         await gotoUrl(page, toPageUrl(NUMBER_AXIS_URL));
  426 | 
  427 |         const crossLines = getNavigationProperty(page, /^crossLines/);
  428 |         await expect(crossLines).toBeVisible();
  429 |         await crossLines.locator(PROPERTY_EXPANDER_SELECTOR).click();
  430 | 
  431 |         const lineVariant = getNavigationProperty(page, /type\s*= 'line'/);
  432 |         await lineVariant.locator(PROPERTY_EXPANDER_SELECTOR).click();
  433 | 
  434 |         // `value` is a cross-line line-variant property; it is absent from the axis interface, so
  435 |         // its presence proves the variant resolved to the cross-line type rather than the axis type.
  436 |         await expect(getNavigationProperty(page, /^value$/)).toBeVisible();
  437 |     });
  438 | 
  439 |     test('keeps cross-line variants collapsed after refreshing on another axis property', async ({ page }) => {
  440 |         await gotoUrl(page, toPageUrl(NUMBER_AXIS_URL));
  441 | 
  442 |         const crossLines = getNavigationProperty(page, /^crossLines/);
  443 |         await expect(crossLines).toBeVisible();
  444 |         await crossLines.locator(PROPERTY_EXPANDER_SELECTOR).click();
  445 | 
  446 |         // The variant branches show, but selecting an unrelated axis property must not auto-expand
  447 |         // them, even though they share the axis page.
  448 |         await expect(getNavigationProperty(page, /type\s*= 'line'/)).toBeVisible();
  449 |         await expect(getNavigationTree(page).locator(PROPERTY_NAME_SELECTOR, { hasText: /^value$/ })).toHaveCount(0);
  450 |     });
  451 | 
  452 |     test('renders a cross-line member as a plain array, like series', async ({ page }) => {
  453 |         await gotoUrl(page, toPageUrl(NUMBER_AXIS_URL));
  454 | 
  455 |         const crossLines = getNavigationProperty(page, /^crossLines/);
  456 |         await expect(crossLines).toBeVisible();
  457 |         // A discriminated-union array reads as a plain array, not an array wrapping an object (`[{ }]`).
  458 |         await expect(crossLines).toContainText('[ ... ]');
  459 |         await expect(crossLines).not.toContainText('[{');
  460 |     });
  461 | 
  462 |     // `padding` is the `PixelSize | PaddingOptions` union: the primitive `PixelSize` stays in the
  463 |     // signature text, and the `PaddingOptions` interface variant expands into its own property rows.
  464 |     test('expands the padding union into its interface variant properties', async ({ page }) => {
  465 |         await gotoUrl(page, toPageUrl('options/'));
  466 |         await waitForApiReady(page);
  467 | 
  468 |         await page.getByRole('button', { name: 'See available interfaces of padding', exact: true }).click();
  469 |         const paddingOptions = page.locator('#reference-AgChartOptions-padding-PaddingOptions');
  470 |         await expect(paddingOptions).toBeVisible();
  471 |         await expect(paddingOptions).toContainText('padding[PaddingOptions]');
```