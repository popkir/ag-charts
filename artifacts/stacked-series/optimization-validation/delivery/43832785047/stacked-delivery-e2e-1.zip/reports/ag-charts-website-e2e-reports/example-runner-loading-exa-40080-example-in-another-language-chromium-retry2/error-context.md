# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: example-runner-loading.spec.ts >> example runner shows the loading logo when reloading an example in another language
- Location: e2e/example-runner-loading.spec.ts:41:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.scrollIntoViewIfNeeded: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('div#example-axis-cross-lines-adding')

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e4]:
        - link "Home" [ref=e6] [cursor=pointer]:
          - /url: /
          - img [ref=e7]
          - img [ref=e9]
        - button "Products" [ref=e24] [cursor=pointer]: Products
        - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page." [ref=e28] [cursor=pointer]:
          - img [ref=e29]
          - generic [ref=e31]: Search
          - generic [ref=e32]: Ctrl K
        - navigation [ref=e35]:
          - list [ref=e36]:
            - listitem [ref=e37]:
              - link "AG Charts Examples" [ref=e38] [cursor=pointer]:
                - /url: /examples/
                - text: Examples
            - listitem [ref=e39]:
              - link "AG Charts Gallery" [ref=e40] [cursor=pointer]:
                - /url: /gallery/
                - text: Gallery
            - listitem [ref=e41]:
              - link "AG Charts Theme Builder" [ref=e42] [cursor=pointer]:
                - /url: /theme-builder/
                - text: Theme Builder
            - listitem [ref=e43]:
              - link "AG Charts Docs" [ref=e44] [cursor=pointer]:
                - /url: /javascript/quick-start/
                - text: Docs
            - listitem [ref=e45]:
              - link "AG Charts API" [ref=e46] [cursor=pointer]:
                - /url: /options/
                - text: API
            - listitem [ref=e47]:
              - link "AG Charts Community" [ref=e48] [cursor=pointer]:
                - /url: /community/
                - text: Community
            - listitem [ref=e49]:
              - link "AG Charts Pricing" [ref=e50] [cursor=pointer]:
                - /url: /license-pricing/
                - text: Pricing
            - listitem [ref=e51]:
              - link "AG Charts Contact Us" [ref=e52] [cursor=pointer]:
                - /url: /contact/
                - text: Contact Us
            - listitem [ref=e53]:
              - link "AG Charts GitHub" [ref=e54] [cursor=pointer]:
                - /url: https://github.com/ag-grid/ag-charts
                - img [ref=e55]
            - listitem [ref=e57]:
              - button "Dark mode selector" [ref=e58] [cursor=pointer]
    - main [ref=e60]:
      - generic [ref=e61]:
        - generic [ref=e66]:
          - link "What's New" [ref=e68] [cursor=pointer]:
            - /url: /whats-new/
          - generic [ref=e69]:
            - heading "Getting started" [level=5] [ref=e70]
            - link "Quick Start" [ref=e71] [cursor=pointer]:
              - /url: /javascript/quick-start/
              - generic [ref=e72]: Quick Start
            - link "Key Features" [ref=e73] [cursor=pointer]:
              - /url: /javascript/key-features/
              - generic [ref=e74]: Key Features
            - link "Community vs. Enterprise" [ref=e75] [cursor=pointer]:
              - /url: /javascript/community-vs-enterprise/
              - generic [ref=e76]: Community vs. Enterprise
            - button "Setup" [ref=e78] [cursor=pointer]:
              - img [ref=e79]
              - generic [ref=e81]: Setup
            - button "Tutorials" [ref=e83] [cursor=pointer]:
              - img [ref=e84]
              - generic [ref=e86]: Tutorials
            - button "Security & Compatibility" [ref=e88] [cursor=pointer]:
              - img [ref=e89]
              - generic [ref=e91]: Security & Compatibility
          - separator [ref=e92]
          - generic [ref=e93]:
            - heading "AI Features" [level=5] [ref=e94]
            - link "Skills" [ref=e95] [cursor=pointer]:
              - /url: /javascript/skills/
              - generic [ref=e96]: Skills
          - separator [ref=e97]
          - generic [ref=e98]:
            - heading "Core features" [level=5] [ref=e99]
            - button "Data" [ref=e101] [cursor=pointer]:
              - img [ref=e102]
              - generic [ref=e104]: Data
            - button "Axes" [ref=e106] [cursor=pointer]:
              - img [ref=e107]
              - generic [ref=e109]: Axes
            - generic [ref=e110]:
              - button "Data Elements" [ref=e111] [cursor=pointer]:
                - img [ref=e112]
                - generic [ref=e114]: Data Elements
              - generic [ref=e117]:
                - link "Cross Lines" [ref=e118] [cursor=pointer]:
                  - /url: /javascript/axes-cross-lines/
                  - generic [ref=e119]: Cross Lines
                - link "Legend" [ref=e120] [cursor=pointer]:
                  - /url: /javascript/legend/
                  - generic [ref=e121]: Legend
                - link "Formatters" [ref=e122] [cursor=pointer]:
                  - /url: /javascript/formatters/
                  - generic [ref=e123]: Formatters
                - link "Stylers" [ref=e124] [cursor=pointer]:
                  - /url: /javascript/stylers/
                  - generic [ref=e125]: Stylers
                - link "Series Bars" [ref=e126] [cursor=pointer]:
                  - /url: /javascript/bars/
                  - generic [ref=e127]: Series Bars
                - link "Series Fills" [ref=e128] [cursor=pointer]:
                  - /url: /javascript/fills/
                  - generic [ref=e129]: Series Fills
                - link "Series Labels" [ref=e130] [cursor=pointer]:
                  - /url: /javascript/series-labels/
                  - generic [ref=e131]: Series Labels
                - link "Series Markers" [ref=e132] [cursor=pointer]:
                  - /url: /javascript/markers/
                  - generic [ref=e133]: Series Markers
                - link "Style Segments" [ref=e134] [cursor=pointer]:
                  - /url: /javascript/style-segments/
                  - generic [ref=e135]: Style Segments
                - link "Annotations" [ref=e136] [cursor=pointer]:
                  - /url: /javascript/annotations/
                  - generic [ref=e138]:
                    - text: Annotations
                    - img [ref=e139]
                - link "Background Regions" [ref=e142] [cursor=pointer]:
                  - /url: /javascript/background-regions/
                  - generic [ref=e143]:
                    - text: Background
                    - generic [ref=e144]:
                      - text: Regions
                      - img [ref=e145]
                - link "Colour Scale" [ref=e148] [cursor=pointer]:
                  - /url: /javascript/colour-scale/
                  - generic [ref=e149]:
                    - text: Colour
                    - generic [ref=e150]:
                      - text: Scale
                      - img [ref=e151]
                - link "Error Bars" [ref=e154] [cursor=pointer]:
                  - /url: /javascript/error-bars/
                  - generic [ref=e155]:
                    - text: Error
                    - generic [ref=e156]:
                      - text: Bars
                      - img [ref=e157]
            - button "Interactivity" [ref=e161] [cursor=pointer]:
              - img [ref=e162]
              - generic [ref=e164]: Interactivity
            - button "Layout & Styling" [ref=e166] [cursor=pointer]:
              - img [ref=e167]
              - generic [ref=e169]: Layout & Styling
          - separator [ref=e170]
          - generic [ref=e171]:
            - heading "Specialised Charts" [level=5] [ref=e172]
            - button "Financial Charts" [ref=e174] [cursor=pointer]:
              - img [ref=e175]
              - generic [ref=e177]: Financial Charts
            - button "Maps" [ref=e179] [cursor=pointer]:
              - img [ref=e180]
              - generic [ref=e182]: Maps
            - link "Org Chart" [ref=e183] [cursor=pointer]:
              - /url: /javascript/org-chart/
              - img [ref=e184]
              - generic [ref=e186]:
                - text: Org
                - generic [ref=e187]:
                  - text: Chart
                  - img [ref=e188]
            - link "Quadrant Chart" [ref=e191] [cursor=pointer]:
              - /url: /javascript/quadrant-chart/
              - img [ref=e192]
              - generic [ref=e204]:
                - text: Quadrant
                - generic [ref=e205]:
                  - text: Chart
                  - img [ref=e206]
          - separator [ref=e209]
          - generic [ref=e210]:
            - heading "Series" [level=5] [ref=e211]
            - link "Bar" [ref=e212] [cursor=pointer]:
              - /url: /javascript/bar-series/
              - img [ref=e213]
              - generic [ref=e215]: Bar
            - link "Line" [ref=e216] [cursor=pointer]:
              - /url: /javascript/line-series/
              - img [ref=e217]
              - generic [ref=e219]: Line
            - link "Area" [ref=e220] [cursor=pointer]:
              - /url: /javascript/area-series/
              - img [ref=e221]
              - generic [ref=e223]: Area
            - link "Scatter" [ref=e224] [cursor=pointer]:
              - /url: /javascript/scatter-series/
              - img [ref=e225]
              - generic [ref=e232]: Scatter
            - link "Bubble" [ref=e233] [cursor=pointer]:
              - /url: /javascript/bubble-series/
              - img [ref=e234]
              - generic [ref=e239]: Bubble
            - link "Pie" [ref=e240] [cursor=pointer]:
              - /url: /javascript/pie-series/
              - img [ref=e241]
              - generic [ref=e243]: Pie
            - link "Donut" [ref=e244] [cursor=pointer]:
              - /url: /javascript/donut-series/
              - img [ref=e245]
              - generic [ref=e247]: Donut
            - link "Combination" [ref=e248] [cursor=pointer]:
              - /url: /javascript/combination-series/
              - img [ref=e249]
              - generic [ref=e252]: Combination
            - link "Box Plot" [ref=e253] [cursor=pointer]:
              - /url: /javascript/box-plot-series/
              - img [ref=e254]
              - generic [ref=e257]:
                - text: Box
                - generic [ref=e258]:
                  - text: Plot
                  - img [ref=e259]
            - link "Candlestick" [ref=e262] [cursor=pointer]:
              - /url: /javascript/candlestick-series/
              - img [ref=e263]
              - generic [ref=e268]:
                - text: Candlestick
                - img [ref=e269]
            - link "HLC" [ref=e272] [cursor=pointer]:
              - /url: /javascript/hlc-series/
              - img [ref=e273]
              - generic [ref=e279]:
                - text: HLC
                - img [ref=e280]
            - link "OHLC" [ref=e283] [cursor=pointer]:
              - /url: /javascript/ohlc-series/
              - img [ref=e284]
              - generic [ref=e289]:
                - text: OHLC
                - img [ref=e290]
            - link "Heatmap" [ref=e293] [cursor=pointer]:
              - /url: /javascript/heatmap-series/
              - img [ref=e294]
              - generic [ref=e297]:
                - text: Heatmap
                - img [ref=e298]
            - link "Histogram" [ref=e301] [cursor=pointer]:
              - /url: /javascript/histogram-series/
              - img [ref=e302]
              - generic [ref=e305]:
                - text: Histogram
                - img [ref=e306]
            - link "Nightingale" [ref=e309] [cursor=pointer]:
              - /url: /javascript/nightingale-series/
              - img [ref=e310]
              - generic [ref=e313]:
                - text: Nightingale
                - img [ref=e314]
            - link "Radar Area" [ref=e317] [cursor=pointer]:
              - /url: /javascript/radar-area-series/
              - img [ref=e318]
              - generic [ref=e321]:
                - text: Radar
                - generic [ref=e322]:
                  - text: Area
                  - img [ref=e323]
            - link "Radar Line" [ref=e326] [cursor=pointer]:
              - /url: /javascript/radar-line-series/
              - img [ref=e327]
              - generic [ref=e329]:
                - text: Radar
                - generic [ref=e330]:
                  - text: Line
                  - img [ref=e331]
            - link "Radial Bar" [ref=e334] [cursor=pointer]:
              - /url: /javascript/radial-bar-series/
              - img [ref=e335]
              - generic [ref=e339]:
                - text: Radial
                - generic [ref=e340]:
                  - text: Bar
                  - img [ref=e341]
            - link "Radial Column" [ref=e344] [cursor=pointer]:
              - /url: /javascript/radial-column-series/
              - img [ref=e345]
              - generic [ref=e347]:
                - text: Radial
                - generic [ref=e348]:
                  - text: Column
                  - img [ref=e349]
            - link "Range Area" [ref=e352] [cursor=pointer]:
              - /url: /javascript/range-area-series/
              - img [ref=e353]
              - generic [ref=e355]:
                - text: Range
                - generic [ref=e356]:
                  - text: Area
                  - img [ref=e357]
            - link "Range Bar" [ref=e360] [cursor=pointer]:
              - /url: /javascript/range-bar-series/
              - img [ref=e361]
              - generic [ref=e365]:
                - text: Range
                - generic [ref=e366]:
                  - text: Bar
                  - img [ref=e367]
            - link "Waterfall" [ref=e370] [cursor=pointer]:
              - /url: /javascript/waterfall-series/
              - img [ref=e371]
              - generic [ref=e375]:
                - text: Waterfall
                - img [ref=e376]
            - link "Sunburst" [ref=e379] [cursor=pointer]:
              - /url: /javascript/sunburst-series/
              - img [ref=e380]
              - generic [ref=e383]:
                - text: Sunburst
                - img [ref=e384]
            - link "Treemap" [ref=e387] [cursor=pointer]:
              - /url: /javascript/treemap-series/
              - img [ref=e388]
              - generic [ref=e391]:
                - text: Treemap
                - img [ref=e392]
            - link "Sankey" [ref=e395] [cursor=pointer]:
              - /url: /javascript/sankey-series/
              - img [ref=e396]
              - generic [ref=e399]:
                - text: Sankey
                - img [ref=e400]
            - link "Chord" [ref=e403] [cursor=pointer]:
              - /url: /javascript/chord-series/
              - img [ref=e404]
              - generic [ref=e407]:
                - text: Chord
                - img [ref=e408]
            - link "Funnel" [ref=e411] [cursor=pointer]:
              - /url: /javascript/funnel-series/
              - img [ref=e412]
              - generic [ref=e415]:
                - text: Funnel
                - img [ref=e416]
            - link "Cone Funnel" [ref=e419] [cursor=pointer]:
              - /url: /javascript/cone-funnel-series/
              - img [ref=e420]
              - generic [ref=e422]:
                - text: Cone
                - generic [ref=e423]:
                  - text: Funnel
                  - img [ref=e424]
            - link "Pyramid" [ref=e427] [cursor=pointer]:
              - /url: /javascript/pyramid-series/
              - img [ref=e428]
              - generic [ref=e431]:
                - text: Pyramid
                - img [ref=e432]
          - separator [ref=e435]
          - generic [ref=e436]:
            - heading "Gauges" [level=5] [ref=e437]
            - link "Radial Gauge" [ref=e438] [cursor=pointer]:
              - /url: /javascript/radial-gauge/
              - img [ref=e439]
              - generic [ref=e442]:
                - text: Radial
                - generic [ref=e443]:
                  - text: Gauge
                  - img [ref=e444]
            - link "Linear Gauge" [ref=e447] [cursor=pointer]:
              - /url: /javascript/linear-gauge/
              - img [ref=e448]
              - generic [ref=e452]:
                - text: Linear
                - generic [ref=e453]:
                  - text: Gauge
                  - img [ref=e454]
        - generic [ref=e460]:
          - heading "JavaScript Charts Cross Lines" [level=1] [ref=e461]:
            - generic [ref=e462]: JavaScript Charts
            - generic [ref=e463]: Cross Lines
          - generic [ref=e464]: Version 15.0.0
          - generic [ref=e465]:
            - button "AI Options" [ref=e467] [cursor=pointer]:
              - generic [ref=e468]:
                - img [ref=e469]
                - generic [ref=e475]: AI Options
              - img [ref=e476]
            - generic [ref=e480]:
              - combobox "Framework selector" [ref=e481] [cursor=pointer]:
                - generic:
                  - generic:
                    - img "javascript logo"
                    - text: JavaScript
                - img [ref=e483]
              - navigation "Other framework versions of this page" [ref=e485]:
                - list [ref=e486]:
                  - listitem:
                    - link "React Charts" [ref=e487] [cursor=pointer]:
                      - /url: /react/axes-cross-lines
                  - listitem:
                    - link "Angular Charts" [ref=e488] [cursor=pointer]:
                      - /url: /angular/axes-cross-lines
                  - listitem:
                    - link "Vue Charts" [ref=e489] [cursor=pointer]:
                      - /url: /vue/axes-cross-lines
  - generic [ref=e492]:
    - generic [ref=e493]:
      - checkbox "Use dark theme" [ref=e494]
      - generic [ref=e495] [cursor=pointer]:
        - img [ref=e496]
        - img [ref=e500]
        - generic [ref=e504]: Use dark theme
    - banner [ref=e505]:
      - generic [ref=e506]:
        - heading "Error" [level=2] [ref=e507]
        - heading "An error occurred." [level=1] [ref=e508]
      - img [ref=e511]
    - generic [ref=e515]:
      - img [ref=e517]
      - generic [ref=e519]: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
    - generic [ref=e520]:
      - generic [ref=e521]:
        - heading "server/getInterfacesReference.ts:12:26" [level=2] [ref=e522]
        - button "Open in editor" [ref=e524]:
          - text: Open in editor
          - img [ref=e525]
      - code [ref=e530]:
        - generic [ref=e531]: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types';"
        - generic [ref=e532]: "import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages';"
        - generic [ref=e533]: "import { pathJoin } from '@utils/pathJoin';"
        - generic [ref=e534]: "import { readFileSync } from 'node:fs';"
        - generic [ref=e536]: "import { entries } from 'ag-charts-core';"
        - generic [ref=e538]: type DevFileKey = keyof typeof DEV_FILE_PATH_MAP;
        - generic [ref=e540]: "function getJsonFromDevFile(devFileKey: DevFileKey) {"
        - generic [ref=e541]: const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]);
        - generic [ref=e542]: const fileContents = readFileSync(file).toString();
        - generic [ref=e543]: ^
        - generic [ref=e544]: "return fileContents === '' ? null : JSON.parse(fileContents);"
        - generic [ref=e545]: "}"
        - generic [ref=e547]: /**
        - generic [ref=e548]: "* Get interfaces reference from the file system"
        - generic [ref=e549]: "*"
        - generic [ref=e550]: "* For static site generation"
        - generic [ref=e551]: "*/"
        - generic [ref=e552]: "export function getInterfacesReference() {"
        - generic [ref=e553]: const jsonContent = getJsonFromDevFile('resolved-interfaces.json');
        - generic [ref=e554]: return new Map(entries(jsonContent)) as ApiReferenceType;
        - generic [ref=e555]: "}"
    - generic [ref=e557]:
      - generic [ref=e558]:
        - heading "Stack Trace" [level=2] [ref=e559]
        - img [ref=e561] [cursor=pointer]
      - generic [ref=e565]: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/ApiReference.astro:15:1) at AstroComponentInstance.ApiReference (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:83:23 at Array.map (<anonymous>) at renderSlots (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:82:21) at renderFrameworkComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:66:3) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:358:5) at renderTreeNodeToFactoryResult (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:153:17) at factory (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:118:10) at AstroComponentInstance.eval (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at Slots.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/slots.js:62:22) at eval (/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/tabs/TabsWithHtmlChildren.astro:13:1) at AstroComponentInstance.TabsWithHtmlChildren (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:52:18 at new BufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:162:18) at createBufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:186:5) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:51:22)"
```

# Test source

```ts
  1  | import type { Page } from '@playwright/test';
  2  | 
  3  | import { expect, test } from './fixture';
  4  | import { gotoUrl, toPageUrl } from './util';
  5  | 
  6  | test.use({ viewport: { width: 1400, height: 900 } });
  7  | 
  8  | const PAGE_NAME = 'axes-cross-lines';
  9  | const EXAMPLE_NAME = 'axis-cross-lines-adding';
  10 | const IFRAME_ID = `loading-frame-${PAGE_NAME}-${EXAMPLE_NAME}`;
  11 | 
  12 | interface LoadingStatesSeen {
  13 |     loadingLogo: boolean;
  14 |     iframeHidden: boolean;
  15 | }
  16 | 
  17 | type WindowWithStates = Window & { __loadingStatesSeen: LoadingStatesSeen };
  18 | 
  19 | /**
  20 |  * A reload can complete faster than an assertion poll interval, so record whether the transient
  21 |  * states were ever entered rather than trying to catch them.
  22 |  */
  23 | async function recordLoadingStates(page: Page, iframeId: string) {
  24 |     await page.evaluate((id) => {
  25 |         const iframe = document.getElementById(id) as HTMLIFrameElement;
  26 |         const exampleOuter = iframe.closest('.example-runner-outer')!;
  27 |         const seen: LoadingStatesSeen = { loadingLogo: false, iframeHidden: false };
  28 |         (window as unknown as WindowWithStates).__loadingStatesSeen = seen;
  29 | 
  30 |         new MutationObserver(() => {
  31 |             seen.loadingLogo ||= exampleOuter.querySelector('.logomark') != null;
  32 |             seen.iframeHidden ||= iframe.style.visibility === 'hidden';
  33 |         }).observe(exampleOuter, { attributes: true, childList: true, subtree: true });
  34 |     }, iframeId);
  35 | }
  36 | 
  37 | function getLoadingStates(page: Page) {
  38 |     return page.evaluate(() => (window as unknown as WindowWithStates).__loadingStatesSeen);
  39 | }
  40 | 
  41 | test('example runner shows the loading logo when reloading an example in another language', async ({ page }) => {
  42 |     await gotoUrl(page, toPageUrl(`javascript/${PAGE_NAME}`));
  43 | 
  44 |     const exampleOuter = page.locator(`div#example-${EXAMPLE_NAME}`);
  45 |     const iframe = page.locator(`#${IFRAME_ID}`);
  46 |     const loadingLogo = exampleOuter.locator('.logomark');
  47 | 
> 48 |     await exampleOuter.scrollIntoViewIfNeeded();
     |                        ^ Error: locator.scrollIntoViewIfNeeded: Test timeout of 30000ms exceeded.
  49 |     await expect(iframe).toHaveCSS('visibility', 'visible', { timeout: 30_000 });
  50 |     await expect(loadingLogo).toHaveCount(0);
  51 | 
  52 |     await recordLoadingStates(page, IFRAME_ID);
  53 | 
  54 |     await exampleOuter.getByRole('button', { name: 'Code', exact: true }).click();
  55 |     const languageSelect = page.locator(`#example-${EXAMPLE_NAME}-typescript-style-selector`);
  56 |     const otherLanguage = (await languageSelect.inputValue()) === 'typescript' ? 'vanilla' : 'typescript';
  57 |     await languageSelect.selectOption(otherLanguage);
  58 |     await exampleOuter.getByRole('button', { name: 'Preview', exact: true }).click();
  59 | 
  60 |     await expect(iframe).toHaveAttribute('src', new RegExp(`/${otherLanguage}/`), { timeout: 30_000 });
  61 |     await expect(iframe).toHaveCSS('visibility', 'visible', { timeout: 30_000 });
  62 |     await expect(loadingLogo).toHaveCount(0);
  63 | 
  64 |     expect(await getLoadingStates(page)).toEqual({ loadingLogo: true, iframeHidden: true });
  65 | });
  66 | 
```