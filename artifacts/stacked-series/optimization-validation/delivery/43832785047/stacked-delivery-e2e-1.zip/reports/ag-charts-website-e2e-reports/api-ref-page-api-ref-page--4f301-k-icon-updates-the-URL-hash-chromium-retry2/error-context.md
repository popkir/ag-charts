# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-ref-page.spec.ts >> api-ref-page >> property link icon updates the URL hash
- Location: e2e/api-ref-page.spec.ts:570:9

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByLabel('Link to width property')
Expected: "#reference-AgChartOptions-width"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for getByLabel('Link to width property')

```

```yaml
- banner:
  - link "Home":
    - /url: /
    - img
    - img
  - button "Products"
  - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.": Search Ctrl K
  - navigation:
    - list:
      - listitem:
        - link "AG Charts Examples":
          - /url: /examples/
          - text: Examples
      - listitem:
        - link "AG Charts Gallery":
          - /url: /gallery/
          - text: Gallery
      - listitem:
        - link "AG Charts Theme Builder":
          - /url: /theme-builder/
          - text: Theme Builder
      - listitem:
        - link "AG Charts Docs":
          - /url: /react/quick-start/
          - text: Docs
      - listitem:
        - link "AG Charts API":
          - /url: /options/
          - text: API
      - listitem:
        - link "AG Charts Community":
          - /url: /community/
          - text: Community
      - listitem:
        - link "AG Charts Pricing":
          - /url: /license-pricing/
          - text: Pricing
      - listitem:
        - link "AG Charts Contact Us":
          - /url: /contact/
          - text: Contact Us
      - listitem:
        - link "AG Charts GitHub":
          - /url: https://github.com/ag-grid/ag-charts
      - listitem:
        - button "Dark mode selector"
- navigation:
  - list:
    - listitem:
      - link "Options API":
        - /url: /options/
    - listitem:
      - link "Themes API":
        - /url: /themes-api/
    - listitem:
      - link "Theme Parameters":
        - /url: /theme-parameters-api/
    - listitem:
      - link "Chart API":
        - /url: /react/api-create-update/
    - listitem:
      - link "Events API":
        - /url: /react/events/
    - listitem:
      - link "Download API":
        - /url: /react/api-download/
    - listitem:
      - link "State API":
        - /url: /react/api-state/
    - listitem:
      - link "Context API":
        - /url: /react/context/
    - listitem:
      - link "TypeScript Generics":
        - /url: /react/ts-generics/
- main
- checkbox "Use dark theme"
- text: Use dark theme
- banner:
  - heading "Error" [level=2]
  - heading "An error occurred." [level=1]
- text: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
- heading "server/getInterfacesReference.ts:12:26" [level=2]
- button "Open in editor"
- code: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types'; import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages'; import { pathJoin } from '@utils/pathJoin'; import { readFileSync } from 'node:fs'; import { entries } from 'ag-charts-core'; type DevFileKey = keyof typeof DEV_FILE_PATH_MAP; function getJsonFromDevFile(devFileKey: DevFileKey) { const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]); const fileContents = readFileSync(file).toString(); ^ return fileContents === '' ? null : JSON.parse(fileContents); } /** * Get interfaces reference from the file system * * For static site generation */ export function getInterfacesReference() { const jsonContent = getJsonFromDevFile('resolved-interfaces.json'); return new Map(entries(jsonContent)) as ApiReferenceType; }"
- heading "Stack Trace" [level=2]
- text: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/components/ApiReferenceFallback.astro:32:1) at AstroComponentInstance.ApiReferenceFallback (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:83:23 at Array.map (<anonymous>) at renderSlots (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:82:21) at renderFrameworkComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:66:3) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:358:5) at Object.default (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options.astro:17:5) at new AstroComponentInstance (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:14:30) at createAstroComponentInstance (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:71:16) at renderAstroComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:340:7) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:344:7) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/pages/options.astro:16:1) at options (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at callComponentAsTemplateResultOrResponse (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render.js:216:11) at renderToAsyncIterable (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render.js:248:22) at renderPage (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/page.js:31:5) at handlePages (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/pages/handler.js:24:8) at async eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/middleware/index.ts:103:28) at async callMiddleware (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/middleware/callMiddleware.js:6:5) at async handleMiddleware (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/middleware/astro-middleware.js:26:15) at async render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/routing/handler.js:61:18) at async DevFacadeApp.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/app/base.js:244:7) at async run (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:95:11) at async runWithErrorHandling (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-astro-server/controller.js:63:3) at async handleDevRequest (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/vite-plugin-app/handle-request.js:39:3)"
```

# Test source

```ts
  473 |         await page.getByRole('button', { name: 'See child properties of PaddingOptions', exact: true }).click();
  474 |         const top = page.locator('#reference-AgChartOptions-padding-PaddingOptions-top');
  475 |         await expect(top).toBeVisible();
  476 |         await expect(top).toContainText('padding[PaddingOptions].top');
  477 |     });
  478 | 
  479 |     // A mixed union keeps its non-interface members (here the primitive `PixelSize`) in a signature
  480 |     // code block reached through "See more details", distinct from the variant rows.
  481 |     test('preserves the primitive members of a mixed union in its signature block', async ({ page }) => {
  482 |         await gotoUrl(page, toPageUrl('options/'));
  483 |         await waitForApiReady(page);
  484 | 
  485 |         await page.getByRole('button', { name: 'See more details about padding', exact: true }).click();
  486 |         const details = page.locator('#reference-AgChartOptions-padding-details');
  487 |         await expect(details).toBeVisible();
  488 |         await expect(details.locator('pre')).not.toHaveCount(0);
  489 |     });
  490 | 
  491 |     // `theme` has its own dedicated page (themes-api), so it renders as a plain, non-expandable row:
  492 |     // no "See available interfaces" action and no expander chevron on its name.
  493 |     test('renders theme as a plain non-expandable row', async ({ page }) => {
  494 |         await gotoUrl(page, toPageUrl('options/'));
  495 |         await waitForApiReady(page);
  496 | 
  497 |         const themeRow = page.locator('#reference-AgChartOptions-theme');
  498 |         await expect(themeRow).toBeVisible();
  499 |         await expect(page.getByRole('button', { name: 'See available interfaces of theme', exact: true })).toHaveCount(
  500 |             0
  501 |         );
  502 |         await expect(themeRow.locator('[class*="propNameExpander"]')).toHaveCount(0);
  503 |     });
  504 | 
  505 |     // `series` has its own navigable per-type pages, so its "See more details" code block lists
  506 |     // the union alias only — the variant names appear, but their interface bodies are not inlined.
  507 |     test('special-type code block lists the union alias without inlining sub-interfaces', async ({ page }) => {
  508 |         await gotoUrl(page, toPageUrl('options/'));
  509 |         await waitForApiReady(page);
  510 | 
  511 |         await page.getByRole('button', { name: 'See more details about series', exact: true }).click();
  512 | 
  513 |         const details = page.locator('#reference-AgChartOptions-series-details pre');
  514 |         await expect(details).toContainText('type AgChartSeriesOptions =');
  515 |         await expect(details).toContainText('AgBarSeriesOptions');
  516 |         await expect(details).not.toContainText('interface AgBarSeriesOptions');
  517 |     });
  518 | 
  519 |     // The type text toggles the inline code block only for members that have one: `series` is
  520 |     // clickable, but the primitive `width` has no code block so its type text stays inert.
  521 |     test('type text toggles the code block only for members that have one', async ({ page }) => {
  522 |         await gotoUrl(page, toPageUrl('options/'));
  523 |         await waitForApiReady(page);
  524 | 
  525 |         const seriesType = page.locator('#reference-AgChartOptions-series [class*="metaValue"]').first();
  526 |         await expect(seriesType).toHaveClass(/isClickable/);
  527 | 
  528 |         const details = page.locator('#reference-AgChartOptions-series-details');
  529 |         await expect(details).toHaveCount(0);
  530 |         await seriesType.click();
  531 |         await expect(details).toBeVisible();
  532 |         await seriesType.click();
  533 |         await expect(details).toHaveCount(0);
  534 | 
  535 |         const widthType = page.locator('#reference-AgChartOptions-width [class*="metaValue"]').first();
  536 |         await expect(widthType).not.toHaveClass(/isClickable/);
  537 |     });
  538 | 
  539 |     // Below the table breakpoint the right column stacks beneath the vertical side-line that marks
  540 |     // an expanded union (drawn at left: 8px), so it must be indented clear of that line.
  541 |     test('indents the stacked right column clear of the expansion side-line', async ({ page }) => {
  542 |         await page.setViewportSize({ width: 900, height: 900 });
  543 |         await gotoUrl(page, toPageUrl('options/'));
  544 |         await waitForApiReady(page);
  545 | 
  546 |         await page.getByRole('button', { name: 'See available interfaces of padding', exact: true }).click();
  547 | 
  548 |         const row = page.locator('#reference-AgChartOptions-padding');
  549 |         await expect(row).toHaveCSS('display', 'block');
  550 | 
  551 |         const offsets = await row.locator('[class*="rightColumn"]').evaluate((rightColumn) => {
  552 |             const propertyRow = rightColumn.closest('.property-row')!;
  553 |             const style = getComputedStyle(rightColumn);
  554 |             const contentLeft = rightColumn.getBoundingClientRect().left + parseFloat(style.paddingLeft);
  555 |             return { contentLeft, rowLeft: propertyRow.getBoundingClientRect().left };
  556 |         });
  557 |         expect(offsets.contentLeft - offsets.rowLeft).toBeGreaterThanOrEqual(16);
  558 |     });
  559 | 
  560 |     // The nav's primitive-union entry deep-links to the signature block via the `-details` hash; the
  561 |     // reference panel resolves that hash by auto-expanding the signature rather than the variant list.
  562 |     test('deep links to a union signature block via the details hash', async ({ page }) => {
  563 |         await gotoUrl(page, toPageUrl('options/series/bar/#reference-AgBarSeriesOptions-fill-details'));
  564 | 
  565 |         const details = page.locator('#reference-AgBarSeriesOptions-fill-details');
  566 |         await expect(details).toBeVisible();
  567 |         await expect(details.locator('pre')).not.toHaveCount(0);
  568 |     });
  569 | 
  570 |     test('property link icon updates the URL hash', async ({ page }) => {
  571 |         await gotoUrl(page, toPageUrl('options/'));
  572 | 
> 573 |         await expect(page.getByLabel('Link to width property')).toHaveAttribute(
      |                                                                 ^ Error: expect(locator).toHaveAttribute(expected) failed
  574 |             'href',
  575 |             '#reference-AgChartOptions-width'
  576 |         );
  577 |     });
  578 | 
  579 |     test('reselecting nav entry keeps a single highlighted node', async ({ page }) => {
  580 |         await gotoUrl(page, toPageUrl('options/'));
  581 |         await waitForApiReady(page);
  582 | 
  583 |         const seriesLink = getNavigationClickable(page, /^series\b/);
  584 |         await expect(seriesLink).toBeVisible();
  585 |         await seriesLink.click();
  586 |         await expect(getNavigationHighlight(page, /^series\b/)).toHaveCount(1);
  587 | 
  588 |         await seriesLink.click();
  589 |         await expect(getNavigationHighlight(page, /^series\b/)).toHaveCount(1);
  590 |     });
  591 | 
  592 |     test('nav entries link to the page or anchor they select', async ({ page }) => {
  593 |         await gotoUrl(page, toPageUrl('options/'));
  594 |         await waitForApiReady(page);
  595 | 
  596 |         await expect(getNavigationClickable(page, /^series\b/)).toHaveAttribute(
  597 |             'href',
  598 |             /\/options\/#reference-AgChartOptions-series$/
  599 |         );
  600 | 
  601 |         await expandNavNode(page, /^series\b/);
  602 |         const barLink = getNavigationTree(page).getByRole('link', { name: "{ type = 'bar'" });
  603 |         await expect(barLink).toHaveAttribute('href', /\/options\/series\/bar\/#reference-AgBarSeriesOptions-type$/);
  604 | 
  605 |         await barLink.click();
  606 |         await expect(page).toHaveURL(/\/options\/series\/bar\/#reference-AgBarSeriesOptions-type$/);
  607 |         await expect(page.locator('header h1')).toContainText("type = 'bar'");
  608 |     });
  609 | 
  610 |     test('keeps links to the reference pages in collapsed branches', async ({ page }) => {
  611 |         await gotoUrl(page, toPageUrl('options/'));
  612 |         await waitForApiReady(page);
  613 | 
  614 |         const barPageLink = page.locator('a[href$="/options/series/bar/"]');
  615 |         await expect(barPageLink).toHaveCount(1);
  616 |         await expect(barPageLink).toBeHidden();
  617 |         await expect(page.locator('a[href$="/options/axes/number/"]')).toHaveCount(1);
  618 |     });
  619 | });
  620 | 
  621 | function countSiblings(node: Element) {
  622 |     let count = 0;
  623 |     while (node.nextElementSibling) {
  624 |         node = node.nextElementSibling;
  625 |         count++;
  626 |     }
  627 |     return count;
  628 | }
  629 | 
```