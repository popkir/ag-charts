# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: example-runner-lazy-hydration.spec.ts >> Example runner lazy hydration >> mounts and fetches source only for runners the reader reaches
- Location: e2e/example-runner-lazy-hydration.spec.ts:14:9

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: locator('.example-runner-outer').first()
Expected: attached
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeAttached" with timeout 5000ms
  - waiting for locator('.example-runner-outer').first()

```

```yaml
- banner:
  - link "Home":
    - /url: /
    - img
    - img
  - button "Products"
  - button "Open search with Enter or Space, or use the Command K (Control K on Windows and Linux) shortcut while anywhere else in the page.": Search Ctrl K
  - navigation:
    - list:
      - listitem:
        - link "AG Charts Examples":
          - /url: /examples/
          - text: Examples
      - listitem:
        - link "AG Charts Gallery":
          - /url: /gallery/
          - text: Gallery
      - listitem:
        - link "AG Charts Theme Builder":
          - /url: /theme-builder/
          - text: Theme Builder
      - listitem:
        - link "AG Charts Docs":
          - /url: /javascript/quick-start/
          - text: Docs
      - listitem:
        - link "AG Charts API":
          - /url: /options/
          - text: API
      - listitem:
        - link "AG Charts Community":
          - /url: /community/
          - text: Community
      - listitem:
        - link "AG Charts Pricing":
          - /url: /license-pricing/
          - text: Pricing
      - listitem:
        - link "AG Charts Contact Us":
          - /url: /contact/
          - text: Contact Us
      - listitem:
        - link "AG Charts GitHub":
          - /url: https://github.com/ag-grid/ag-charts
      - listitem:
        - button "Dark mode selector"
- main:
  - link "What's New":
    - /url: /whats-new/
  - heading "Getting started" [level=5]
  - link "Quick Start":
    - /url: /javascript/quick-start/
  - link "Key Features":
    - /url: /javascript/key-features/
  - link "Community vs. Enterprise":
    - /url: /javascript/community-vs-enterprise/
  - button "Setup"
  - button "Tutorials"
  - button "Security & Compatibility"
  - separator
  - heading "AI Features" [level=5]
  - link "Skills":
    - /url: /javascript/skills/
  - separator
  - heading "Core features" [level=5]
  - button "Data"
  - button "Axes"
  - button "Data Elements"
  - button "Interactivity"
  - link "Accessibility":
    - /url: /javascript/accessibility/
  - link "Localisation":
    - /url: /javascript/localisation/
  - link "Series Highlighting":
    - /url: /javascript/series-highlighting/
  - link "Tooltips":
    - /url: /javascript/tooltips/
  - link "Touch":
    - /url: /javascript/touch/
  - link "Animation":
    - /url: /javascript/animation/
  - link "Context Menu":
    - /url: /javascript/context-menu/
  - link "Crosshairs & Band Highlight":
    - /url: /javascript/axes-crosshairs/
  - link "Data Selection":
    - /url: /javascript/selection/
  - link "Flash On Update":
    - /url: /javascript/flash-on-update/
  - link "Navigator":
    - /url: /javascript/navigator/
  - link "Range Controls":
    - /url: /javascript/range-controls/
  - link "Scrollbar":
    - /url: /javascript/scrollbar/
  - link "Synchronization":
    - /url: /javascript/sync/
  - link "Zoom":
    - /url: /javascript/zoom/
  - button "Layout & Styling"
  - separator
  - heading "Specialised Charts" [level=5]
  - button "Financial Charts"
  - button "Maps"
  - link "Org Chart":
    - /url: /javascript/org-chart/
  - link "Quadrant Chart":
    - /url: /javascript/quadrant-chart/
  - separator
  - heading "Series" [level=5]
  - link "Bar":
    - /url: /javascript/bar-series/
  - link "Line":
    - /url: /javascript/line-series/
  - link "Area":
    - /url: /javascript/area-series/
  - link "Scatter":
    - /url: /javascript/scatter-series/
  - link "Bubble":
    - /url: /javascript/bubble-series/
  - link "Pie":
    - /url: /javascript/pie-series/
  - link "Donut":
    - /url: /javascript/donut-series/
  - link "Combination":
    - /url: /javascript/combination-series/
  - link "Box Plot":
    - /url: /javascript/box-plot-series/
  - link "Candlestick":
    - /url: /javascript/candlestick-series/
  - link "HLC":
    - /url: /javascript/hlc-series/
  - link "OHLC":
    - /url: /javascript/ohlc-series/
  - link "Heatmap":
    - /url: /javascript/heatmap-series/
  - link "Histogram":
    - /url: /javascript/histogram-series/
  - link "Nightingale":
    - /url: /javascript/nightingale-series/
  - link "Radar Area":
    - /url: /javascript/radar-area-series/
  - link "Radar Line":
    - /url: /javascript/radar-line-series/
  - link "Radial Bar":
    - /url: /javascript/radial-bar-series/
  - link "Radial Column":
    - /url: /javascript/radial-column-series/
  - link "Range Area":
    - /url: /javascript/range-area-series/
  - link "Range Bar":
    - /url: /javascript/range-bar-series/
  - link "Waterfall":
    - /url: /javascript/waterfall-series/
  - link "Sunburst":
    - /url: /javascript/sunburst-series/
  - link "Treemap":
    - /url: /javascript/treemap-series/
  - link "Sankey":
    - /url: /javascript/sankey-series/
  - link "Chord":
    - /url: /javascript/chord-series/
  - link "Funnel":
    - /url: /javascript/funnel-series/
  - link "Cone Funnel":
    - /url: /javascript/cone-funnel-series/
  - link "Pyramid":
    - /url: /javascript/pyramid-series/
  - separator
  - heading "Gauges" [level=5]
  - link "Radial Gauge":
    - /url: /javascript/radial-gauge/
  - link "Linear Gauge":
    - /url: /javascript/linear-gauge/
  - heading "JavaScript Charts Zoom" [level=1]
  - text: Version 15.0.0
  - button "AI Options"
  - combobox "Framework selector":
    - img "javascript logo"
    - text: JavaScript
  - navigation "Other framework versions of this page":
    - list:
      - listitem:
        - link "React Charts":
          - /url: /react/zoom/
      - listitem:
        - link "Angular Charts":
          - /url: /angular/zoom/
      - listitem:
        - link "Vue Charts":
          - /url: /vue/zoom/
  - link "Enterprise":
    - /url: /javascript/community-vs-enterprise/
- checkbox "Use dark theme"
- text: Use dark theme
- banner:
  - heading "Error" [level=2]
  - heading "An error occurred." [level=1]
- text: "ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json'"
- heading "server/getInterfacesReference.ts:12:26" [level=2]
- button "Open in editor"
- code: "import type { ApiReferenceType } from '@generate-code-reference-plugin/doc-interfaces/types'; import { DEV_FILE_PATH_MAP, getRootUrl } from '@utils/pages'; import { pathJoin } from '@utils/pathJoin'; import { readFileSync } from 'node:fs'; import { entries } from 'ag-charts-core'; type DevFileKey = keyof typeof DEV_FILE_PATH_MAP; function getJsonFromDevFile(devFileKey: DevFileKey) { const file = pathJoin(getRootUrl().pathname, DEV_FILE_PATH_MAP[devFileKey]); const fileContents = readFileSync(file).toString(); ^ return fileContents === '' ? null : JSON.parse(fileContents); } /** * Get interfaces reference from the file system * * For static site generation */ export function getInterfacesReference() { const jsonContent = getJsonFromDevFile('resolved-interfaces.json'); return new Map(entries(jsonContent)) as ApiReferenceType; }"
- heading "Stack Trace" [level=2]
- text: "Error: ENOENT: no such file or directory, open '/home/runner/work/ag-charts/ag-charts/dist/packages/ag-charts-types/resolved-interfaces.AUTO.json' at Object.openSync (node:fs:621:18) at readFileSync (node:fs:487:35) at getJsonFromDevFile (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:12:26) at getInterfacesReference (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/utils/server/getInterfacesReference.ts:22:25) at eval (/home/runner/work/ag-charts/ag-charts/packages/ag-charts-website/src/components/api-documentation/ApiReference.astro:15:1) at AstroComponentInstance.ApiReference (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:83:23 at Array.map (<anonymous>) at renderSlots (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:82:21) at renderFrameworkComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:66:3) at renderComponent (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/component.js:358:5) at renderTreeNodeToFactoryResult (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:153:17) at factory (/home/runner/work/ag-charts/ag-charts/node_modules/@astrojs/markdoc/components/TreeNode.ts:118:10) at AstroComponentInstance.eval (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:43:20) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:24:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at SlotRenderInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:35:1) at renderSlotToString (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/slot.js:74:23) at Slots.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/core/render/slots.js:62:22) at eval (/home/runner/work/ag-charts/ag-charts/external/ag-website-shared/src/components/tabs/TabsWithHtmlChildren.astro:13:1) at AstroComponentInstance.TabsWithHtmlChildren (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/astro-component.js:11:12) at AstroComponentInstance.init (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:31:23) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:44:28) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at RenderTemplateResult.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/render-template.js:43:22) at AstroComponentInstance.renderImpl (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:52:32) at AstroComponentInstance.render (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/astro/instance.js:48:17) at renderChild (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:10:11) at /home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:52:18 at new BufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:162:18) at createBufferedRenderer (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/util.js:186:5) at renderArray (/home/runner/work/ag-charts/ag-charts/node_modules/astro/dist/runtime/server/render/any.js:51:22)"
```

# Test source

```ts
  1  | import { expect, test } from './fixture';
  2  | import { gotoUrl, toPageUrl } from './util';
  3  | 
  4  | // Example runners hydrate when they scroll into view (`client:visible`), so a page with many
  5  | // examples only mounts, and only fetches source for, the runners near the viewport. Off-screen
  6  | // runners keep their reserved height and mount when the reader reaches them.
  7  | 
  8  | test.use({ viewport: { width: 1280, height: 800 } });
  9  | 
  10 | // Eighteen runners, among the most rendered on any docs page
  11 | const PAGE_PATH = 'javascript/zoom/';
  12 | 
  13 | test.describe('Example runner lazy hydration', () => {
  14 |     test('mounts and fetches source only for runners the reader reaches', async ({ page }) => {
  15 |         const contentsRequests = new Set<string>();
  16 |         page.on('request', (request) => {
  17 |             if (/\/examples\/.*\/contents\.json/.test(request.url())) {
  18 |                 contentsRequests.add(request.url());
  19 |             }
  20 |         });
  21 | 
  22 |         await gotoUrl(page, toPageUrl(PAGE_PATH));
  23 |         const runners = page.locator('.example-runner-outer');
  24 |         const codeButtons = page.getByRole('button', { name: 'Code', exact: true });
> 25 |         await expect(runners.first()).toBeAttached();
     |                                       ^ Error: expect(locator).toBeAttached() failed
  26 |         const runnerCount = await runners.count();
  27 |         expect(runnerCount).toBeGreaterThan(5);
  28 | 
  29 |         // Give any eager hydration time to happen before counting
  30 |         await page.waitForTimeout(2000);
  31 |         expect(await codeButtons.count(), 'runners mounted on load').toBeLessThan(runnerCount);
  32 |         expect(contentsRequests.size, 'contents.json requests on load').toBeLessThan(runnerCount);
  33 | 
  34 |         // Reaching a runner mounts it and loads its source
  35 |         const firstRunner = runners.first();
  36 |         await firstRunner.scrollIntoViewIfNeeded();
  37 |         await expect(firstRunner.getByRole('button', { name: 'Code', exact: true })).toBeVisible();
  38 |         await expect.poll(() => contentsRequests.size).toBeGreaterThan(0);
  39 |         const mountedAtFirst = await codeButtons.count();
  40 |         expect(mountedAtFirst, 'runners mounted with the first in view').toBeLessThan(runnerCount);
  41 | 
  42 |         const lastRunner = runners.last();
  43 |         await lastRunner.scrollIntoViewIfNeeded();
  44 |         await expect(lastRunner.getByRole('button', { name: 'Code', exact: true })).toBeVisible();
  45 |         expect(await codeButtons.count()).toBeGreaterThan(mountedAtFirst);
  46 | 
  47 |         // The reserved height keeps the layout stable while runners hydrate and switch views.
  48 |         // Document-relative, since the click may scroll the page.
  49 |         const documentTop = (element: HTMLElement) => element.getBoundingClientRect().top + window.scrollY;
  50 |         const topBefore = await lastRunner.evaluate(documentTop);
  51 |         await lastRunner.getByRole('button', { name: 'Code', exact: true }).click();
  52 |         await expect(lastRunner.getByRole('button', { name: 'Preview', exact: true })).toBeVisible();
  53 |         expect(await lastRunner.evaluate(documentTop)).toBe(topBefore);
  54 |     });
  55 | });
  56 | 
```